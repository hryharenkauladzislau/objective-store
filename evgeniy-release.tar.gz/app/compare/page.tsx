import { Container } from "@/components/ui/primitives";
import { Comparison } from "@/components/catalog/Comparison";
import { readCatalog, publicCatalog } from "@/lib/catalog-store";
export const metadata = { title: "Сравнение устройств" };
export default async function Page() {
  return (
    <Container className="py-12">
      <h1 className="text-4xl font-semibold tracking-tight">Сравнение</h1>
      <p className="mt-3 text-sm text-muted">
        До трёх моделей рядом. Выберите то, что важно вам.
      </p>
      <Comparison products={publicCatalog(await readCatalog()).products} />
    </Container>
  );
}
