import { PAGE_COPY } from "@/lib/content";
import { Container } from "@/components/ui/primitives";
import { Comparison } from "@/components/catalog/Comparison";
import { readCatalog, publicCatalog } from "@/lib/catalog-store";
export const metadata = { title: "Сравнение устройств" };
export default async function Page() {
  const d = publicCatalog(await readCatalog());
  const copy = d.pages?.compare || PAGE_COPY.compare;
  return (
    <Container className="py-12">
      <h1 className="text-4xl font-semibold tracking-tight">{copy.title}</h1>
      <p className="mt-3 text-sm text-muted">
        {copy.intro}
      </p>
      <Comparison products={d.products} />
    </Container>
  );
}
