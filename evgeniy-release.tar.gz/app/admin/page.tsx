import { AdminPanel } from "@/components/admin/AdminPanel";
import { isAdmin } from "@/lib/admin-auth";
import { readCatalog } from "@/lib/catalog-store";
export const metadata = {
  title: "Управление магазином",
  robots: { index: false, follow: false },
};
export default async function Page() {
  return (
    <AdminPanel initial={(await isAdmin()) ? await readCatalog() : null} />
  );
}
