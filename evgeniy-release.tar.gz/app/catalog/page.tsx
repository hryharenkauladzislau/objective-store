import { PAGE_COPY } from "@/lib/content";
import { Container, SectionHeader } from "@/components/ui/primitives";
import { ProductCard } from "@/components/catalog/ProductCard";
import { CatalogControls } from "@/components/catalog/CatalogControls";
import { Button } from "@/components/ui/Button";
import { readCatalog, publicCatalog } from "@/lib/catalog-store";
import { CATALOG_SORTS, queryProducts, type CatalogQuery } from "@/lib/catalog";
import { ProductImage } from "@/components/catalog/ProductImage";

/*
 * Каталог (ТЗ §11): поиск, фильтры (модель/память/цвет/состояние/наличие/цена),
 * сортировка — состояние в URL. Пустая выдача предлагает сброс фильтров
 * и вопрос менеджеру.
 */

export const metadata = { title: "Каталог" };

export default async function CatalogPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const sp = await searchParams;
  const first = (key: string): string | undefined => {
    const v = sp[key];
    return Array.isArray(v) ? v[0] : v;
  };

  const data = publicCatalog(await readCatalog());
  const copy = data.pages?.catalog || PAGE_COPY.catalog;
  const category = data.categories.find(
    (c) => c.slug === first("category"),
  )?.slug;
  const currentCategory = data.categories.find((c) => c.slug === category);
  const subcategory = !currentCategory?.direct
    ? currentCategory?.subcategories?.find(
        (s) => s.slug === first("subcategory"),
      )?.slug
    : undefined;
  const sort = CATALOG_SORTS.find((s) => s === first("sort"));
  const storageGb = Number(first("storage"));
  const maxPriceUsd = Number(first("maxPrice"));

  const query: CatalogQuery = {
    category,
    subcategory,
    sale: first("sale") === "1",
    q: first("q"),
    storageGb:
      Number.isFinite(storageGb) && storageGb > 0 ? storageGb : undefined,
    color: first("color"),
    availability:
      first("availability") === "in-stock" ||
      first("availability") === "on-order"
        ? (first("availability") as "in-stock" | "on-order")
        : undefined,
    maxPriceUsd:
      Number.isFinite(maxPriceUsd) && maxPriceUsd > 0 ? maxPriceUsd : undefined,
    sort,
  };

  const products = queryProducts(query, data.products);
  const browseBrands = !category && !first("q") && !first("sale");
  const browseSubcategories = !!currentCategory && !currentCategory.direct && !subcategory && !first("q") && !first("sale");

  /* Опции фильтров — внутри текущей категории, но до остальных фильтров */
  const pool = data.products.filter(
    (p) => !category || p.category === category,
  );
  const storages = [
    ...new Set(pool.flatMap((p) => p.variants.map((v) => v.storageGb ?? -1))),
  ]
    .filter((gb) => gb > 0)
    .sort((a, b) => a - b);
  const colors = [
    ...new Set(pool.flatMap((p) => p.variants.map((v) => v.colorName))),
  ].sort((a, b) => a.localeCompare(b, "ru"));

  const hasActiveFilters = Boolean(
    query.q ||
    query.storageGb ||
    query.color ||
    query.availability ||
    query.maxPriceUsd ||
    sort ||
    subcategory ||
    query.sale,
  );

  const hasJsFilters = Boolean(
    query.q ||
    query.storageGb ||
    query.color ||
    query.availability ||
    query.maxPriceUsd ||
    subcategory ||
    query.sale,
  );

  return (
    <Container className="py-10 lg:py-14">
      <SectionHeader
        title={copy.title}
        caption={`${products.length} ${plural(products.length)} · цены уточняются у менеджера`}
      />

      {browseBrands && (
        <div className="mt-9 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {data.categories.map((c) => (
            <a key={c.slug} href={`/catalog?category=${c.slug}`} className="group grid min-h-72 overflow-hidden rounded-block border border-line bg-surface p-7 shadow-card sm:grid-rows-[auto_1fr_auto]">
              <div className="flex items-center justify-between"><h2 className="text-3xl font-semibold">{c.name}</h2></div>
              <div className="relative min-h-44"><ProductImage src={c.image || data.products.find((p) => p.category === c.slug)?.variants[0]?.images[0]} alt={c.name} className="object-contain p-3 transition-transform duration-500 group-hover:scale-105" /></div>
              <p className="text-sm text-muted">{c.caption}</p>
            </a>
          ))}
        </div>
      )}

      {browseSubcategories && (
        <div className="mt-9 grid grid-cols-2 gap-4 lg:grid-cols-3">
          {currentCategory.subcategories?.map((s) => (
            <a key={s.slug} href={`/catalog?category=${currentCategory.slug}&subcategory=${s.slug}`} className="group flex min-h-64 flex-col overflow-hidden rounded-block border border-line bg-surface p-6 shadow-card">
              <div className="flex items-center justify-between"><h2 className="text-2xl font-semibold">{s.name}</h2></div>
              <div className="relative mt-4 min-h-40 flex-1"><ProductImage src={s.image || data.products.find((p) => p.category === currentCategory.slug && p.subcategory === s.slug)?.variants[0]?.images[0]} alt={s.name} className="object-contain p-3 transition-transform duration-500 group-hover:scale-105" /></div>
            </a>
          ))}
        </div>
      )}

      <div className={(browseBrands || browseSubcategories) ? "mt-12" : "mt-8"}>
        <CatalogControls
          key={JSON.stringify(sp)}
          state={{
            category,
            subcategory,
            sale: query.sale ? "1" : undefined,
            q: query.q,
            storage: query.storageGb ? String(query.storageGb) : undefined,
            color: query.color,
            availability: query.availability,
            maxPrice: query.maxPriceUsd ? String(query.maxPriceUsd) : undefined,
            sort,
            focus: first("focus") !== undefined,
          }}
          storages={storages}
          colors={colors}
          hasActiveFilters={hasActiveFilters}
          chips={
            <div>
              <div className="mt-3 flex gap-2 overflow-x-auto pb-1">
                <Chip href="/catalog" active={!category}>
                  Все
                </Chip>
                {data.categories.map((c) => (
                  <Chip
                    key={c.slug}
                    href={`/catalog?category=${c.slug}`}
                    active={category === c.slug}
                  >
                    {c.name}
                  </Chip>
                ))}
                <Chip href="/catalog?sale=1" active={!!query.sale}>
                  SALE
                </Chip>
              </div>
              {!currentCategory?.direct &&
                !!currentCategory?.subcategories?.length && (
                  <div className="mt-3 flex flex-wrap gap-2">
                    <Chip
                      href={"/catalog?category=" + category}
                      active={!subcategory}
                    >
                      Все модели
                    </Chip>
                    {currentCategory.subcategories.map((s) => (
                      <Chip
                        key={s.slug}
                        href={`/catalog?category=${category}&subcategory=${s.slug}`}
                        active={subcategory === s.slug}
                      >
                        {s.name}
                      </Chip>
                    ))}
                  </div>
                )}
            </div>
          }
        />
      </div>

      {!browseBrands && !browseSubcategories && products.length > 0 ? (
        <div className="mt-8 grid grid-cols-2 gap-4 lg:grid-cols-4">
          {products.map((product, i) => (
            <ProductCard
              key={product.slug}
              product={product}
              priority={i < 4}
            />
          ))}
        </div>
      ) : !browseBrands && !browseSubcategories ? (
        <div className="mt-10 rounded-card border border-line bg-surface p-8 text-center shadow-card">
          <p className="text-lg font-bold">Ничего не нашлось</p>
          <p className="mx-auto mt-2 max-w-md text-sm leading-relaxed text-muted">
            {hasJsFilters
              ? "Попробуйте изменить или сбросить фильтры — либо спросите Евгения: подберёт вариант под запрос."
              : "В этой категории пока пусто. Спросите Евгения — подберёт вариант под запрос."}
          </p>
          <div className="mt-6 flex flex-wrap justify-center gap-3">
            <Button href="/catalog">Сбросить фильтры</Button>
            <Button href="/contacts?topic=question" variant="secondary">
              Задать вопрос
            </Button>
          </div>
        </div>
      ) : null}
    </Container>
  );
}

function Chip({
  href,
  active,
  children,
}: {
  href: string;
  active: boolean;
  children: string;
}) {
  const cls = active
    ? "border-transparent bg-ink text-canvas"
    : "border-line bg-surface text-ink/80 hover:border-ink/25";
  return (
    <a
      href={href}
      className={`shrink-0 rounded-full border px-4 py-2 text-sm font-medium transition-colors ${cls}`}
    >
      {children}
    </a>
  );
}

function plural(n: number): string {
  const mod10 = n % 10;
  const mod100 = n % 100;
  if (mod10 === 1 && mod100 !== 11) return "модель";
  if (mod10 >= 2 && mod10 <= 4 && (mod100 < 12 || mod100 > 14)) return "модели";
  return "моделей";
}
