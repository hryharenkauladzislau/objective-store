import Link from "next/link";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { Container } from "@/components/ui/primitives";
import { readCatalog, publicCatalog } from "@/lib/catalog-store";
import { ProductConfigurator } from "@/components/catalog/ProductConfigurator";
export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const p = publicCatalog(await readCatalog()).products.find(
    (p) => p.slug === slug,
  );
  return {
    title: p?.name || "Товар не найден",
    description: p
      ? p.name +
        " в Минске. Выберите память, цвет и версию. Актуальная цена и наличие — у менеджера."
      : undefined,
  };
}
export default async function ProductPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const d = publicCatalog(await readCatalog());
  const p = d.products.find((p) => p.slug === slug);
  if (!p) notFound();
  const json = {
    "@context": "https://schema.org",
    "@type": "Product",
    name: p.name,
    description: p.tagline,
    brand: { "@type": "Brand", name: "Apple" },
    image: p.variants[0]?.images,
    sku: p.slug,
  };
  return (
    <Container className="py-8 lg:py-12">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify(json).replace(/</g, "\\u003c"),
        }}
      />
      <nav
        aria-label="Хлебные крошки"
        className="flex gap-2 text-sm text-muted"
      >
        <Link href={"/catalog?category=" + p.category}>Каталог</Link>
        <span>/</span>
        <span>{p.name}</span>
      </nav>
      <ProductConfigurator product={p} />
      <section className="my-16 max-w-3xl">
        <h2 className="text-2xl font-semibold">Характеристики</h2>
        <dl className="mt-6 divide-y divide-line">
          {p.specs.map((s, i) => (
            <div className="flex justify-between gap-6 py-4 text-sm" key={i}>
              <dt className="text-muted">{s.label}</dt>
              <dd className="text-right">{s.value}</dd>
            </div>
          ))}
        </dl>
      </section>
    </Container>
  );
}
