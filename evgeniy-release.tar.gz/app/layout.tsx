import type { Metadata } from "next";
import { Manrope } from "next/font/google";
import "./globals.css";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { DartLoader } from "@/components/loading/DartLoader";
import { FounderContactDock } from "@/components/founder/FounderContactDock";
import { SiteProvider } from "@/components/layout/SiteProvider";
import { readCatalog } from "@/lib/catalog-store";
import { SITE } from "@/lib/site";
export const dynamic = "force-dynamic";

/*
 * TODO: заменить название, описание и контакты на данные заказчика (ТЗ §24).
 */
const manrope = Manrope({
  subsets: ["latin", "cyrillic"],
  variable: "--font-manrope",
  display: "swap",
});

export const metadata: Metadata = {
  metadataBase: process.env.NEXT_PUBLIC_SITE_URL
    ? new URL(process.env.NEXT_PUBLIC_SITE_URL)
    : undefined,
  openGraph: {
    title: "EVGENIY APPLE",
    description: "Техника Apple в Минске. Новые и б/у устройства, Trade-in.",
    locale: "ru_RU",
    type: "website",
    images: ["/images/evgeniy-founder.webp"],
  },
  title: {
    default: "EVGENIY APPLE — техника Apple в Минске: iPhone, Mac, iPad",
    template: "%s — EVGENIY APPLE",
  },
  description:
    "Техника Apple в Минске: актуальные iPhone, Mac, iPad и Watch, проверенные б/у устройства и Trade-in. Консультация лично от Евгения — основателя магазина.",
};

export default async function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const { settings } = await readCatalog();
  return (
    <html lang="ru" className={`${manrope.variable} h-full antialiased`}>
      <body className="flex min-h-full flex-col">
        <SiteProvider value={{ ...SITE, ...settings }}>
          <DartLoader />
          <Header />
          <main className="flex-1">{children}</main>
          <Footer />
          <FounderContactDock />
        </SiteProvider>
      </body>
    </html>
  );
}
