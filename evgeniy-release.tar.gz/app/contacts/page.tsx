import { Container } from "@/components/ui/primitives";
import { readCatalog } from "@/lib/catalog-store";
import { TelegramRequest } from "@/components/catalog/TelegramRequest";
export const metadata = { title: "Контакты" };
export default async function Page() {
  const { settings: s } = await readCatalog();
  return (
    <Container className="py-12 lg:py-20">
      <p className="text-xs uppercase tracking-widest text-muted">
        EVGENIY APPLE / МИНСК
      </p>
      <h1 className="mt-4 text-4xl font-semibold tracking-tight sm:text-6xl">
        Давайте обсудим.
      </h1>
      <div className="mt-12 grid gap-10 lg:grid-cols-2">
        <div>
          <a
            href={"tel:" + s.phone.replace(/[^+\d]/g, "")}
            className="text-2xl font-semibold sm:text-4xl"
          >
            {s.phone}
          </a>
          <p className="mt-5 text-sm text-muted">{s.email}</p>
          <div className="mt-8">
            <TelegramRequest text="Здравствуйте! Хочу задать вопрос о технике Apple." />
          </div>
          <div className="mt-8 flex flex-wrap gap-5 text-sm underline underline-offset-4">
            <a href={s.telegramChannel}>Telegram-канал ↗</a>
            <a href={s.instagramUrl}>Instagram ↗</a>
          </div>
        </div>
        <div className="rounded-block border border-line bg-white p-7">
          <h2 className="text-2xl font-semibold">Самовывоз</h2>
          <p className="mt-5">{s.address}</p>
          <p className="mt-3 text-sm text-muted">{s.hours}</p>
          <a
            className="mt-6 inline-block text-sm font-semibold text-accent"
            href={
              "https://yandex.by/maps/?text=" + encodeURIComponent(s.address)
            }
            target="_blank"
            rel="noopener noreferrer"
          >
            Показать на карте ↗
          </a>
          <p className="mt-10 border-t border-line pt-5 text-xs text-muted">
            {s.legalName} · УНП {s.legalId}
          </p>
        </div>
      </div>
    </Container>
  );
}
