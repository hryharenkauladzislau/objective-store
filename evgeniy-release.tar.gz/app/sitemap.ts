import type { MetadataRoute } from "next";
import { readCatalog, publicCatalog } from "@/lib/catalog-store";
export const dynamic = "force-dynamic";
export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const url = process.env.NEXT_PUBLIC_SITE_URL;
  if (!url) return [];
  const d = publicCatalog(await readCatalog());
  return [
    "",
    "/catalog",
    "/used",
    "/trade-in",
    "/shipping",
    "/warranty",
    "/repair",
    "/about",
    "/contacts",
    "/faq",
    ...d.products.map((p) => "/catalog/" + p.slug),
    ...d.used.map((u) => "/used/" + u.slug),
  ].map((p) => ({ url: url.replace(/\/$/, "") + p }));
}
