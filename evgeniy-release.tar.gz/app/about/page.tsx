import { ProductImage } from "@/components/catalog/ProductImage";
import { getPresentation } from "@/lib/presentation";
import { PAGE_COPY } from "@/lib/content";
import { Container } from "@/components/ui/primitives";
import { TelegramRequest } from "@/components/catalog/TelegramRequest";
import { readCatalog } from "@/lib/catalog-store";
import { SocialProof } from "@/components/social/SocialProof";
import { LocationPanel } from "@/components/location/LocationPanel";
export const metadata = { title: "Обо мне" };
export default async function Page() {
  const { settings: s, pages, presentation } = await readCatalog();
  const copy = pages?.about || PAGE_COPY.about;
  const p = getPresentation(presentation);
  return (
    <Container className="py-12 lg:py-20">
      <div className="grid items-center gap-10 lg:grid-cols-2">
        <div className="relative aspect-[4/5] overflow-hidden rounded-block">
          <ProductImage
            src={p.brand.founderPhoto}
            alt="Евгений, основатель магазина"
            priority
            sizes="(max-width:1024px) 100vw,50vw"
            className="object-cover object-[50%_18%]"
          />
        </div>
        <div>
          <p className="text-xs uppercase tracking-widest text-muted">
            ЛИЧНОЕ ЗНАКОМСТВО
          </p>
          <h1 className="mt-4 text-4xl font-semibold tracking-tight sm:text-6xl">
            {copy.title}
          </h1>
          <p className="mt-6 text-base leading-relaxed text-muted">
            {copy.intro}
          </p>
          {copy.sections.map((section,i)=><section key={i} className="mt-5"><h2 className="text-base font-semibold">{section.title}</h2><p className="mt-2 whitespace-pre-line text-sm leading-relaxed text-muted">{section.text}</p></section>)}
          <div className="mt-7">
            <TelegramRequest text="Здравствуйте, Евгений! Помогите, пожалуйста, с выбором устройства." />
          </div>
          <div className="mt-8 border-t border-line pt-5 text-xs text-muted">
            {s.legalName} · УНП {s.legalId}
            <p className="mt-2">{s.address}</p>
          </div>
        </div>
      </div>
      <div className="mt-16"><SocialProof value={p.socialProof} /></div>
      <div className="mt-8"><LocationPanel value={p.location} /></div>
    </Container>
  );
}
