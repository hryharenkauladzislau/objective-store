import Image from "next/image";
import { Container } from "@/components/ui/primitives";
import { TelegramRequest } from "@/components/catalog/TelegramRequest";
import { readCatalog } from "@/lib/catalog-store";
export const metadata = { title: "Обо мне" };
export default async function Page() {
  const { settings: s } = await readCatalog();
  return (
    <Container className="py-12 lg:py-20">
      <div className="grid items-center gap-10 lg:grid-cols-2">
        <div className="relative aspect-[4/5] overflow-hidden rounded-block">
          <Image
            src="/images/evgeniy-founder.webp"
            alt="Евгений, основатель магазина"
            fill
            priority
            sizes="(max-width:1024px) 100vw,50vw"
            className="object-cover object-top"
          />
        </div>
        <div>
          <p className="text-xs uppercase tracking-widest text-muted">
            ЛИЧНОЕ ЗНАКОМСТВО
          </p>
          <h1 className="mt-4 text-4xl font-semibold tracking-tight sm:text-6xl">
            Привет,
            <br />я Евгений.
          </h1>
          <p className="mt-6 text-base leading-relaxed text-muted">
            Evgeniy Apple — мой магазин техники в Минске. Здесь можно выбрать
            новые и б/у устройства Apple, обсудить Trade-in и договориться о
            доставке по Беларуси.
          </p>
          <p className="mt-4 text-sm leading-relaxed text-muted">
            В Telegram я публикую предложения магазина. Если нужной модели нет в
            каталоге, напишите — обсудим варианты.
          </p>
          <div className="mt-7">
            <TelegramRequest text="Здравствуйте, Евгений! Помогите, пожалуйста, с выбором устройства." />
          </div>
          <a
            className="mt-7 inline-block text-sm text-accent underline underline-offset-4"
            href={s.telegramChannel}
          >
            Публикации магазина ↗
          </a>
          <div className="mt-8 border-t border-line pt-5 text-xs text-muted">
            {s.legalName} · УНП {s.legalId}
            <p className="mt-2">{s.address}</p>
          </div>
        </div>
      </div>
    </Container>
  );
}
