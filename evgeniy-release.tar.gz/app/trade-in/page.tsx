import { Container } from "@/components/ui/primitives";
import { TradeInForm } from "@/components/catalog/TradeInForm";
import { readCatalog } from "@/lib/catalog-store";
export const metadata = { title: "Trade-in — оценка устройства" };
export default async function Page() {
  const d = await readCatalog();
  return (
    <Container className="py-12 lg:py-20">
      <p className="text-xs uppercase tracking-widest text-muted">
        ОБМЕН УСТРОЙСТВА
      </p>
      <h1 className="mt-4 text-4xl font-semibold tracking-tight sm:text-6xl">
        Начните с вашего Apple.
      </h1>
      <p className="mt-5 max-w-xl text-sm leading-relaxed text-muted">
        Несколько деталей о вашем устройстве — и менеджер сможет обсудить обмен.
        Финальная оценка после осмотра.
      </p>
      <TradeInForm rates={d.tradeIn || []} />
    </Container>
  );
}
