import { PAGE_COPY } from "@/lib/content";
import { Container } from "@/components/ui/primitives";
import { TradeInForm } from "@/components/catalog/TradeInForm";
import { readCatalog, publicCatalog } from "@/lib/catalog-store";
export const metadata = { title: "Trade-in — оценка устройства" };
export default async function Page() {
  const d = await readCatalog();
  const copy = d.pages?.["trade-in"] || PAGE_COPY["trade-in"];
  return (
    <Container className="trade-in-page py-10 lg:py-14">
      <p className="text-xs uppercase tracking-widest text-muted">
        ОБМЕН УСТРОЙСТВА
      </p>
      <h1 className="mt-4 text-4xl font-semibold tracking-tight sm:text-6xl">
        {copy.title}
      </h1>
      <p className="mt-5 max-w-4xl text-lg leading-relaxed text-muted">
        {copy.intro}
      </p>
      <p className="mt-5 max-w-4xl text-base leading-relaxed text-muted">{d.tradeInSettings?.intro?.replace("за три шага", "за четыре шага")}</p>
      <TradeInForm rates={d.tradeIn || []} settings={d.tradeInSettings} newDevices={publicCatalog(d).products.filter(p => p.subcategory === "iphone" || /^iPhone\b/i.test(p.name)).map(p => ({ slug: p.slug, name: p.name, variants: p.variants.filter(v => v.status !== "out") })).filter(p => p.variants.length)} />
    </Container>
  );
}
