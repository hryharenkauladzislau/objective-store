import Link from "next/link";
import { Container } from "@/components/ui/primitives";
import { ProductImage } from "@/components/catalog/ProductImage";
import { readCatalog, publicCatalog } from "@/lib/catalog-store";
import { PriceDisplay } from "@/components/catalog/PriceDisplay";
import { TelegramRequest } from "@/components/catalog/TelegramRequest";
export const metadata = { title: "Б/У устройства" };
export default async function Page() {
  const d = publicCatalog(await readCatalog());
  return (
    <Container className="py-12">
      <h1 className="text-4xl font-semibold tracking-tight sm:text-6xl">
        Б/У устройства
      </h1>
      <p className="mt-5 max-w-xl text-sm leading-relaxed text-muted">
        Каждая карточка — конкретный экземпляр. С фотографиями, состоянием,
        аккумулятором и комплектом.
      </p>
      {!d.used.length ? (
        <div className="my-14 rounded-block border border-line bg-white p-8">
          <h2 className="text-xl font-semibold">
            Сейчас нет опубликованных устройств.
          </h2>
          <p className="my-4 text-sm text-muted">
            Уточните у менеджера ближайшие поступления и доступные модели.
          </p>
          <TelegramRequest
            text="Здравствуйте! Какие б/у устройства сейчас есть в наличии?"
            label="Уточнить поступления"
          />
        </div>
      ) : (
        <div className="mt-10 grid grid-cols-2 gap-4 lg:grid-cols-4">
          {d.used.map((u) => (
            <Link
              key={u.id}
              href={"/used/" + u.slug}
              className="overflow-hidden rounded-card border border-line bg-white"
            >
              <div className="relative aspect-square">
                <ProductImage src={u.images[0]} alt={u.name} />
                {(u.oldPriceUsd ?? 0) > u.priceUsd && (
                  <span className="absolute right-3 top-3 rounded-full bg-red-700 px-3 py-1 text-xs font-semibold text-white">
                    SALE
                  </span>
                )}
              </div>
              <div className="p-4">
                <h2 className="font-semibold">{u.name}</h2>
                <p className="mt-2 text-xs text-muted">
                  {u.storageGb} ГБ · {u.colorName}
                </p>
                <p className="mt-2 text-xs text-muted">
                  Аккумулятор {u.batteryHealth}%
                </p>
                <p className="mt-4 font-semibold">
                  <PriceDisplay price={u.priceUsd} oldPrice={u.oldPriceUsd} />
                </p>
              </div>
            </Link>
          ))}
        </div>
      )}
    </Container>
  );
}
