import { notFound } from "next/navigation";
import { Container } from "@/components/ui/primitives";
import { Gallery } from "@/components/catalog/Gallery";
import { TelegramRequest } from "@/components/catalog/TelegramRequest";
import { PurchaseBar } from "@/components/catalog/PurchaseBar";
import { PriceDisplay } from "@/components/catalog/PriceDisplay";
import { readCatalog, publicCatalog } from "@/lib/catalog-store";
import { formatPrice } from "@/lib/catalog";
export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const u = publicCatalog(await readCatalog()).used.find(
    (u) => u.slug === slug,
  );
  return { title: u ? u.name + " — б/у" : "Устройство не найдено" };
}
export default async function Page({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const u = publicCatalog(await readCatalog()).used.find(
    (u) => u.slug === slug,
  );
  if (!u) notFound();
  const request = [
    "Здравствуйте! Хочу приобрести б/у " + u.name + ".",
    u.storageGb + " ГБ · " + u.colorName,
    "Экземпляр: " + u.id,
    "Цена на сайте: " + formatPrice(u.priceUsd),
    "Подтвердите наличие и условия покупки.",
  ].join("\n");
  const rows = [
    ["Память", u.storageGb + " ГБ"],
    ["Цвет", u.colorName],
    ["Состояние", u.conditionNote],
    [
      "Аккумулятор",
      u.batteryHealth + "%" + (u.batteryReplaced ? " · заменён" : ""),
    ],
    ["Комплект", u.kit.join(", ") || "Уточняется"],
    ["Проверки", u.checks.join(", ") || "Уточняются"],
    ["Дефекты", u.defects || "Не указаны продавцом"],
    [
      "Гарантия",
      u.warrantyMonths ? u.warrantyMonths + " мес." : "Уточните условия",
    ],
  ];
  return (
    <Container className="py-12">
      <PurchaseBar
        text={request}
        price={formatPrice(u.priceUsd)}
        label="Уточнить наличие"
      />
      <div className="grid gap-10 lg:grid-cols-2">
        <Gallery images={u.images} name={u.name} />
        <div>
          <p className="text-xs uppercase tracking-widest text-muted">
            ПАСПОРТ Б/У УСТРОЙСТВА
          </p>
          <h1 className="mt-4 text-4xl font-semibold">{u.name}</h1>
          {(u.oldPriceUsd ?? 0) > u.priceUsd && (
            <span className="mt-4 inline-block rounded-full bg-red-700 px-3 py-1 text-xs font-semibold text-white">
              SALE
            </span>
          )}
          <p className="mt-5 text-3xl font-semibold">
            <PriceDisplay price={u.priceUsd} oldPrice={u.oldPriceUsd} />
          </p>
          <dl className="my-7 divide-y divide-line">
            {rows.map(([k, v]) => (
              <div key={k} className="grid grid-cols-2 gap-4 py-3 text-sm">
                <dt className="text-muted">{k}</dt>
                <dd>{v}</dd>
              </div>
            ))}
          </dl>
          <TelegramRequest text={request} label="Уточнить наличие" />
        </div>
      </div>
    </Container>
  );
}
