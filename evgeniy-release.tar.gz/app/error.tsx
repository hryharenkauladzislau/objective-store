"use client";
export default function ErrorPage({ retry }: { retry: () => void }) {
  return (
    <div className="mx-auto max-w-xl px-5 py-20">
      <h2 className="text-3xl font-semibold">Не удалось загрузить страницу.</h2>
      <p className="mt-4 text-sm text-muted">
        Попробуйте ещё раз. Если проблема остаётся, свяжитесь с магазином.
      </p>
      <button
        className="mt-6 rounded-full bg-accent px-6 py-3 text-white"
        onClick={retry}
      >
        Повторить
      </button>
    </div>
  );
}
