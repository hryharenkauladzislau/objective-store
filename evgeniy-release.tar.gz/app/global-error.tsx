"use client";
export default function GlobalError({ retry }: { retry: () => void }) {
  return (
    <html lang="ru">
      <body
        style={{
          fontFamily: "system-ui",
          padding: "60px 24px",
          background: "#f7f7f3",
          color: "#171717",
        }}
      >
        <h1>Магазин временно недоступен</h1>
        <p>Попробуйте обновить страницу или напишите в Telegram.</p>
        <button onClick={retry}>Повторить</button>
        <p>
          <a href="https://t.me/evgeniy_apple">Связаться с магазином</a>
        </p>
      </body>
    </html>
  );
}
