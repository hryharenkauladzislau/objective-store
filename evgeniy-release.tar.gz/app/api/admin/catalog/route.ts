import { isAdmin, guard } from "@/lib/admin-auth";
import {
  readCatalog,
  writeCatalog,
  RevisionConflict,
} from "@/lib/catalog-store";
import { ZodError } from "zod";
export async function GET() {
  if (!(await isAdmin())) return new Response(null, { status: 401 });
  return Response.json(await readCatalog(), {
    headers: { "Cache-Control": "no-store" },
  });
}
export async function PUT(r: Request) {
  const denied = await guard(r);
  if (denied) return denied;
  try {
    const text = await r.text();
    if (Buffer.byteLength(text) > 4 * 1024 * 1024)
      return new Response(null, { status: 413 });
    return Response.json(await writeCatalog(JSON.parse(text)));
  } catch (e) {
    return Response.json(
      {
        error:
          e instanceof ZodError
            ? e.issues
                .map((x) => `${x.path.join(".")}: ${x.message}`)
                .join("; ")
            : e instanceof RevisionConflict
              ? e.message
              : "Не удалось сохранить каталог. Проверьте данные и хранилище.",
      },
      {
        status:
          e instanceof RevisionConflict
            ? 409
            : e instanceof ZodError || e instanceof SyntaxError
              ? 400
              : 500,
      },
    );
  }
}
