import { guard, isAdmin } from "@/lib/admin-auth";
import { readCatalog } from "@/lib/catalog-store";
import { exportPriceList, previewPriceList } from "@/lib/price-list";
export async function GET() {
  if (!(await isAdmin())) return Response.json({ error: "Нужен вход" }, { status: 401 });
  return new Response(exportPriceList(await readCatalog()), { headers: {
    "Content-Type": "text/plain; charset=utf-8", "Content-Disposition": 'attachment; filename="evgeniy-apple-prices.txt"', "Cache-Control": "no-store",
  }});
}
export async function POST(req: Request) {
  const denied = await guard(req);
  if (denied) return denied;
  try {
    if (Number(req.headers.get("content-length")) > 3 * 1024 * 1024) return Response.json({ error: "Файл больше 2 МБ" }, { status: 413 });
    const form = await req.formData();
    const file = form.get("file");
    if (!(file instanceof File) || !file.name.toLowerCase().endsWith(".txt") || file.size > 2 * 1024 * 1024) return Response.json({ error: "Нужен TXT до 2 МБ" }, { status: 400 });
    return Response.json(previewPriceList(await file.text(), await readCatalog()), { headers: { "Cache-Control": "no-store" } });
  } catch (e) { return Response.json({ error: (e as Error).message }, { status: 400 }); }
}
