import { guard, isAdmin } from "@/lib/admin-auth";
import { excelTemplate, previewExcel } from "@/lib/excel";
import { readCatalog } from "@/lib/catalog-store";
export async function GET() {
  if (!(await isAdmin()))
    return Response.json({ error: "Нужен вход" }, { status: 401 });
  return new Response(
    new Uint8Array(await excelTemplate(await readCatalog())),
    {
      headers: {
        "Content-Type":
          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "Content-Disposition": 'attachment; filename="catalog-template.xlsx"',
      },
    },
  );
}
export async function POST(req: Request) {
  const error = await guard(req);
  if (error) return error;
  try {
    const length = Number(req.headers.get("content-length"));
    if (length > 3 * 1024 * 1024)
      return Response.json({ error: "Файл больше 2 МБ" }, { status: 413 });
    const form = await req.formData();
    const file = form.get("file");
    if (
      !(file instanceof File) ||
      !file.name.toLowerCase().endsWith(".xlsx") ||
      file.size > 2 * 1024 * 1024
    )
      return Response.json({ error: "Нужен .xlsx до 2 МБ" }, { status: 400 });
    return Response.json(
      await previewExcel(
        Buffer.from(await file.arrayBuffer()),
        await readCatalog(),
      ),
      { headers: { "Cache-Control": "no-store" } },
    );
  } catch (e) {
    return Response.json({ error: (e as Error).message }, { status: 400 });
  }
}
