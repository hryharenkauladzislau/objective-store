import { cookies } from "next/headers";
import {
  COOKIE,
  configured,
  passwordMatches,
  token,
  sameOrigin,
  throttle,
} from "@/lib/admin-auth";
export async function POST(r: Request) {
  if (!sameOrigin(r))
    return Response.json({ error: "Недопустимый источник" }, { status: 403 });
  if (!configured())
    return Response.json(
      { error: "На сервере не настроен пароль администратора" },
      { status: 503 },
    );
  if (throttle(r))
    return Response.json(
      { error: "Слишком много попыток. Подождите 15 минут" },
      { status: 429 },
    );
  try {
    if (Number(r.headers.get("content-length")) > 4096)
      return new Response(null, { status: 413 });
    const { password } = await r.json();
    if (typeof password !== "string" || !passwordMatches(password))
      return Response.json({ error: "Неверный пароль" }, { status: 401 });
    (await cookies()).set(COOKIE, token(), {
      httpOnly: true,
      sameSite: "strict",
      secure: process.env.NODE_ENV === "production",
      path: "/",
      maxAge: 8 * 3600,
    });
    return Response.json({ ok: true });
  } catch {
    return Response.json({ error: "Некорректный запрос" }, { status: 400 });
  }
}
export async function DELETE(r: Request) {
  if (!sameOrigin(r)) return new Response(null, { status: 403 });
  (await cookies()).delete(COOKIE);
  return Response.json({ ok: true });
}
