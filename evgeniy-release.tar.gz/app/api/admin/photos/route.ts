import sharp from "sharp";
import { guard } from "@/lib/admin-auth";
import { putPhoto } from "@/lib/catalog-store";
export async function POST(r: Request) {
  const denied = await guard(r);
  if (denied) return denied;
  if (Number(r.headers.get("content-length")) > 11 * 1024 * 1024)
    return new Response(null, { status: 413 });
  try {
    const file = (await r.formData()).get("file");
    if (!(file instanceof File) || file.size > 10 * 1024 * 1024)
      return Response.json({ error: "Фото до 10 МБ" }, { status: 400 });
    const bytes = Buffer.from(await file.arrayBuffer());
    const instance = sharp(bytes, { limitInputPixels: 40000000 });
    const m = await instance.metadata();
    if (!["jpeg", "png", "webp"].includes(m.format || ""))
      return Response.json(
        { error: "Используйте JPEG, PNG или WebP" },
        { status: 400 },
      );
    const result = await instance
      .rotate()
      .resize(1600, 1600, { fit: "inside", withoutEnlargement: true })
      .webp({ quality: 85 })
      .toBuffer();
    return Response.json({ url: await putPhoto(result) });
  } catch {
    return Response.json(
      { error: "Не удалось загрузить фото" },
      { status: 400 },
    );
  }
}
