import { readCatalog, publicCatalog } from "@/lib/catalog-store";
export async function GET() {
  return Response.json(publicCatalog(await readCatalog()), {
    headers: { "Cache-Control": "no-store" },
  });
}
