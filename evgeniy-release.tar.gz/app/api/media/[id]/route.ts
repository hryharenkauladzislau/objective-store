import { getPhoto } from "@/lib/catalog-store";
export async function GET(
  _r: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const bytes = await getPhoto((await params).id);
  if (!bytes) return new Response(null, { status: 404 });
  return new Response(new Uint8Array(bytes), {
    headers: {
      "Content-Type": "image/webp",
      "Cache-Control": "public,max-age=31536000,immutable",
      "X-Content-Type-Options": "nosniff",
    },
  });
}
