import { readCatalog } from "@/lib/catalog-store";
export async function GET() {
  try {
    await readCatalog();
    return Response.json(
      { status: "ok" },
      { headers: { "Cache-Control": "no-store" } },
    );
  } catch {
    return Response.json({ status: "unavailable" }, { status: 503 });
  }
}
