import Link from "next/link";
import { DeviceScene } from "@/components/home/DeviceScene";
import { EditorialVideo } from "@/components/home/EditorialVideo";
import { EditorialMotion } from "@/components/home/EditorialMotion";
import { EditorialShowcase } from "@/components/home/EditorialShowcase";
import { Container, SectionHeader } from "@/components/ui/primitives";
import { Button } from "@/components/ui/Button";
import { readCatalog, publicCatalog } from "@/lib/catalog-store";
import { productStatus, isSale } from "@/lib/catalog";
import { FeaturedCarousel } from "@/components/carousel/FeaturedCarousel";
import { ProductCard } from "@/components/catalog/ProductCard";
import { ProductImage } from "@/components/catalog/ProductImage";
import { EntryGate } from "@/components/loading/EntryGate";
import { getPresentation } from "@/lib/presentation";
import { SocialProof } from "@/components/social/SocialProof";
import { LocationPanel } from "@/components/location/LocationPanel";
export default async function HomePage() {
 const d=publicCatalog(await readCatalog()), p=getPresentation(d.presentation);
 const featured=d.products.filter(n=>n.featuredOnHome&&n.subcategory==="iphone"&&["in-stock","on-order","request"].includes(productStatus(n)));
 const models=(featured.length?featured:d.products.filter(n=>n.subcategory==="iphone")).slice(0,p.carousel.limit);
 const sales=d.products.filter(n=>n.variants.some(v=>isSale(v)&&["in-stock","on-order"].includes(v.status))).slice(0,4);
 const others=d.products.filter(n=>n.subcategory!=="iphone"&&!models.some(m=>m.slug===n.slug)).slice(0,4);
 return <><EntryGate/><EditorialMotion>{p.home.filter(b=>b.enabled).map(b=>{
  const heading=<SectionHeader title={b.title} href={b.ctaLabel?b.ctaHref:undefined} hrefLabel={b.ctaLabel}/>;
  const cta=b.ctaLabel?<Button href={b.ctaHref}>{b.ctaLabel}</Button>:null;
  let section;
  switch(b.id){
   case "carousel":section=<><div className="editorial-hero">{!b.image&&<EditorialVideo/>}<div className="editorial-hero-backdrop" aria-hidden="true" style={b.image?{backgroundImage:`linear-gradient(180deg,rgba(0,0,0,.12),rgba(0,0,0,.72)),url("${b.image}")`}:undefined}/><div className="editorial-hero-content"><p className="text-xs uppercase tracking-[.2em] text-muted">{b.kicker}</p><h1 className="mt-3 text-[42px] leading-[1.08] font-semibold tracking-[-.045em] sm:text-6xl lg:text-[76px]">{b.title}</h1><p className="mt-4 max-w-lg text-sm text-muted">{b.body}</p>{cta}</div></div><div className="mt-8"><FeaturedCarousel products={models}/></div></>;break;
   case "device-scene":section=<DeviceScene block={b}/>;break;
   case "showcase":section=<EditorialShowcase block={b}/>;break;
   case "quick-links":section=<div className="grid grid-cols-2 gap-2 border-y border-line py-5 sm:grid-cols-4">{b.items.map((i,n)=><Link key={n} href={i.href||"/catalog"} className="flex items-center justify-between gap-2 p-2 text-sm font-medium hover:text-accent">{i.title}</Link>)}</div>;break;
   case "benefits":section=<div className="grid gap-6 text-xs sm:grid-cols-3">{b.items.map((i,n)=><Link key={n} href={i.href||"/contacts"} className="border-t border-line pt-5"><h2 className="font-semibold">{i.title}</h2><p className="mt-2 leading-relaxed text-muted">{i.text}</p></Link>)}</div>;break;
   case "sale":if(!sales.length)return null;section=<>{heading}<div className="mt-7 grid grid-cols-2 gap-4 lg:grid-cols-4">{sales.map(n=><ProductCard key={n.slug} product={n}/>)}</div></>;break;
   case "categories":section=<>{heading}<div className="mt-7 grid grid-cols-2 gap-4 lg:grid-cols-6">{d.categories.map((c,i)=><Link key={c.slug} href={"/catalog?category="+c.slug} className={"group flex min-h-64 flex-col overflow-hidden rounded-card border border-line bg-surface p-5 sm:min-h-80 sm:p-7 "+(i===0?"lg:col-span-4":"lg:col-span-1")}><div className="flex items-center justify-between"><h3 className="text-xl font-semibold sm:text-2xl">{c.name}</h3><span className="text-xs text-muted">{String(i+1).padStart(2,"0")}</span></div><div className="relative mt-4 min-h-36 flex-1 sm:min-h-48"><ProductImage src={c.image||d.products.find(n=>n.category===c.slug)?.variants[0]?.images[0]} alt={c.name} sizes="(max-width:640px) 45vw,45vw" className="object-contain p-2 transition-transform duration-500 group-hover:scale-105"/></div>{c.caption&&<p className="mt-3 text-xs text-muted">{c.caption}</p>}</Link>)}</div></>;break;
   case "used":section=<div className="grid overflow-hidden rounded-block bg-surface text-ink md:grid-cols-2"><div className="p-7 sm:p-12"><p className="text-xs uppercase tracking-widest text-ink/60">{b.kicker}</p><h2 className="mt-5 text-3xl leading-tight font-semibold sm:text-5xl">{b.title}</h2><p className="mt-5 max-w-sm text-sm leading-relaxed text-ink/70">{b.body}</p><Link href={b.ctaHref} className="mt-8 inline-flex rounded-full bg-surface px-6 py-3 text-sm font-semibold text-ink">{b.ctaLabel}</Link></div><div className="border-t border-ink/15 px-7 py-8 md:border-t-0 md:border-l sm:px-12">{b.items.map((i,n)=><div key={n} className="flex gap-6 border-b border-ink/15 py-5 text-sm"><span className="text-ink/40">{String(n+1).padStart(2,"0")}</span><span>{i.title}{i.text&&<small className="mt-2 block text-ink/70">{i.text}</small>}</span></div>)}</div></div>;break;
   case "trade-in":section=<div className="grid items-center gap-8 border-y border-line py-12 md:grid-cols-[1.3fr_1fr]"><div><p className="text-xs uppercase tracking-widest text-muted">{b.kicker}</p><h2 className="mt-4 text-3xl font-semibold tracking-tight sm:text-5xl">{b.title}</h2></div><div><p className="max-w-sm text-sm leading-relaxed text-muted">{b.body}</p><div className="mt-6">{cta}</div></div></div>;break;
   case "other-products":if(!others.length)return null;section=<>{heading}<div className="mt-7 grid grid-cols-2 gap-4 lg:grid-cols-4">{others.map(n=><ProductCard key={n.slug} product={n}/>)}</div></>;break;
   case "about":section=<div className="grid items-center gap-8 overflow-hidden rounded-block bg-surface md:grid-cols-2"><div className="relative min-h-80 md:min-h-[480px]"><ProductImage src={p.brand.founderPhoto} alt={p.brand.founderName+", основатель магазина"} sizes="(max-width:768px) 100vw,50vw" className="object-cover object-[50%_18%]"/></div><div className="p-7 md:py-10 md:pr-12"><p className="text-xs uppercase tracking-widest text-muted">{b.kicker}</p><h2 className="mt-4 text-3xl font-semibold tracking-tight sm:text-5xl">{b.title}</h2><p className="mt-5 whitespace-pre-line text-sm leading-relaxed text-muted">{b.body}</p><Link href={b.ctaHref} className="mt-7 inline-block text-sm font-semibold text-accent">{b.ctaLabel}</Link><a href={d.settings.telegramChannel} className="ml-5 text-sm text-muted underline underline-offset-4">Канал магазина</a></div></div>;break;
   case "reviews":section=<SocialProof value={p.socialProof}/>;break;
   case "location":section=<LocationPanel value={p.location} compact/>;break;
   case "services":section=<div className="grid gap-3 sm:grid-cols-2">{b.items.map((i,n)=><Link key={n} href={i.href||"/contacts"} className="rounded-card border border-line bg-surface p-7"><h2 className="flex justify-between gap-4 text-xl font-semibold">{i.title}</h2><p className="mt-4 max-w-sm text-sm text-muted">{i.text}</p></Link>)}</div>;break;
   case "faq":section=<>{heading}<div className="mt-5 divide-y divide-line">{b.items.map((i,n)=><details key={n} className="py-5"><summary className="cursor-pointer text-sm font-semibold">{i.title}</summary><p className="mt-3 max-w-2xl text-sm leading-relaxed text-muted">{i.text}</p></details>)}</div></>;break;
   case "contacts":section=<div className="flex flex-wrap items-center justify-between gap-8 border-t border-line pt-10"><div><p className="text-xs uppercase tracking-widest text-muted">{b.kicker}</p><h2 className="mt-3 text-2xl font-semibold">{b.title}</h2><p className="mt-3 text-sm">{d.settings.address}</p><p className="mt-2 text-sm text-muted">{d.settings.hours}</p>{b.body&&<p className="mt-3 text-sm text-muted">{b.body}</p>}</div>{cta}</div>;break;
   default:section=<>{heading}{b.body&&<p className="mt-5 whitespace-pre-line text-sm leading-relaxed text-muted">{b.body}</p>}<div className="mt-8 grid gap-8 sm:grid-cols-3">{b.items.map((i,n)=><div key={n} className="border-t border-line pt-5"><p className="text-xs text-muted">{String(n+1).padStart(2,"0")}</p><h3 className="mt-5 text-xl font-semibold">{i.title}</h3><p className="mt-3 whitespace-pre-line text-sm leading-relaxed text-muted">{i.text}</p>{i.href&&<Link className="mt-4 inline-block text-sm text-accent" href={i.href}>Подробнее</Link>}</div>)}</div></>;
  }
  return <Container key={b.id} className={b.id==="carousel"?"pb-10 pt-9 lg:pt-14":(["quick-links","benefits"].includes(b.id)?"pb-10":"pb-20")}><section data-home-block={b.id}>{section}</section></Container>;
 })}</EditorialMotion></>;
}
