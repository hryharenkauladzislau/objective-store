import Link from "next/link";
import Image from "next/image";
import { Container, SectionHeader } from "@/components/ui/primitives";
import { Button } from "@/components/ui/Button";
import { readCatalog, publicCatalog } from "@/lib/catalog-store";
import { productStatus, isSale } from "@/lib/catalog";
import { FeaturedCarousel } from "@/components/carousel/FeaturedCarousel";
import { ProductCard } from "@/components/catalog/ProductCard";
import { ProductImage } from "@/components/catalog/ProductImage";
import { EntryGate } from "@/components/loading/EntryGate";
export default async function HomePage() {
  const d = publicCatalog(await readCatalog());
  const featured = d.products.filter(
    (p) =>
      p.featuredOnHome &&
      p.category === "iphone" &&
      ["in-stock", "on-order"].includes(productStatus(p)),
  );
  const overview = d.products
    .filter((p) => p.category === "iphone")
    .slice(0, 5);
  const models = featured.length ? featured : overview;
  const sales = d.products
    .filter((p) =>
      p.variants.some(
        (v) => isSale(v) && ["in-stock", "on-order"].includes(v.status),
      ),
    )
    .slice(0, 4);
  const others = d.products
    .filter(
      (p) => p.category !== "iphone" && !models.some((m) => m.slug === p.slug),
    )
    .slice(0, 4);
  return (
    <>
      <EntryGate />
      <Container className="pb-16 pt-9 lg:pt-14">
        <div className="flex flex-wrap items-end justify-between gap-5">
          <div>
            <p className="text-xs uppercase tracking-[.2em] text-muted">
              EVGENIY APPLE / МИНСК
            </p>
            <h1 className="mt-3 text-[42px] leading-[1.08] font-semibold tracking-[-.045em] sm:text-6xl lg:text-[76px]">
              Ваш следующий iPhone.
            </h1>
            <p className="mt-4 max-w-lg text-sm text-muted">
              {featured.length
                ? "Выберите модель. Цвет, память и цена — внутри."
                : "Обзор моделей. Актуальную цену и наличие подтвердит менеджер."}
            </p>
          </div>
          <Button href="/catalog" size="lg">
            Каталог ↗
          </Button>
        </div>
        <div className="mt-8">
          <FeaturedCarousel products={models} />
        </div>
        <div className="mt-8 grid grid-cols-2 gap-2 border-y border-line py-5 sm:grid-cols-4">
          {[
            ["/catalog", "Каталог"],
            ["/used", "Б/У устройства"],
            ["/trade-in", "Trade-in"],
            ["/contacts", "Задать вопрос"],
          ].map(([href, label]) => (
            <Link
              key={href}
              href={href}
              className="flex items-center justify-between gap-2 p-2 text-sm font-medium hover:text-accent"
            >
              {label}
              <span>↗</span>
            </Link>
          ))}
        </div>
        <div className="grid gap-3 py-7 text-xs text-muted sm:grid-cols-3">
          <Link href="/warranty">Гарантия — условия до покупки →</Link>
          <Link href="/shipping">Доставка по Минску и Беларуси →</Link>
          <Link href="/contacts">Помощь с выбором →</Link>
        </div>
      </Container>
      <Container className="pb-20">
        {sales.length > 0 && (
          <section className="mb-16">
            <SectionHeader
              title="Специальные предложения"
              href="/catalog?sale=1"
              hrefLabel="Все SALE"
            />
            <div className="mt-7 grid grid-cols-2 gap-4 lg:grid-cols-4">
              {sales.map((p) => (
                <ProductCard key={p.slug} product={p} />
              ))}
            </div>
          </section>
        )}
        <SectionHeader
          title="Техника для ваших задач."
          href="/catalog"
          hrefLabel="Каталог"
        />
        <div className="mt-7 grid grid-cols-2 gap-4 lg:grid-cols-6">
          {d.categories
            .filter((c) => d.products.some((p) => p.category === c.slug))
            .map((c, i) => {
              const image = d.products.find((p) => p.category === c.slug)
                ?.variants[0]?.images[0];
              return (
                <Link
                  key={c.slug}
                  href={"/catalog?category=" + c.slug}
                  className={
                    "group flex min-h-64 flex-col overflow-hidden rounded-card border border-line bg-white p-5 sm:min-h-80 sm:p-7 " +
                    (i >= 3 ? "lg:col-span-3" : "lg:col-span-2")
                  }
                >
                  <div className="flex items-center justify-between">
                    <h3 className="text-xl font-semibold sm:text-2xl">
                      {c.name}
                    </h3>
                    <span className="text-xs text-muted">0{i + 1} ↗</span>
                  </div>
                  <div className="relative mt-4 min-h-36 flex-1 sm:min-h-48">
                    <ProductImage
                      src={image}
                      alt={c.name}
                      sizes="(max-width:640px) 45vw, 30vw"
                      className="object-contain p-2 transition-transform duration-300 group-hover:scale-105"
                    />
                  </div>
                </Link>
              );
            })}
        </div>
      </Container>
      <Container className="pb-20">
        <div className="grid overflow-hidden rounded-block bg-ink text-white md:grid-cols-2">
          <div className="p-7 sm:p-12">
            <p className="text-xs uppercase tracking-widest text-white/60">
              Б/У УСТРОЙСТВА
            </p>
            <h2 className="mt-5 text-3xl leading-tight font-semibold sm:text-5xl">
              Другой владелец.
              <br />
              Тот же Apple.
            </h2>
            <p className="mt-5 max-w-sm text-sm leading-relaxed text-white/70">
              Фотографии конкретного устройства, состояние аккумулятора и
              комплект. Всё, что важно знать до встречи.
            </p>
            <Link
              href="/used"
              className="mt-8 inline-flex rounded-full bg-white px-6 py-3 text-sm font-semibold text-ink"
            >
              Выбрать устройство ↗
            </Link>
          </div>
          <div className="flex flex-col justify-center gap-0 border-t border-white/15 px-7 py-8 md:border-t-0 md:border-l sm:px-12">
            {[
              "Реальные фотографии",
              "Состояние и следы использования",
              "Аккумулятор и заменённые детали",
              "Комплект и условия гарантии",
            ].map((s, i) => (
              <div
                className="flex gap-6 border-b border-white/15 py-5 text-sm"
                key={s}
              >
                <span className="text-white/40">0{i + 1}</span>
                {s}
              </div>
            ))}
          </div>
        </div>
      </Container>
      <Container className="pb-20">
        <div className="grid items-center gap-8 border-y border-line py-12 md:grid-cols-[1.3fr_1fr]">
          <div>
            <p className="text-xs uppercase tracking-widest text-muted">
              TRADE-IN
            </p>
            <h2 className="mt-4 text-3xl font-semibold tracking-tight sm:text-5xl">
              Старый iPhone —<br />
              часть оплаты нового.
            </h2>
          </div>
          <div>
            <p className="max-w-sm text-sm leading-relaxed text-muted">
              Расскажите о вашем устройстве. Менеджер оценит его, а
              окончательную сумму подтвердит после осмотра.
            </p>
            <div className="mt-6">
              <Button href="/trade-in">Оценить устройство ↗</Button>
            </div>
          </div>
        </div>
      </Container>
      {others.length > 0 && (
        <Container className="pb-20">
          <SectionHeader
            title="Не только iPhone."
            href="/catalog"
            hrefLabel="Все устройства"
          />
          <div className="mt-7 grid grid-cols-2 gap-4 lg:grid-cols-4">
            {others.map((p) => (
              <ProductCard key={p.slug} product={p} />
            ))}
          </div>
        </Container>
      )}
      <Container className="pb-20">
        <SectionHeader title="Как проходит покупка" />
        <div className="mt-8 grid gap-8 sm:grid-cols-3">
          {[
            [
              "Выбираете",
              "Модель, память и цвет. Если сомневаетесь — поможем сравнить.",
            ],
            [
              "Подтверждаем",
              "В Telegram уточняем цену, наличие и удобный способ получения.",
            ],
            [
              "Получаете",
              "Согласовываем выдачу или доставку. Условия оплаты и гарантии — до заказа.",
            ],
          ].map(([title, desc], i) => (
            <div key={title} className="border-t border-line pt-5">
              <p className="text-xs text-muted">0{i + 1}</p>
              <h3 className="mt-5 text-xl font-semibold">{title}</h3>
              <p className="mt-3 text-sm leading-relaxed text-muted">{desc}</p>
            </div>
          ))}
        </div>
      </Container>
      <Container className="pb-20">
        <div className="grid items-center gap-8 overflow-hidden rounded-block bg-[#eeeee8] md:grid-cols-2">
          <div className="relative min-h-80 md:min-h-[480px]">
            <Image
              src="/images/evgeniy-founder.webp"
              alt="Евгений, основатель Evgeniy Apple"
              fill
              sizes="(max-width:768px) 100vw,50vw"
              className="object-cover object-top"
            />
          </div>
          <div className="p-7 md:py-10 md:pr-12">
            <p className="text-xs uppercase tracking-widest text-muted">
              О МАГАЗИНЕ
            </p>
            <h2 className="mt-4 text-3xl font-semibold tracking-tight sm:text-5xl">
              За именем —<br />
              человек.
            </h2>
            <p className="mt-5 text-sm leading-relaxed text-muted">
              Меня зовут Евгений. В моём магазине можно подобрать новую и б/у
              технику Apple, обсудить обмен и договориться о доставке.
            </p>
            <Link
              href="/about"
              className="mt-7 inline-block text-sm font-semibold text-accent"
            >
              Обо мне →
            </Link>
            <a
              href={d.settings.telegramChannel}
              className="ml-5 text-sm text-muted underline underline-offset-4"
            >
              Канал магазина ↗
            </a>
          </div>
        </div>
      </Container>
      <Container className="pb-20">
        <div className="grid gap-3 sm:grid-cols-2">
          {[
            [
              "/repair",
              "Ремонт и обслуживание",
              "Опишите проблему — обсудим диагностику и дальнейшие действия.",
            ],
            [
              "/warranty",
              "Гарантия",
              "Условия для выбранного устройства согласуем перед покупкой.",
            ],
          ].map(([href, title, text]) => (
            <Link
              key={href}
              href={href}
              className="rounded-card border border-line bg-white p-7"
            >
              <h2 className="flex justify-between gap-4 text-xl font-semibold">
                {title}
                <span>↗</span>
              </h2>
              <p className="mt-4 max-w-sm text-sm text-muted">{text}</p>
            </Link>
          ))}
        </div>
      </Container>
      <Container className="pb-20">
        <SectionHeader
          title="Коротко о главном"
          href="/faq"
          hrefLabel="Все вопросы"
        />
        <div className="mt-5 divide-y divide-line">
          {[
            [
              "Как узнать точную цену?",
              "Выберите конфигурацию и нажмите «Уточнить цену». Менеджер подтвердит стоимость и наличие перед заказом.",
            ],
            [
              "Можно ли обменять мой телефон?",
              "Заполните форму Trade-in. Предварительная оценка обсуждается по описанию, окончательная — после осмотра.",
            ],
            [
              "Есть доставка за пределы Минска?",
              "Да, по Беларуси. Стоимость, сроки и способ получения согласовываются с менеджером.",
            ],
          ].map(([q, a]) => (
            <details key={q} className="py-5">
              <summary className="cursor-pointer text-sm font-semibold">
                {q}
              </summary>
              <p className="mt-3 max-w-2xl text-sm leading-relaxed text-muted">
                {a}
              </p>
            </details>
          ))}
        </div>
      </Container>
      <Container className="pb-20">
        <div className="flex flex-wrap items-center justify-between gap-8 border-t border-line pt-10">
          <div>
            <p className="text-xs uppercase tracking-widest text-muted">
              КОНТАКТЫ
            </p>
            <h2 className="mt-3 text-2xl font-semibold">
              {d.settings.address}
            </h2>
            <p className="mt-2 text-sm text-muted">{d.settings.hours}</p>
          </div>
          <Button href="/contacts">Связаться ↗</Button>
        </div>
      </Container>
    </>
  );
}
