import Link from "next/link";
import { DeviceScene } from "@/components/home/DeviceScene";
import { SculpturalHero } from "@/components/home/SculpturalHero";
import { PhoneSculpture } from "@/components/home/PhoneSculpture";
import { EditorialMotion } from "@/components/home/EditorialMotion";
import { EditorialShowcase } from "@/components/home/EditorialShowcase";
import { Container, SectionHeader } from "@/components/ui/primitives";
import { Button } from "@/components/ui/Button";
import { readCatalog, publicCatalog } from "@/lib/catalog-store";
import { productStatus, isSale } from "@/lib/catalog";
import { FeaturedCarousel } from "@/components/carousel/FeaturedCarousel";
import { ProductCard } from "@/components/catalog/ProductCard";
import { ProductImage } from "@/components/catalog/ProductImage";
import { EntryGate } from "@/components/loading/EntryGate";
import { getPresentation } from "@/lib/presentation";
import { SocialProof } from "@/components/social/SocialProof";
import { LocationPanel } from "@/components/location/LocationPanel";

export default async function HomePage() {
  const d = publicCatalog(await readCatalog()), p = getPresentation(d.presentation);
  const featured = d.products.filter(n => n.featuredOnHome && n.subcategory === "iphone" && ["in-stock", "on-order", "request"].includes(productStatus(n)));
  const models = (featured.length ? featured : d.products.filter(n => n.subcategory === "iphone")).slice(0, p.carousel.limit);
  const sales = d.products.filter(n => n.variants.some(v => isSale(v) && ["in-stock", "on-order"].includes(v.status))).slice(0, 4);
  const others = d.products.filter(n => n.subcategory !== "iphone" && !models.some(m => m.slug === n.slug)).slice(0, 4);

  return <><EntryGate /><EditorialMotion>{p.home.filter(b => b.enabled).map(b => {
    const heading = <SectionHeader title={b.title} href={b.ctaLabel ? b.ctaHref : undefined} hrefLabel={b.ctaLabel} />;
    const cta = b.ctaLabel ? <Button href={b.ctaHref}>{b.ctaLabel}</Button> : null;
    let section;
    switch (b.id) {
      case "carousel":
        section = <><SculpturalHero block={b} /><div className="home-carousel"><FeaturedCarousel products={models} /></div></>;
        break;
      case "device-scene": section = <DeviceScene block={b} />; break;
      case "showcase": section = <EditorialShowcase block={b} />; break;
      case "quick-links":
        section = <div className="home-quick-links">{b.items.map((i, n) => <Link key={n} href={i.href || "/catalog"}><span className="home-index">{String(n + 1).padStart(2, "0")}</span><span>{i.title}</span></Link>)}</div>;
        break;
      case "benefits":
        section = <div className="home-benefits">{b.items.map((i, n) => <Link key={n} href={i.href || "/contacts"}><span className="home-index">{String(n + 1).padStart(2, "0")}</span><h2>{i.title}</h2><p>{i.text}</p></Link>)}</div>;
        break;
      case "sale":
        if (!sales.length) return null;
        section = <>{heading}<div className="home-product-grid">{sales.map(n => <ProductCard key={n.slug} product={n} />)}</div></>;
        break;
      case "categories":
        section = <>{heading}<div className="home-category-grid">{d.categories.map((c, i) => <Link key={c.slug} href={"/catalog?category=" + c.slug} className="home-category" data-tilt>
          <div className="home-category-title"><h3>{c.name}</h3><span className="home-index">{String(i + 1).padStart(2, "0")}</span></div>
          <div className="home-category-image"><ProductImage src={c.image || d.products.find(n => n.category === c.slug)?.variants[0]?.images[0]} alt={c.name} sizes="(max-width:640px) 90vw,50vw" className="object-contain" /></div>
          {c.caption && <p>{c.caption}</p>}
        </Link>)}</div></>;
        break;
      case "used":
        section = <div className="home-used"><div className="home-used-copy"><p className="editorial-eyebrow">{b.kicker}</p><h2>{b.title}</h2><p className="editorial-description">{b.body}</p><Link href={b.ctaHref} className="editorial-link">{b.ctaLabel}</Link></div>
          <div className="home-used-details">{b.items.map((i, n) => <div key={n}><span className="home-index">{String(n + 1).padStart(2, "0")}</span><span>{i.title}{i.text && <small>{i.text}</small>}</span></div>)}</div>
        </div>;
        break;
      case "trade-in":
        section = <div className="home-trade-in"><div className="home-trade-copy"><p className="editorial-eyebrow">{b.kicker}</p><h2>{b.title}</h2><p className="editorial-description">{b.body}</p>{cta}</div><div className="home-trade-art"><span className="trade-in-word" aria-hidden="true">TRADE<br />IN.</span><PhoneSculpture compact /></div></div>;
        break;
      case "other-products":
        if (!others.length) return null;
        section = <>{heading}<div className="home-product-grid">{others.map(n => <ProductCard key={n.slug} product={n} />)}</div></>;
        break;
      case "about":
        section = <div className="home-about"><div className="home-about-photo"><ProductImage src={p.brand.founderPhoto} alt={p.brand.founderName + ", основатель магазина"} sizes="(max-width:768px) 100vw,45vw" className="object-cover object-[50%_18%]" /></div>
          <div className="home-about-copy"><p className="editorial-eyebrow">{b.kicker}</p><h2>{b.title}</h2><p className="editorial-description whitespace-pre-line">{b.body}</p><div className="home-about-links"><Link href={b.ctaHref} className="editorial-link">{b.ctaLabel}</Link><a href={d.settings.telegramChannel} className="editorial-link">Канал магазина</a></div></div>
        </div>;
        break;
      case "reviews": section = <SocialProof value={p.socialProof} />; break;
      case "location": section = <LocationPanel value={p.location} compact />; break;
      case "services":
        section = <div className="home-services">{b.items.map((i, n) => <Link key={n} href={i.href || "/contacts"}><span className="home-index">{String(n + 1).padStart(2, "0")}</span><h2>{i.title}</h2><p>{i.text}</p></Link>)}</div>;
        break;
      case "faq":
        section = <div className="home-faq">{heading}<div>{b.items.map((i, n) => <details key={n}><summary>{i.title}</summary><p>{i.text}</p></details>)}</div></div>;
        break;
      case "contacts":
        section = <div className="home-contacts"><div><p className="editorial-eyebrow">{b.kicker}</p><h2>{b.title}</h2><p>{d.settings.address}</p><p className="text-muted">{d.settings.hours}</p>{b.body && <p className="text-muted">{b.body}</p>}</div>{cta}</div>;
        break;
      default:
        section = <>{heading}{b.body && <p className="editorial-description mt-5 whitespace-pre-line">{b.body}</p>}<div className="home-steps">{b.items.map((i, n) => <div key={n}><span className="home-step-number">{String(n + 1).padStart(2, "0")}</span><h3>{i.title}</h3><p>{i.text}</p>{i.href && <Link className="editorial-link" href={i.href}>Подробнее</Link>}</div>)}</div></>;
    }
    return <Container key={b.id} className={"home-section home-section-" + b.id}><section data-home-block={b.id}>{section}</section></Container>;
  })}</EditorialMotion></>;
}
