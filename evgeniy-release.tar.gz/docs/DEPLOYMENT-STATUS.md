# Deployment status — 2026-10-02

The complete tested source includes the site editor, Telegram source archive and continuous carousel with mouse dragging. Lint, TypeScript, production build and 33 browser/API scenarios passed.

Repository: hryharenkauladzislau/objective-store, branch design-prototype. Deployment packaging uses evgeniy-release.tar.gz, Dockerfile, railway.json and RELEASE.md. The Docker build uses the archive, not older prototype files at the repository root.

Railway project evgeniy-apple: f1e6ade6-7968-4558-8870-eb8b71b0a06b. No application is deployed yet. User authorized Railway GitHub installation for objective-store. GitHub now requires Confirm access with GitHub Mobile or email before finalizing installation.

After verification: connect design-prototype, add PostgreSQL and DATABASE_URL, set admin credentials via Railway Variables, deploy and verify domain/health/admin/persistence. Never use another customer's credentials.
