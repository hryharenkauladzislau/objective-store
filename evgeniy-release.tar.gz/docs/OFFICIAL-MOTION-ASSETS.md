# Official iPhone footage — 2026-10-03

The hand-built CSS phone was removed. Device geometry, camera layout and colours in the new films are genuine Apple product footage. No generated or reconstructed iPhone is used.

Source page: https://www.apple.com/lt/iphone-17-pro/

- Design: https://www.apple.com/105/media/us/iphone-17-pro/2025/704d4474-8e63-4ce7-9917-bb47b1ca4ba0/anim/highlights-design/large.mp4
- Aluminium unibody: https://www.apple.com/105/media/us/iphone-17-pro/2025/704d4474-8e63-4ce7-9917-bb47b1ca4ba0/anim/design/large.mp4

Public source URLs returned HTTP 200. Locally served, cropped/optimised H.264 MP4 files are 192 KB and 294 KB. Short forward/reverse loops use original frames only, without geometry alteration. Poster images are extracted from these same files. Audio is removed.

These MP4 sources have a black background, not an alpha channel. CSS screen blending on the merchant's dark canvas removes the visible black rectangle; this is not a claim of true transparent video. No chroma-key erosion of the device is used.

Visibility-aware playback stops outside the viewport and when the tab is hidden; reduced-motion and autoplay failure retain a static poster. Public availability does not constitute a commercial-use licence: the merchant should confirm applicable permission for branded advertising footage before its commercial use. No third-party 3D model was added.

## iPhone 18 Pro update — 2026-10-03

The default hero now uses genuine iPhone 18 Pro footage showing Black, Silver, Glacier and Burgundy, replacing iPhone 17 Pro. Source page: https://www.apple.com/iphone-18-pro/

- Colours: https://www.apple.com/105/media/us/iphone-18-pro/2026/591df885-5ee2-4173-86e6-401021249f7c/anim/highlights-colors/large.mp4
- Burgundy camera macro: https://www.apple.com/105/media/us/iphone-18-pro/2026/591df885-5ee2-4173-86e6-401021249f7c/anim/hero/large.mp4

Both retrieved HTTP 200. Optimized local clips total approximately 249 KB, H.264, 20fps, muted; posters are real extracted frames. Colour footage is cropped to remove unused black margins, then loops forward/reverse. Custom merchant images are preserved; saved built-in iPhone 17 scene media upgrades to 18. No catalog models, stock, prices or product photography are relabelled as 18.
