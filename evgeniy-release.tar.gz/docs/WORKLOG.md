# EVGENIY APPLE — выполненная реализация

Дата: 02.10.2026. Основа: ветка design-prototype, 6daaf23.

- Завершены карточка/галерея/конфигуратор, сравнение, каталог с URL-фильтрами, служебные страницы и реальные контакты.
- Шапка, карусель, входной выбор услуг, прелоадер, фото владельца и адаптив соответствуют обсуждённой структуре.
- Реализовано хранилище PostgreSQL и файловый режим, защита админки, загрузка фото и импорт/экспорт Excel по SKU.
- Категории создаются, переименовываются, перемещаются, скрываются и восстанавливаются; подкатегории необязательны. Их удаление сбрасывает привязки товара, не удаляя товары.
- Таблица цен фильтруется по категориям, подкатегориям, модели/SKU и скидкам. SALE использует действительную новую цену и более высокую старую, виден в каталоге и карточке. Специальные предложения на главной появляются только при наличии реальных скидок.
- Trade-in: 22 опубликованных максимальных оценки iStock в RUB, источник/дата/признак утверждения. Менеджер редактирует прайс, валюту, память и утверждает свои цены. Сторонние данные не выдаются за обещание магазина. Для повреждённых устройств автоматической суммы нет.
- В публичном API нет исходной базовой цены и коэффициента продавца. Добавлены healthcheck и конфигурация Railway.
- Обработаны повреждённые значения сравнения в браузере; состояние обновляется между страницами и вкладками.
- TypeScript, ESLint и production build проходят. Интеграционные/браузерные сценарии проверяют категории, SALE, Trade-in, Excel, фото, ревизии, Telegram-ссылки и мобильную админку.

Запуск остаётся зависим от доступа для загрузки в Railway. Подготовлен отдельный проект evgeniy-apple; приложение пока не опубликовано. Подключение GitHub возвращает 403 при записи. Пакет исходников и патч позволяют перенести все коммиты.

Перед боевым показом владелец подтверждает наличие, цены, логотип и условия обслуживания. Фактическая отправка заявки в Telegram и production PostgreSQL проверяются после развёртывания. Полная Mini App, эквайринг и CRM не входят в текущую поставку.

## Редактор сайта и карусель — 02.10.2026

- В админке «Сайт»: порядок/видимость блоков, тексты, кнопки, меню, цвета, логотип и фото владельца, выбор услуги, загрузка, карусель, подвал и SEO. Произвольные внешние ссылки в меню и неподдерживаемые пути фото отклоняются. Старые документы совместимы с настройками по умолчанию.
- Карусель продолжает движение при наведении. Добавлены ручное перетаскивание мышью, стрелки и отдельная кнопка паузы; после ручного листания движение возобновляется. Системный reduced motion отключает автоматическое движение.
- По первичному материалу Telegram обновлены график, доставка, подарки и условия Б/У. Прайс от 05.08.2025 (93 позиции) сохранён как архив в «Данные канала»; он не используется как актуальная цена/наличие. Более свежий проверяемый прайс не найден.
- Пройдены 33 сценария scripts/check.mjs, lint, TypeScript и production build. Проверено сохранение редактора, порядок/видимость/цвета/меню, мобильная админка, движение при наведении, drag, стрелки, пауза и reduced motion.
- Railway GitHub app: разрешение дано пользователем для objective-store; установка остановилась на GitHub Confirm access (Mobile либо email). До подтверждения приложение не развёрнуто.

## 2026-10-02 — Final customer revision
- Dark charcoal/gold storefront and admin; legacy default light theme migrates on read while retaining custom settings/data.
- Telegram product, service and Trade-in drafts contain no website/source URLs. Removed copy-request fallback and instructional CTA text.
- Trade-in shows only approved merchant rates in BYN/USD; Russian research prices remain internal archive, without public amount or source links.
- Visible mobile “Задать вопрос” contact dock; clean card/social/service labels without decorative arrows; gallery uses thumbnails/swipe/keyboard, carousel uses drag/keyboard and explicit pause.
- Equal-width/equal-height comparison product headers; variant selection falls back to an available configuration when changing memory or color.
- TXT price export/import: one variant per line, stable SKU, last number is USD price. Preview before apply, authenticated endpoint, strict validation, duplicate/unknown SKU rejection and revision checks. Changes affect only the chosen variants, keep products grouped and preserve absent variants.
- Validation: lint, TypeScript and production build passed; 39 browser/API scenarios over 18 routes passed in Chromium, no browser runtime errors.

## 2026-10-03 — black canvas, readable services and Trade-in configuration
- Black canvas replaces the old green-tinted default, with neutral surfaces and borders; saved custom accents and unrelated content are retained. All interface tracking is zero.
- Larger logo, navigation, contacts and header; desktop intermediate widths use a second navigation row rather than clipping eight links.
- Shipping, warranty and repair use the full content width, larger typography and responsive service panels.
- Trade-in target model, memory, colour and SIM derive from the public catalog. Changing a parent selection clears dependent fields; out-of-stock variants cannot be requested. Selected configuration and price are carried into the link-free manager draft. Help choosing a phone remains available.
- Real iPhone 17 Pro imagery replaces built-in older concept placeholders in the device study. Merchant-uploaded images remain editable and unchanged. Prior offscreen animation optimizations are retained.
- Lint, TypeScript, production build and 17 API regression groups passed. Live UI verification follows deployment.
