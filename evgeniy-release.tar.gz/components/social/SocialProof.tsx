import type { Presentation } from "@/lib/presentation";
import { SocialIcon } from "@/components/layout/ContactLinks";

export function SocialProof({ value }: { value: Presentation["socialProof"] }) {
  return (
    <div className="social-proof overflow-hidden rounded-block border border-line bg-surface text-ink">
      <div className="grid gap-8 p-7 sm:p-10 lg:grid-cols-[.9fr_1.1fr]">
        <div>
          <p className="text-xs uppercase tracking-[.2em] text-ink/50">ДОВЕРИЕ БЕЗ ПОСТАНОВКИ</p>
          <h2 className="mt-4 text-3xl font-semibold tracking-tight sm:text-5xl">{value.title}</h2>
          <p className="mt-5 max-w-md text-sm leading-relaxed text-ink/65">{value.intro}</p>
          <div className="mt-8 flex flex-wrap gap-3">
            <a className="inline-flex items-center gap-2 rounded-full bg-surface px-5 py-3 text-sm font-semibold text-ink" href={value.instagramUrl} target="_blank" rel="noopener noreferrer"><SocialIcon network="instagram" />Instagram</a>
            <a className="rounded-full border border-ink/25 px-5 py-3 text-sm" href={value.yandexUrl} target="_blank" rel="noopener noreferrer">Локация на Яндекс Картах</a>
          </div>
        </div>
        {value.reviews.length ? (
          <div className="flex snap-x gap-4 overflow-x-auto pb-3">
            {value.reviews.map((review, index) => (
              <a key={index} href={review.url} target="_blank" rel="noopener noreferrer" className="min-w-[280px] snap-start rounded-card bg-ink/5 p-6 ring-1 ring-ink/12 sm:min-w-[330px]">
                <div className="flex items-center justify-between text-xs text-ink/45"><span>{review.source === "yandex" ? "ЯНДЕКС" : "INSTAGRAM"}</span><span>{review.date}</span></div>
                {review.rating && <p className="mt-4 tracking-[.2em] text-signal">{"★".repeat(review.rating)}</p>}
                <blockquote className="mt-4 text-sm leading-relaxed text-ink/85">«{review.text}»</blockquote>
                <p className="mt-5 text-sm font-semibold">{review.author}</p>
              </a>
            ))}
          </div>
        ) : (
          <div className="grid content-center gap-3 sm:grid-cols-2">
            <a href={value.instagramUrl} target="_blank" rel="noopener noreferrer" className="rounded-card bg-ink/5 p-6 ring-1 ring-ink/12"><span className="inline-flex items-center gap-2 text-xs text-ink/55"><SocialIcon network="instagram" className="h-5 w-5" /> INSTAGRAM</span><p className="mt-8 text-xl font-semibold">Распаковки, отметки и реальные покупки</p><span className="mt-6 block text-sm text-ink/60">Открыть профиль</span></a>
            <a href={value.yandexUrl} target="_blank" rel="noopener noreferrer" className="rounded-card bg-ink/5 p-6 ring-1 ring-ink/12"><span className="text-xs text-ink/45">ЯНДЕКС КАРТЫ</span><p className="mt-8 text-xl font-semibold">БЦ «Аякс» · Могилёвская, 1</p><span className="mt-6 block text-sm text-ink/60">Посмотреть локацию</span></a>
          </div>
        )}
      </div>
    </div>
  );
}
