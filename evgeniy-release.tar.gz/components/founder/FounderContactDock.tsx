"use client";
import { useSite } from "@/components/layout/SiteProvider";
import { usePathname } from "next/navigation";
import { ProductImage } from "@/components/catalog/ProductImage";

/*
 * Фиксированная кнопка связи (личный бренд владельца) — единственная плавающая
 * точка входа (ТЗ §8). Пока ссылка Telegram не предоставлена, ведёт на страницу
 * контактов вместо нерабочего адреса; после заполнения lib/site.ts
 * автоматически переключается на Telegram.
 */
export function FounderContactDock() {
  const SITE = useSite();
  const pathname = usePathname();
  if (pathname.startsWith("/admin") || !SITE.presentation.dock.enabled) return null;
  const href = SITE.telegramUrl ?? "/contacts?topic=question";
  const isExternal = SITE.telegramUrl !== null;

  return (
    <a
      href={href}
      {...(isExternal ? { target: "_blank", rel: "noopener noreferrer" } : {})}
      aria-label="Задать вопрос"
      className={
        "fixed bottom-4 right-4 z-50 items-center gap-2.5 rounded-full border border-line bg-surface p-1.5 pr-4 shadow-card transition-colors duration-200 hover:border-ink/25 " +
        (/^\/(catalog|used)\//.test(pathname) ? "hidden md:flex" : "flex")
      }
      style={{
        paddingBottom: "max(0.375rem, env(safe-area-inset-bottom) * 0.4)",
      }}
    >
      <span className="relative h-10 w-10 shrink-0 overflow-hidden rounded-full bg-tint ring-1 ring-accent/20">
        <ProductImage
          src={SITE.presentation.brand.founderPhoto}
          alt="Евгений"
          sizes="40px"
          className="object-cover object-[64%_37%]"
        />
        <span
          aria-hidden="true"
          className="absolute -bottom-0.5 -right-0.5 h-2.5 w-2.5 rounded-full border-2 border-surface bg-accent"
        />
      </span>
      <span className="text-sm font-semibold">
        {SITE.presentation.dock.label}
      </span>
    </a>
  );
}
