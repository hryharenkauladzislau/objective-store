"use client";
import { useSite } from "@/components/layout/SiteProvider";
import { usePathname } from "next/navigation";

/*
 * Фиксированная кнопка связи (личный бренд владельца) — единственная плавающая
 * точка входа (ТЗ §8). Пока ссылка Telegram не предоставлена, ведёт на страницу
 * контактов вместо нерабочего адреса; после заполнения lib/site.ts
 * автоматически переключается на Telegram.
 */
export function FounderContactDock() {
  const SITE = useSite();
  const pathname = usePathname();
  if (pathname.startsWith("/admin") || !SITE.presentation.dock.enabled) return null;
  const href = SITE.telegramUrl ?? "/contacts?topic=question";
  const isExternal = SITE.telegramUrl !== null;

  return (
    <a
      href={href}
      {...(isExternal ? { target: "_blank", rel: "noopener noreferrer" } : {})}
      aria-label={`Задать вопрос — ${SITE.telegramLabel} или страница контактов`}
      className={
        "fixed bottom-4 right-4 z-50 items-center gap-2.5 rounded-full border border-line bg-surface p-1.5 sm:pr-4 shadow-card transition-colors duration-200 hover:border-ink/25 " +
        (/^\/(catalog|used)\//.test(pathname) ? "hidden md:flex" : "flex")
      }
      style={{
        paddingBottom: "max(0.375rem, env(safe-area-inset-bottom) * 0.4)",
      }}
    >
      <span className="relative shrink-0">
        <span
          className="flex h-[34px] w-[34px] items-center justify-center rounded-full bg-tint text-accent"
          aria-hidden="true"
        >
          ↗
        </span>
        <span
          aria-hidden="true"
          className="absolute -bottom-0.5 -right-0.5 h-2.5 w-2.5 rounded-full border-2 border-surface bg-accent"
        />
      </span>
      <span className="hidden text-sm font-semibold sm:inline">
        {SITE.presentation.dock.label}
      </span>
    </a>
  );
}
