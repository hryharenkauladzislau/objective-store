"use client";
import { useEffect, useRef, useState } from "react";
import type { Product } from "@/lib/catalog";
import { ProductCard } from "@/components/catalog/ProductCard";
import { usePresentation } from "@/components/layout/SiteProvider";
export function FeaturedCarousel({ products }: { products: Product[] }) {
 const config = usePresentation().carousel;
 const view = useRef<HTMLDivElement>(null);
 const [paused,setPaused] = useState(false);
 const interactionUntil = useRef(0);
 const pointer = useRef<{id:number;x:number;scroll:number;moved:boolean} | null>(null);
 const suppressClick = useRef(false);
 const loop = products.length >= 4;
 useEffect(() => {
  const desktop = matchMedia("(min-width:1024px)");
  const reduced = matchMedia("(prefers-reduced-motion:reduce)");
  let frame = 0, last = performance.now(), position = view.current?.scrollLeft || 0;
  const tick = (now:number) => {
   const el = view.current;
   if(el && loop && desktop.matches && !reduced.matches && config.autoplay && !paused && !document.hidden && !pointer.current?.moved && now > interactionUntil.current) {
    // Keep sub-pixel progress: scrollLeft is rounded in some browsers.
    if(Math.abs(el.scrollLeft-position)>3) position=el.scrollLeft;
    position += Math.min(50,now-last)*config.speed/1000;
    const stride=el.querySelector<HTMLElement>("[data-loop-start]")?.offsetLeft || el.scrollWidth/2;
    if(position>=stride)position-=stride;
    el.scrollLeft=position;
   } else if(el) position=el.scrollLeft;
   last=now;frame=requestAnimationFrame(tick);
  };
  frame=requestAnimationFrame(tick);return()=>cancelAnimationFrame(frame);
 },[paused,loop,config.autoplay,config.speed]);
 const move=(direction:number)=>{
  const el=view.current;if(!el)return;
  const stride=el.querySelector<HTMLElement>("[data-loop-start]")?.offsetLeft || 0;
  if(loop && direction<0 && el.scrollLeft<300 && matchMedia("(min-width:1024px)").matches)el.scrollLeft+=stride;
  interactionUntil.current=performance.now()+500;
  el.scrollBy({left:direction*((el.querySelector<HTMLElement>('[data-card]')?.offsetWidth || 280)+16),behavior:matchMedia("(prefers-reduced-motion:reduce)").matches?"instant":"smooth"});
 };
 if(!products.length)return <p className="py-8 text-muted">Доступные модели появятся после обновления наличия.</p>;
 return <section aria-label="Карусель моделей">
  <div className="mb-4 flex items-center justify-end gap-3">{products.length>1 && <div className="flex shrink-0 gap-2">{loop && config.autoplay && <button className="round-action" aria-label={paused?"Запустить карусель":"Остановить карусель"} onClick={()=>setPaused(!paused)}>{paused?"▶":"Ⅱ"}</button>}</div>}</div>
  <div ref={view} data-carousel="true" className="carousel-view cursor-grab active:cursor-grabbing" tabIndex={0}
   onKeyDown={e=>{if(e.key==="ArrowLeft" || e.key==="ArrowRight"){e.preventDefault();move(e.key==="ArrowRight"?1:-1);}}}
   onWheel={()=>{interactionUntil.current=performance.now()+700;}}
   onPointerDown={e=>{if(e.pointerType!=="mouse" || e.button!==0)return;suppressClick.current=false;pointer.current={id:e.pointerId,x:e.clientX,scroll:e.currentTarget.scrollLeft,moved:false};}}
   onPointerMove={e=>{const p=pointer.current;if(!p || p.id!==e.pointerId)return;const delta=e.clientX-p.x;if(Math.abs(delta)>5 && !p.moved){p.moved=true;suppressClick.current=true;e.currentTarget.setPointerCapture(e.pointerId);}if(p.moved){e.preventDefault();e.currentTarget.scrollLeft=p.scroll-delta;interactionUntil.current=performance.now()+700;}}}
   onPointerUp={e=>{if(e.currentTarget.hasPointerCapture(e.pointerId))e.currentTarget.releasePointerCapture(e.pointerId);pointer.current=null;}}
   onPointerCancel={()=>{pointer.current=null;}}
   onPointerLeave={()=>{if(!pointer.current?.moved)pointer.current=null;}}
   onClickCapture={e=>{if(suppressClick.current){e.preventDefault();e.stopPropagation();suppressClick.current=false;}}}
   onDragStart={e=>e.preventDefault()}
  ><div className="carousel-track relative flex w-max gap-4">
   {(loop?[...products,...products]:products).map((p,i)=><div data-card key={p.slug+"-"+i} data-loop-start={i===products.length?true:undefined} className={"carousel-card shrink-0 snap-start transition-transform "+(config.zoomOnHover?"carousel-card-zoom ":"")+(i>=products.length?"hidden lg:block":"")} aria-hidden={i>=products.length?true:undefined}><ProductCard product={p} priority={i===0} tabIndex={i>=products.length?-1:undefined}/></div>)}
  </div></div>
 </section>;
}
