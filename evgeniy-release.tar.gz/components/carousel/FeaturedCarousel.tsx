"use client";
import { useEffect, useRef, useState } from "react";
import type { Product } from "@/lib/catalog";
import { ProductCard } from "@/components/catalog/ProductCard";
export function FeaturedCarousel({ products }: { products: Product[] }) {
  const view = useRef<HTMLDivElement>(null);
  const hovering = useRef(false);
  const [paused, setPaused] = useState(false);
  const loop = products.length >= 4;
  useEffect(() => {
    const mq = matchMedia("(min-width:1024px)");
    const reduced = matchMedia("(prefers-reduced-motion:reduce)");
    let frame = 0;
    let last = performance.now();
    const tick = (now: number) => {
      const el = view.current;
      if (
        el &&
        loop &&
        mq.matches &&
        !reduced.matches &&
        !paused &&
        !hovering.current &&
        !document.hidden
      ) {
        el.scrollLeft += Math.min(50, now - last) * 0.04;
        const half =
          el.querySelector<HTMLElement>("[data-loop-start]")?.offsetLeft ||
          el.scrollWidth / 2;
        if (el.scrollLeft >= half) el.scrollLeft -= half;
      }
      last = now;
      frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [paused, loop]);
  const move = (n: number) => {
    setPaused(true);
    view.current?.scrollBy({
      left: n * 300,
      behavior: matchMedia("(prefers-reduced-motion:reduce)").matches
        ? "instant"
        : "smooth",
    });
  };
  if (!products.length)
    return (
      <p className="py-8 text-muted">
        Доступные модели появятся после обновления наличия.
      </p>
    );
  return (
    <section aria-label="Карусель моделей">
      <div className="mb-4 flex items-center justify-between gap-3">
        <span className="text-xs text-muted">
          Свайпайте или выбирайте модель
        </span>
        {products.length > 1 && (
          <div className="flex gap-2">
            {loop && (
              <button
                className="round-action"
                aria-label={
                  paused ? "Запустить карусель" : "Остановить карусель"
                }
                onClick={() => setPaused(!paused)}
              >
                {paused ? "▶" : "Ⅱ"}
              </button>
            )}
            <button
              className="round-action"
              aria-label="Предыдущие модели"
              onClick={() => move(-1)}
            >
              ←
            </button>
            <button
              className="round-action"
              aria-label="Следующие модели"
              onClick={() => move(1)}
            >
              →
            </button>
          </div>
        )}
      </div>
      <div
        ref={view}
        data-carousel="true"
        className="carousel-view"
        onMouseEnter={() => (hovering.current = true)}
        onMouseLeave={() => (hovering.current = false)}
        onFocusCapture={() => setPaused(true)}
        onPointerDown={() => setPaused(true)}
        onWheel={() => setPaused(true)}
      >
        <div className="relative flex w-max gap-4 py-3">
          {(loop ? [...products, ...products] : products).map((p, i) => (
            <div
              key={p.slug + "-" + i}
              data-loop-start={i === products.length ? true : undefined}
              className={
                "w-[250px] shrink-0 snap-start transition-transform hover:scale-[1.04] sm:w-[280px] " +
                (i >= products.length ? "hidden lg:block" : "")
              }
              aria-hidden={i >= products.length ? true : undefined}
            >
              <ProductCard
                product={p}
                priority={i === 0}
                tabIndex={i >= products.length ? -1 : undefined}
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
