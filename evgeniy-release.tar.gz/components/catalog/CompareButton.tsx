"use client";
import { useState } from "react";
import Link from "next/link";
import { track } from "@/lib/telegram";
import {
  useCompareList,
  readCompareList,
  writeCompareList,
} from "@/lib/compare";
export function CompareButton({ slug }: { slug: string }) {
  const selected = useCompareList().includes(slug);
  const [message, setMessage] = useState("");
  const toggle = () => {
    try {
      const list = readCompareList();
      if (!list.includes(slug) && list.length >= 3) {
        setMessage("Можно сравнить до трёх моделей");
        return;
      }
      writeCompareList(
        list.includes(slug) ? list.filter((s) => s !== slug) : [...list, slug],
      );
      track("compare_add", { slug });
      setMessage("");
    } catch {
      setMessage("Разрешите сохранение в браузере");
    }
  };
  return (
    <div className="mt-4">
      <button
        className="text-sm font-medium text-accent"
        aria-pressed={selected}
        onClick={toggle}
      >
        {selected ? "✓ В сравнении" : "＋ Сравнить"}
      </button>
      {selected && (
        <Link
          className="ml-4 text-sm underline underline-offset-4"
          href="/compare"
        >
          Открыть сравнение
        </Link>
      )}
      {message && (
        <p role="status" className="mt-2 text-xs text-muted">
          {message}
        </p>
      )}
    </div>
  );
}
