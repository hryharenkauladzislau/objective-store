"use client";
import Image from "next/image";
import { useState } from "react";
export function ProductImage({
  src,
  alt,
  priority = false,
  sizes = "50vw",
  className = "",
}: {
  src?: string;
  alt: string;
  priority?: boolean;
  sizes?: string;
  className?: string;
}) {
  const [failed, setFailed] = useState<string>();
  const [loaded, setLoaded] = useState<string>();
  if (!src || failed === src)
    return (
      <div className="absolute inset-0 flex items-center justify-center bg-canvas text-muted">
        <span className="text-sm">Фото уточняется</span>
      </div>
    );
  return (
    <>
      {loaded !== src && (
        <div
          className="absolute inset-0 animate-pulse bg-line/30"
          aria-hidden="true"
        />
      )}
      <Image
        src={src}
        alt={alt}
        fill
        sizes={sizes}
        preload={priority}
        unoptimized={src.startsWith("/api/")}
        className={className}
        onError={() => setFailed(src)}
        onLoad={() => setLoaded(src)}
        data-boot-critical={priority ? "true" : undefined}
      />
    </>
  );
}
