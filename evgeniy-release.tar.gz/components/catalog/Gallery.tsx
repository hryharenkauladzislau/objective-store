"use client";
import { useState } from "react";
import { ProductImage } from "./ProductImage";
export function Gallery({ images, name }: { images: string[]; name: string }) {
  const [index, setIndex] = useState(0);
  const current = Math.min(index, Math.max(0, images.length - 1));
  const next = (n: number) =>
    setIndex((current + n + images.length) % images.length);
  return (
    <div>
      <div className="relative aspect-square overflow-hidden rounded-block border border-line bg-white">
        <ProductImage
          key={images[current]}
          src={images[current]}
          alt={`${name} — фото ${current + 1}`}
          priority
          className="object-contain p-4"
        />
        {images.length > 1 && (
          <div className="absolute inset-x-3 top-1/2 flex justify-between">
            <button
              aria-label="Предыдущее фото"
              className="round-action"
              onClick={() => next(-1)}
            >
              ←
            </button>
            <button
              aria-label="Следующее фото"
              className="round-action"
              onClick={() => next(1)}
            >
              →
            </button>
          </div>
        )}
      </div>
      <div className="mt-3 flex gap-2 overflow-x-auto">
        {images.map((src, i) => (
          <button
            key={`${src}-${i}`}
            aria-label={`Фото ${i + 1}`}
            aria-pressed={i === current}
            onClick={() => setIndex(i)}
            className={`relative h-16 w-16 shrink-0 overflow-hidden rounded-xl border bg-white ${i === current ? "border-accent ring-1 ring-accent" : "border-line"}`}
          >
            <ProductImage
              src={src}
              alt={`${name} — миниатюра ${i + 1}`}
              sizes="64px"
              className="object-contain"
            />
          </button>
        ))}
      </div>
    </div>
  );
}
