"use client";
import { useRef, useState } from "react";
import { ProductImage } from "./ProductImage";
export function Gallery({ images, name }: { images: string[]; name: string }) {
  const [index, setIndex] = useState(0);
  const touchX = useRef<number | null>(null);
  const current = Math.min(index, Math.max(0, images.length - 1));
  const next = (n: number) =>
    setIndex((current + n + images.length) % images.length);
  return (
    <div>
      <div className="relative aspect-square overflow-hidden rounded-block border border-line bg-surface"
        role="group" aria-label="Фотографии товара" tabIndex={images.length > 1 ? 0 : undefined}
        onKeyDown={(e) => { if (images.length > 1 && (e.key === "ArrowLeft" || e.key === "ArrowRight")) { e.preventDefault(); next(e.key === "ArrowRight" ? 1 : -1); } }}
        onTouchStart={(e) => { touchX.current = e.touches[0].clientX; }}
        onTouchEnd={(e) => { if (touchX.current !== null && images.length > 1) { const delta = e.changedTouches[0].clientX - touchX.current; if (Math.abs(delta) > 40) next(delta < 0 ? 1 : -1); } touchX.current = null; }}
      >
        <ProductImage
          key={images[current]}
          src={images[current]}
          alt={`${name} — фото ${current + 1}`}
          priority
          className="object-contain p-4"
        />

      </div>
      <div className="mt-3 flex gap-2 overflow-x-auto">
        {images.map((src, i) => (
          <button
            key={`${src}-${i}`}
            aria-label={`Фото ${i + 1}`}
            aria-pressed={i === current}
            onClick={() => setIndex(i)}
            className={`relative h-16 w-16 shrink-0 overflow-hidden rounded-xl border bg-surface ${i === current ? "border-accent ring-1 ring-accent" : "border-line"}`}
          >
            <ProductImage
              src={src}
              alt={`${name} — миниатюра ${i + 1}`}
              sizes="64px"
              className="object-contain"
            />
          </button>
        ))}
      </div>
    </div>
  );
}
