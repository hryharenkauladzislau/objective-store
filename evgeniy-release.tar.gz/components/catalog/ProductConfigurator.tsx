"use client";
import { useState } from "react";
import type { Product, Variant } from "@/lib/catalog";
import { formatPrice, variantPrice, isSale } from "@/lib/catalog";
import { PriceDisplay } from "./PriceDisplay";
import { Gallery } from "./Gallery";
import { StatusBadge } from "@/components/ui/primitives";
import { TelegramRequest } from "./TelegramRequest";
import { CompareButton } from "./CompareButton";
import { track } from "@/lib/telegram";
import { PurchaseBar } from "./PurchaseBar";
const memory = (v: number | null) =>
  v === null ? "Стандарт" : v >= 1024 ? v / 1024 + " ТБ" : v + " ГБ";
export function ProductConfigurator({ product }: { product: Product }) {
  const [sku, setSku] = useState(
    product.variants.find((v) => v.status === "in-stock")?.sku ||
      product.variants[0].sku,
  );
  const v = product.variants.find((x) => x.sku === sku) || product.variants[0];
  const select = (n: Variant) => {
    setSku(n.sku);
    track("variant_select", { slug: product.slug, sku: n.sku });
  };
  const price = variantPrice(v);
  const request = [
    "Здравствуйте! Хочу купить товар: " + product.name + ".",
    v.storageGb ? "Память: " + memory(v.storageGb) : "",
    "Цвет: " + v.colorName,
    "Версия: " + v.sim,
    "Артикул: " + v.sku,
    price === null
      ? "Цена от: по запросу. Подскажите актуальную цену и наличие."
      : "Цена от: " + formatPrice(price) + ". Подтвердите цену и наличие.",
    "Товар: /catalog/" + product.slug,
  ]
    .filter(Boolean)
    .join("\n");
  const groups: [
    string,
    keyof Pick<Variant, "storageGb" | "colorName" | "sim">,
  ][] = [
    ["Память", "storageGb"],
    ["Цвет", "colorName"],
    ["Версия", "sim"],
  ];
  return (
    <>
      <PurchaseBar
        text={request}
        price={price === null ? "По запросу" : formatPrice(price)}
        label={
          v.status === "out"
            ? "Уточнить наличие"
            : price === null
              ? "Уточнить цену"
              : "Купить"
        }
      />
      <div className="mt-8 grid items-start gap-8 lg:grid-cols-2 lg:gap-16">
        <Gallery
          key={v.sku}
          images={v.images}
          name={product.name + " " + v.colorName}
        />
        <div>
          <div className="flex items-center gap-3">
            <StatusBadge status={v.status} />
            {isSale(v) && (
              <span className="rounded-full bg-red-700 px-3 py-1 text-xs font-semibold text-white">
                SALE
              </span>
            )}
          </div>
          <h1 className="mt-4 text-4xl font-semibold tracking-tight lg:text-5xl">
            {product.name}
          </h1>
          <p className="mt-3 text-muted">{product.tagline}</p>
          {groups.map(([label, key]) => {
            const options = [...new Set(product.variants.map((x) => x[key]))];
            if (
              options.length === 1 &&
              key === "storageGb" &&
              options[0] === null
            )
              return null;
            return (
              <fieldset key={key} className="mt-7">
                <legend className="mb-3 text-xs uppercase tracking-widest text-muted">
                  {label}
                </legend>
                <div className="flex flex-wrap gap-2">
                  {options.map((o) => {
                    const exact = product.variants.find(
                      (n) =>
                        n[key] === o &&
                        (["storageGb", "colorName", "sim"] as const)
                          .filter((k) => k !== key)
                          .every((k) => n[k] === v[k]),
                    );
                    return (
                      <button
                        key={String(o)}
                        disabled={!exact}
                        title={!exact ? "Такого сочетания нет" : undefined}
                        aria-pressed={v[key] === o}
                        onClick={() => exact && select(exact)}
                        className={
                          "flex min-h-11 items-center gap-2 rounded-xl border px-4 text-sm disabled:opacity-30 " +
                          (v[key] === o
                            ? "border-accent bg-tint"
                            : "border-line bg-white")
                        }
                      >
                        {key === "colorName" && (
                          <span
                            className="h-4 w-4 rounded-full border border-black/10"
                            style={{
                              backgroundColor: product.variants.find(
                                (n) => n[key] === o,
                              )?.colorHex,
                            }}
                          />
                        )}
                        {key === "storageGb"
                          ? memory(o as number | null)
                          : String(o)}
                      </button>
                    );
                  })}
                </div>
              </fieldset>
            );
          })}
          <p className="mt-8 text-3xl font-semibold tabular-nums">
            <PriceDisplay price={price} variant={v} />
          </p>
          <div className="mt-5">
            <TelegramRequest
              text={request}
              label={
                v.status === "out"
                  ? "Уточнить поступление"
                  : price === null
                    ? "Уточнить цену"
                    : "Купить"
              }
            />
          </div>
          <CompareButton slug={product.slug} />
          <p className="mt-6 border-t border-line pt-4 text-xs text-muted">
            Цена и наличие подтверждаются перед заказом. Доставка по Минску и
            Беларуси.
          </p>
        </div>
      </div>
      <section className="mt-16">
        <h2 className="text-2xl font-semibold">Все конфигурации</h2>
        <div className="mt-5 overflow-x-auto rounded-card border border-line bg-white">
          <table className="w-full min-w-[640px] text-left text-sm">
            <thead className="bg-canvas text-muted">
              <tr>
                {["Память", "Цвет", "Версия", "Наличие", "Цена", ""].map(
                  (x, i) => (
                    <th className="p-4 font-medium" key={i}>
                      {x}
                    </th>
                  ),
                )}
              </tr>
            </thead>
            <tbody>
              {product.variants.map((n) => (
                <tr
                  className={
                    "border-t border-line " +
                    (sku === n.sku ? "bg-tint/50" : "")
                  }
                  key={n.sku}
                >
                  <td className="p-4">{memory(n.storageGb)}</td>
                  <td>{n.colorName}</td>
                  <td>{n.sim}</td>
                  <td>
                    <StatusBadge status={n.status} />
                  </td>
                  <td>
                    <PriceDisplay price={variantPrice(n)} variant={n} />
                  </td>
                  <td className="pr-4">
                    <button
                      className="text-accent underline underline-offset-4"
                      onClick={() => {
                        select(n);
                        window.scrollTo({ top: 0, behavior: "smooth" });
                      }}
                    >
                      Выбрать
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </>
  );
}
