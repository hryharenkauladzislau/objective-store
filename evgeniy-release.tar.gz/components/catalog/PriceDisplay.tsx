import { formatPrice, type Variant } from "@/lib/catalog";
export function PriceDisplay({
  price,
  variant,
  from = false,
  oldPrice,
}: {
  price: number | null;
  variant?: Variant;
  from?: boolean;
  oldPrice?: number | null;
}) {
  const previous = oldPrice ?? variant?.oldPriceUsd;
  const sale = price !== null && previous != null && previous > price;
  return (
    <span className="inline-flex flex-wrap items-baseline gap-x-2 gap-y-1 tabular-nums">
      {sale && (
        <del className="text-[.65em] font-normal text-muted">
          {formatPrice(previous!)}
        </del>
      )}
      <span className={sale ? "text-red-700" : ""}>
        {price === null
          ? "Цена по запросу"
          : (from ? "от " : "") + formatPrice(price)}
      </span>
    </span>
  );
}
