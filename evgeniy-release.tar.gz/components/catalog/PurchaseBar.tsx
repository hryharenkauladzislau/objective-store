"use client";
import { useSite } from "@/components/layout/SiteProvider";
import { telegramLink, track, prepareTelegramDraft, isMacTelegram } from "@/lib/telegram";
export function PurchaseBar({
  text,
  price,
  label,
}: {
  text: string;
  price: string;
  label: string;
}) {
  const site = useSite();
  return (
    <div
      data-purchasebar="true"
      className="fixed inset-x-0 bottom-0 z-50 flex items-center justify-between gap-3 border-t border-line bg-canvas px-5 pt-3 pb-[max(12px,env(safe-area-inset-bottom))] md:hidden"
    >
      <span className="text-sm font-semibold tabular-nums">{price}</span>
      <a
        className="shrink-0 rounded-full bg-accent px-5 py-3 text-sm font-semibold text-canvas"
        href={telegramLink(site.telegramUrl!, text)}
        onClick={event => {
          prepareTelegramDraft(text);
          track("telegram_click", { path: location.pathname });
          if (isMacTelegram() && !event.metaKey && !event.ctrlKey && !event.shiftKey && !event.altKey) {
            event.preventDefault();
            window.location.assign(telegramLink(site.telegramUrl!, text, { draft: false }));
          }
        }}
      >
        {label}
      </a>
    </div>
  );
}
