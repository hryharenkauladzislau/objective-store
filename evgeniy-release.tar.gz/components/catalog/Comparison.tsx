"use client";
import { useState } from "react";
import Link from "next/link";
import type { Product } from "@/lib/catalog";
import { productPriceFrom, formatPrice } from "@/lib/catalog";
import { ProductImage } from "./ProductImage";
import { useCompareList, writeCompareList } from "@/lib/compare";
export function Comparison({ products }: { products: Product[] }) {
  const ids = useCompareList();
  const [message, setMessage] = useState("");
  const [diff, setDiff] = useState(false);
  const selected = ids
    .map((id) => products.find((p) => p.slug === id))
    .filter((p): p is Product => !!p)
    .slice(0, 3);
  const update = (list: string[]) => {
    try {
      writeCompareList(list);
      setMessage("");
    } catch {
      setMessage("Разрешите сохранение в браузере для сравнения моделей");
    }
  };
  const fields = [
    ...new Set(selected.flatMap((p) => p.specs.map((s) => s.label))),
  ];
  return (
    <>
      {message && (
        <p role="status" className="mt-5 text-sm text-red-700">
          {message}
        </p>
      )}
      <div className="mt-7 flex flex-wrap items-center justify-between gap-4">
        <label className="text-sm">
          <input
            type="checkbox"
            checked={diff}
            onChange={(e) => setDiff(e.target.checked)}
            className="mr-2 accent-accent"
          />
          Только различия
        </label>
        {selected.length < 3 && (
          <select
            className="field max-w-xs"
            value=""
            aria-label="Добавить модель в сравнение"
            onChange={(e) =>
              e.target.value &&
              update([
                ...ids.filter((id) => products.some((p) => p.slug === id)),
                e.target.value,
              ])
            }
          >
            <option value="">Добавить модель</option>
            {products
              .filter((p) => !ids.includes(p.slug))
              .map((p) => (
                <option key={p.slug} value={p.slug}>
                  {p.name}
                </option>
              ))}
          </select>
        )}
      </div>
      {!selected.length ? (
        <p className="my-20 text-muted">
          Выберите до трёх моделей для сравнения.
        </p>
      ) : (
        <div className="mt-8 overflow-x-auto">
          <table className="w-full min-w-[560px] text-left text-sm">
            <thead>
              <tr>
                <th className="w-32" />
                {selected.map((p) => (
                  <th className="min-w-44 p-4 align-top" key={p.slug}>
                    <div className="relative aspect-square max-w-52">
                      <ProductImage
                        src={p.variants[0]?.images[0]}
                        alt={p.name}
                      />
                    </div>
                    <Link
                      href={"/catalog/" + p.slug}
                      className="mt-4 block text-lg"
                    >
                      {p.name} ↗
                    </Link>
                    <button
                      className="mt-2 text-xs font-normal text-muted underline"
                      onClick={() => update(ids.filter((id) => id !== p.slug))}
                    >
                      Убрать
                    </button>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {["Цена", ...fields].map((f) => {
                const values = selected.map((p) =>
                  f === "Цена"
                    ? productPriceFrom(p) === null
                      ? "По запросу"
                      : "от " + formatPrice(productPriceFrom(p)!)
                    : p.specs.find((s) => s.label === f)?.value || "—",
                );
                if (diff && new Set(values).size === 1) return null;
                return (
                  <tr className="border-t border-line" key={f}>
                    <th className="py-4 pr-4 font-normal text-muted">{f}</th>
                    {values.map((v, i) => (
                      <td className="p-4" key={i}>
                        {v}
                      </td>
                    ))}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </>
  );
}
