"use client";
import { useState } from "react";
import { TelegramRequest } from "./TelegramRequest";
import { matchingRate, formatTradeIn, type TradeInRate } from "@/lib/trade-in";
export function TradeInForm({ rates }: { rates: TradeInRate[] }) {
  const [step, setStep] = useState(0);
  const [data, setData] = useState({
    type: "iPhone",
    model: "",
    memory: "",
    condition: "Есть небольшие следы использования",
    battery: "",
    works: "Работает полностью",
    kit: "",
    contact: "",
  });
  const change = (k: keyof typeof data, v: string) =>
    setData({ ...data, [k]: v });
  const rate =
    data.type === "iPhone"
      ? matchingRate(rates, data.model, data.memory)
      : undefined;
  const needsInspection =
    data.works !== "Работает полностью" ||
    data.condition === "Есть повреждения";
  const estimate =
    rate && !needsInspection
      ? `${rate.approved ? "Предварительная оценка магазина" : "Ориентир стороннего прайса"}: до ${formatTradeIn(rate)}. Финальная сумма после осмотра.`
      : "Оценка менеджером после осмотра.";
  const request = [
    "Здравствуйте! Хочу оценить устройство для Trade-in.",
    ...Object.entries(data).map(
      ([k, v]) =>
        ({
          type: "Тип",
          model: "Модель",
          memory: "Память",
          condition: "Состояние",
          battery: "Аккумулятор, %",
          works: "Работоспособность",
          kit: "Комплект",
          contact: "Контакт",
        })[k] +
        ": " +
        (v || "не указано"),
    ),
    "Фотографии приложу в переписке.",
    estimate,
    ...(rate && !rate.approved
      ? [
          "Источник ориентира: " +
            rate.sourceUrl +
            " (" +
            rate.checkedAt +
            "). Не утверждённая цена магазина.",
        ]
      : []),
  ].join("\n");
  return (
    <div className="mt-10 max-w-2xl rounded-block border border-line bg-white p-6 sm:p-8">
      <div className="mb-8 flex gap-2">
        {["Устройство", "Состояние", "Заявка"].map((t, i) => (
          <span
            key={t}
            className={
              "flex-1 border-t-2 pt-3 text-xs " +
              (step === i
                ? "border-accent text-accent"
                : "border-line text-muted")
            }
          >
            {i + 1}. {t}
          </span>
        ))}
      </div>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          setStep(Math.min(2, step + 1));
        }}
      >
        {step === 0 && (
          <div className="grid gap-5 sm:grid-cols-2">
            <label className="admin-label">
              Тип устройства
              <select
                className="field"
                value={data.type}
                onChange={(e) => change("type", e.target.value)}
              >
                {["iPhone", "iPad", "MacBook", "Apple Watch", "Другое"].map(
                  (x) => (
                    <option key={x}>{x}</option>
                  ),
                )}
              </select>
            </label>
            <label className="admin-label">
              Модель
              <input
                list="trade-in-models"
                required
                maxLength={100}
                className="field"
                value={data.model}
                placeholder="Например, iPhone 15 Pro"
                onChange={(e) => change("model", e.target.value)}
              />
              <datalist id="trade-in-models">
                {[...new Set(rates.map((r) => r.model))].map((model) => (
                  <option key={model} value={model} />
                ))}
              </datalist>
            </label>
            <label className="admin-label">
              Память
              <input
                required
                maxLength={50}
                className="field"
                placeholder="256 ГБ"
                value={data.memory}
                onChange={(e) => change("memory", e.target.value)}
              />
            </label>
          </div>
        )}
        {step === 1 && (
          <div className="grid gap-5">
            <label className="admin-label">
              Внешнее состояние
              <select
                className="field"
                value={data.condition}
                onChange={(e) => change("condition", e.target.value)}
              >
                {[
                  "Без заметных следов",
                  "Есть небольшие следы использования",
                  "Есть повреждения",
                ].map((x) => (
                  <option key={x}>{x}</option>
                ))}
              </select>
            </label>
            <label className="admin-label">
              Работоспособность
              <select
                className="field"
                value={data.works}
                onChange={(e) => change("works", e.target.value)}
              >
                {[
                  "Работает полностью",
                  "Есть неисправности",
                  "Не включается",
                ].map((x) => (
                  <option key={x}>{x}</option>
                ))}
              </select>
            </label>
            <label className="admin-label">
              Состояние аккумулятора, % (если известно)
              <input
                className="field"
                type="number"
                min="0"
                max="100"
                value={data.battery}
                onChange={(e) => change("battery", e.target.value)}
              />
            </label>
            <label className="admin-label">
              Комплект, ремонты и замечания
              <textarea
                className="field"
                maxLength={800}
                value={data.kit}
                onChange={(e) => change("kit", e.target.value)}
                placeholder="Коробка, кабель, заменённые детали…"
              />
            </label>
          </div>
        )}
        {step === 2 && (
          <>
            <div
              className="mb-6 rounded-card border border-line bg-tint p-5"
              data-trade-in-estimate
            >
              <p className="text-xs uppercase tracking-widest text-accent">
                {rate?.approved
                  ? "Предварительная оценка"
                  : "Ориентир для обмена"}
              </p>
              <p className="mt-3 text-2xl font-semibold">
                {rate && !needsInspection
                  ? "до " + formatTradeIn(rate)
                  : "Оценим после осмотра"}
              </p>
              <p className="mt-3 text-sm leading-relaxed text-muted">
                {rate && !rate.approved
                  ? "Публичный ориентир iStock, Россия, в российских рублях. Это не цена выкупа Evgeniy Apple. Память, состояние, батарея и рынок Минска могут изменить итоговую сумму."
                  : "Сумму подтвердит менеджер с учётом памяти, батареи, ремонта и состояния устройства."}
              </p>
              {rate && !rate.approved && (
                <a
                  className="mt-3 inline-block text-xs underline text-muted"
                  href={rate.sourceUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Источник · проверен {rate.checkedAt}
                </a>
              )}
            </div>
            <label className="admin-label">
              Телефон или Telegram для ответа
              <input
                className="field"
                maxLength={100}
                value={data.contact}
                onChange={(e) => change("contact", e.target.value)}
                placeholder="@username или +375…"
              />
            </label>
            <div className="mt-6 whitespace-pre-line rounded-card bg-canvas p-5 text-sm leading-relaxed">
              {request}
            </div>
            <p className="my-5 text-xs leading-relaxed text-muted">
              Фото отправьте в Telegram вместе с заявкой. Стоимость оценки
              подтвердит менеджер после осмотра. Данные формы на сайте не
              сохраняются.
            </p>
            <TelegramRequest
              label="Отправить на оценку"
              disabled={data.contact.trim().length < 3}
              text={request}
            />
          </>
        )}
        <div className="mt-7 flex justify-between gap-3">
          {step > 0 ? (
            <button
              type="button"
              className="rounded-full border border-line px-5 py-3 text-sm"
              onClick={() => setStep(step - 1)}
            >
              ← Назад
            </button>
          ) : (
            <span />
          )}
          {step < 2 && (
            <button
              className="rounded-full bg-accent px-6 py-3 text-sm font-semibold text-white"
              type="submit"
            >
              Далее →
            </button>
          )}
        </div>
      </form>
    </div>
  );
}
