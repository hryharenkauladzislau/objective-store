"use client";
import { useState } from "react";
import { TelegramRequest } from "./TelegramRequest";
import { matchingRate, formatTradeIn, type TradeInRate, DEFAULT_TRADE_IN_SETTINGS } from "@/lib/trade-in";
import type { CatalogDocument } from "@/lib/schema";
export function TradeInForm({ rates, settings, newDevices }: { rates: TradeInRate[]; settings?: CatalogDocument["tradeInSettings"]; newDevices: { slug: string; name: string }[] }) {
  const config = settings || DEFAULT_TRADE_IN_SETTINGS;
  const [step, setStep] = useState(0);
  const [data, setData] = useState({
    type: "iPhone",
    model: "",
    memory: "",
    condition: config.conditionOptions[1] || config.conditionOptions[0],
    battery: "",
    works: config.workOptions[0],
    kit: "",
    contact: "",
    newDevice: "",
  });
  const change = (k: keyof typeof data, v: string) =>
    setData({ ...data, [k]: v });
  const rate =
    data.type === "iPhone"
      ? matchingRate(rates.filter((r) => r.approved && r.currency !== "RUB"), data.model, data.memory)
      : undefined;
  const needsInspection =
    data.works !== config.workOptions[0] ||
    data.condition === config.conditionOptions.at(-1);
  const estimate =
    rate && !needsInspection
      ? `Предварительная оценка: до ${formatTradeIn(rate)}. Финальная сумма после осмотра.`
      : "Оценка менеджером после осмотра.";
  const request = [
    "Здравствуйте! Хочу воспользоваться услугой Trade-in.",
    ...Object.entries(data).map(
      ([k, v]) =>
        ({
          type: "Тип",
          model: "Модель",
          memory: "Память",
          condition: "Состояние",
          battery: "Аккумулятор, %",
          works: "Работоспособность",
          kit: "Комплект",
          contact: "Контакт",
          newDevice: "Хочу приобрести",
        })[k] +
        ": " +
        (v || "не указано"),
    ),
    "Фотографии приложу в переписке.",
    estimate,
  ].join("\n");
  return (
    <div className="mt-10 max-w-2xl rounded-block border border-line bg-surface p-6 sm:p-8">
      <div className="mb-8 flex gap-2">
        {["Устройство", "Состояние", "Новый iPhone", "Заявка"].map((t, i) => (
          <span
            key={t}
            className={
              "flex-1 border-t-2 pt-3 text-xs " +
              (step === i
                ? "border-accent text-accent"
                : "border-line text-muted")
            }
          >
            {i + 1}. {t}
          </span>
        ))}
      </div>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          setStep(Math.min(3, step + 1));
        }}
      >
        {step === 0 && (
          <div className="grid gap-5 sm:grid-cols-2">
            <label className="admin-label">
              Тип устройства
              <select
                className="field"
                value={data.type}
                onChange={(e) => change("type", e.target.value)}
              >
                {config.deviceTypes.map(
                  (x) => (
                    <option key={x}>{x}</option>
                  ),
                )}
              </select>
            </label>
            <label className="admin-label">
              Модель
              <input
                list="trade-in-models"
                required
                maxLength={100}
                className="field"
                value={data.model}
                placeholder="Например, iPhone 15 Pro"
                onChange={(e) => change("model", e.target.value)}
              />
              <datalist id="trade-in-models">
                {[...new Set(rates.map((r) => r.model))].map((model) => (
                  <option key={model} value={model} />
                ))}
              </datalist>
            </label>
            <label className="admin-label">
              Память
              <input
                required
                maxLength={50}
                className="field"
                placeholder="256 ГБ"
                value={data.memory}
                onChange={(e) => change("memory", e.target.value)}
              />
            </label>
          </div>
        )}
        {step === 1 && (
          <div className="grid gap-5">
            <label className="admin-label">
              Внешнее состояние
              <select
                className="field"
                value={data.condition}
                onChange={(e) => change("condition", e.target.value)}
              >
                {config.conditionOptions.map((x) => (
                  <option key={x}>{x}</option>
                ))}
              </select>
            </label>
            <label className="admin-label">
              Работоспособность
              <select
                className="field"
                value={data.works}
                onChange={(e) => change("works", e.target.value)}
              >
                {config.workOptions.map((x) => (
                  <option key={x}>{x}</option>
                ))}
              </select>
            </label>
            <label className="admin-label">
              Состояние аккумулятора, % (если известно)
              <input
                className="field"
                type="number"
                min="0"
                max="100"
                value={data.battery}
                onChange={(e) => change("battery", e.target.value)}
              />
            </label>
            <label className="admin-label">
              Комплект, ремонты и замечания
              <textarea
                className="field"
                maxLength={800}
                value={data.kit}
                onChange={(e) => change("kit", e.target.value)}
                placeholder="Коробка, кабель, заменённые детали…"
              />
            </label>
          </div>
        )}
        {step === 2 && (
          <label className="admin-label">
            Какой iPhone хотите приобрести?
            <select className="field" required value={data.newDevice} onChange={(e) => change("newDevice", e.target.value)}>
              <option value="" disabled>Выберите новый iPhone</option>
              {newDevices.map(device => <option key={device.slug} value={device.name}>{device.name}</option>)}
              <option value="Помогите подобрать iPhone">Помогите подобрать iPhone</option>
            </select>
          </label>
        )}
        {step === 3 && (
          <>
            <div
              className="mb-6 rounded-card border border-line bg-tint p-5"
              data-trade-in-estimate
            >
              <p className="text-xs uppercase tracking-widest text-accent">
                {rate?.approved
                  ? "Предварительная оценка"
                  : "Ориентир для обмена"}
              </p>
              <p className="mt-3 text-2xl font-semibold">
                {rate && !needsInspection
                  ? "до " + formatTradeIn(rate)
                  : "Оценим после осмотра"}
              </p>
              <p className="mt-3 text-sm leading-relaxed text-muted">{config.estimateNotice}</p>
            </div>
            <label className="admin-label">
              Телефон или Telegram для ответа (необязательно)
              <input
                className="field"
                maxLength={100}
                value={data.contact}
                onChange={(e) => change("contact", e.target.value)}
                placeholder="@username или +375…"
              />
            </label>
            <p className="my-5 text-sm text-muted">{config.photoNotice}</p>
            <TelegramRequest
              label="Отправить на оценку"
              text={request}
            />
          </>
        )}
        <div className="mt-7 flex justify-between gap-3">
          {step > 0 ? (
            <button
              type="button"
              className="rounded-full border border-line px-5 py-3 text-sm"
              onClick={() => setStep(step - 1)}
            >
              Назад
            </button>
          ) : (
            <span />
          )}
          {step < 3 && (
            <button
              className="rounded-full bg-accent px-6 py-3 text-sm font-semibold text-canvas"
              type="submit"
            >
              Далее
            </button>
          )}
        </div>
      </form>
    </div>
  );
}
