"use client";
import { useState } from "react";
import { useSite } from "@/components/layout/SiteProvider";
import { telegramLink, track } from "@/lib/telegram";
export function TelegramRequest({
  text,
  label = "Задать вопрос",
  disabled = false,
}: {
  text: string;
  label?: string;
  disabled?: boolean;
}) {
  const site = useSite();
  const [copied, setCopied] = useState(false);
  const [fallback, setFallback] = useState(false);
  return (
    <div>
      <a
        href={disabled ? undefined : telegramLink(site.telegramUrl!, text)}
        aria-disabled={disabled || undefined}
        target="_blank"
        rel="noopener noreferrer"
        onClick={(e) => {
          e.currentTarget.href = telegramLink(
            site.telegramUrl!,
            text + "\n" + location.href,
          );
          track("telegram_click", { path: location.pathname });
        }}
        className={
          "inline-flex min-h-12 items-center justify-center rounded-full bg-accent px-6 text-sm font-semibold text-white hover:bg-accent-strong " +
          (disabled ? "pointer-events-none opacity-40" : "")
        }
      >
        {label} ↗
      </a>
      <button
        type="button"
        className="ml-4 text-xs text-muted underline underline-offset-4"
        onClick={async () => {
          try {
            await navigator.clipboard.writeText(text + "\n" + location.href);
            setCopied(true);
          } catch {
            setFallback(true);
          }
        }}
      >
        {copied ? "Текст скопирован" : "Скопировать заявку"}
      </button>
      {fallback && (
        <textarea
          aria-label="Текст заявки для копирования"
          readOnly
          value={text}
          className="field mt-3 h-40"
        />
      )}
      <p className="mt-3 text-xs text-muted">
        Откроется Telegram с готовым сообщением. Если текст не подставился,
        скопируйте заявку.
      </p>
    </div>
  );
}
