"use client";
import { useSite } from "@/components/layout/SiteProvider";
import { telegramLink, track } from "@/lib/telegram";
export function TelegramRequest({ text, label = "Задать вопрос", disabled = false }: { text: string; label?: string; disabled?: boolean }) {
  const site = useSite();
  return <a
    href={disabled ? undefined : telegramLink(site.telegramUrl!, text)}
    aria-disabled={disabled || undefined}
    onClick={() => track("telegram_click", { path: location.pathname })}
    className={"inline-flex min-h-12 items-center justify-center rounded-full bg-accent px-6 text-sm font-semibold text-canvas hover:bg-accent-strong " + (disabled ? "pointer-events-none opacity-40" : "")}
  >{label}</a>;
}
