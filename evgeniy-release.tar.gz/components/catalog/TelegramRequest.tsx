"use client";
import { useSite } from "@/components/layout/SiteProvider";
import { telegramLink, track, prepareTelegramDraft, isMacTelegram } from "@/lib/telegram";
export function TelegramRequest({ text, label = "Задать вопрос", disabled = false }: { text: string; label?: string; disabled?: boolean }) {
  const site = useSite();
  return <a
    href={disabled ? undefined : telegramLink(site.telegramUrl!, text)}
    aria-disabled={disabled || undefined}
    onClick={event => {
      prepareTelegramDraft(text);
      track("telegram_click", { path: location.pathname });
      if (isMacTelegram() && !event.metaKey && !event.ctrlKey && !event.shiftKey && !event.altKey) {
        event.preventDefault();
        window.location.assign(telegramLink(site.telegramUrl!, text, { draft: false }));
      }
    }}
    className={"inline-flex min-h-12 items-center justify-center rounded-full bg-accent px-6 text-sm font-semibold text-canvas hover:bg-accent-strong " + (disabled ? "pointer-events-none opacity-40" : "")}
  >{label}</a>;
}
