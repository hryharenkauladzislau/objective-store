"use client";
import { createContext, useContext, type ReactNode } from "react";
import { SITE } from "@/lib/site";
import { DEFAULT_PRESENTATION, type Presentation } from "@/lib/presentation";
const Context = createContext({ ...SITE, presentation: DEFAULT_PRESENTATION });
export function SiteProvider({
  value,
  children,
}: {
  value: typeof SITE & { presentation: Presentation };
  children: ReactNode;
}) {
  return <Context.Provider value={value}>{children}</Context.Provider>;
}
export function useSite() {
  return useContext(Context);
}

export function usePresentation() { return useContext(Context).presentation; }
