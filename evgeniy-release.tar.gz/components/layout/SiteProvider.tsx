"use client";
import { createContext, useContext, type ReactNode } from "react";
import { SITE } from "@/lib/site";
const Context = createContext(SITE);
export function SiteProvider({
  value,
  children,
}: {
  value: typeof SITE;
  children: ReactNode;
}) {
  return <Context.Provider value={value}>{children}</Context.Provider>;
}
export function useSite() {
  return useContext(Context);
}
