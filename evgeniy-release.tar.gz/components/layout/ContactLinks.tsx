"use client";
import { useSite } from "@/components/layout/SiteProvider";
import { cn } from "@/lib/cn";

/*
 * Контактные ссылки из единого конфига lib/site.ts (ТЗ §24).
 * Пока значение не предоставлено владельцем, показываем плейсхолдер без href —
 * фейковые ссылки и номера запрещены. Когда значение появится в конфиге,
 * плейсхолдер автоматически превратится в рабочую ссылку.
 */

const HOVER = "transition-colors hover:text-ink";

export function SocialIcon({ network, className = "h-4 w-4" }: { network: "telegram" | "instagram"; className?: string }) {
  return network === "telegram" ? (
    <svg viewBox="0 0 24 24" aria-hidden="true" className={className} fill="currentColor">
      <path d="M21.7 3.5 18.5 19c-.24 1.1-.88 1.37-1.78.85l-4.88-3.6-2.35 2.27c-.26.26-.48.48-.98.48l.35-4.97 9.04-8.17c.4-.35-.08-.55-.61-.2L6.11 12.7 1.3 11.2C.25 10.87.23 10.15 1.52 9.65L20.3 2.42c.87-.32 1.63.2 1.4 1.08Z" />
    </svg>
  ) : (
    <svg viewBox="0 0 24 24" aria-hidden="true" className={className} fill="none" stroke="currentColor" strokeWidth="1.8">
      <rect x="3" y="3" width="18" height="18" rx="5" />
      <circle cx="12" cy="12" r="4.1" />
      <circle cx="17.4" cy="6.7" r="1" fill="currentColor" stroke="none" />
    </svg>
  );
}

export function PhoneLink({ className }: { className?: string }) {
  const SITE = useSite();
  if (SITE.phone) {
    return (
      <a
        href={`tel:${SITE.phone.replace(/[^+\d]/g, "")}`}
        className={cn("font-semibold", HOVER, className)}
      >
        {SITE.phone}
      </a>
    );
  }
  return (
    <span className={cn("font-medium text-muted", className)}>
      {SITE.phonePlaceholder}
      <span className="ml-1.5 text-ink/40">· уточняется</span>
    </span>
  );
}

export function SocialLink({
  network,
  className,
}: {
  network: "telegram" | "instagram";
  className?: string;
}) {
  const SITE = useSite();
  const url = network === "telegram" ? SITE.telegramUrl : SITE.instagramUrl;
  const label =
    network === "telegram" ? SITE.telegramLabel : SITE.instagramLabel;

  if (url) {
    return (
      <a
        href={url}
        target="_blank"
        rel="noopener noreferrer"
        className={cn(
          "inline-flex items-center gap-1.5 font-semibold text-accent hover:text-accent-strong",
          className,
        )}
      >
        <SocialIcon network={network} />
        {label}
      </a>
    );
  }
  return (
    <span
      className={cn("font-medium text-muted", className)}
      title="Ссылка появится после подключения"
    >
      {label}
      <span className="ml-1.5 text-ink/40">· скоро</span>
    </span>
  );
}
