import { Container } from "@/components/ui/primitives";
import { TelegramRequest } from "@/components/catalog/TelegramRequest";
import { readCatalog } from "@/lib/catalog-store";
export async function InformationPage({
  route,
  title,
  intro,
  sections,
}: {
  route: string;
  title: string;
  intro: string;
  sections: { title: string; text: string }[];
}) {
  const override = (await readCatalog()).pages?.[route];
  if (override) {
    title = override.title;
    intro = override.intro;
    sections = override.sections;
  }
  return (
    <Container className="py-12 lg:py-20">
      <p className="text-xs uppercase tracking-widest text-muted">
        EVGENIY APPLE
      </p>
      <h1 className="mt-4 max-w-3xl text-4xl font-semibold tracking-tight sm:text-6xl">
        {title}
      </h1>
      <p className="mt-6 max-w-2xl text-base leading-relaxed text-muted">
        {intro}
      </p>
      <div className="mt-12 max-w-3xl divide-y divide-line">
        {sections.map((s, i) => (
          <section key={i} className="grid gap-4 py-7 sm:grid-cols-[60px_1fr]">
            <span className="text-xs text-muted">0{i + 1}</span>
            <div>
              <h2 className="text-xl font-semibold">{s.title}</h2>
              <p className="mt-3 text-sm leading-relaxed text-muted">
                {s.text}
              </p>
            </div>
          </section>
        ))}
      </div>
      <div className="mt-10">
        <TelegramRequest text={"Здравствуйте! Хочу уточнить: " + title + "."} />
      </div>
    </Container>
  );
}
