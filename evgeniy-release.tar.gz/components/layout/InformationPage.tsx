import { Container } from "@/components/ui/primitives";
import { TelegramRequest } from "@/components/catalog/TelegramRequest";
import { readCatalog } from "@/lib/catalog-store";
export async function InformationPage({
  route,
  title,
  intro,
  sections,
}: {
  route: string;
  title: string;
  intro: string;
  sections: { title: string; text: string }[];
}) {
  const override = (await readCatalog()).pages?.[route];
  if (override) {
    title = override.title;
    intro = override.intro;
    sections = override.sections;
  }
  return (
    <Container className="information-page py-10 lg:py-14">
      <p className="text-xs uppercase tracking-widest text-muted">
        EVGENIY APPLE
      </p>
      <h1 className="mt-4 text-4xl font-semibold sm:text-6xl">
        {title}
      </h1>
      <p className="information-intro mt-6 text-lg leading-relaxed text-muted">
        {intro}
      </p>
      <div className="information-sections mt-9">
        {sections.map((s, i) => (
          <section key={i} className="grid gap-4 sm:grid-cols-[40px_1fr]">
            <span className="text-xs text-muted">0{i + 1}</span>
            <div>
              <h2 className="text-2xl font-semibold">{s.title}</h2>
              <p className="mt-4 text-base leading-relaxed text-muted">
                {s.text}
              </p>
            </div>
          </section>
        ))}
      </div>
      <div className="mt-10">
        <TelegramRequest text={"Здравствуйте! Хочу уточнить: " + title + "."} />
      </div>
    </Container>
  );
}
