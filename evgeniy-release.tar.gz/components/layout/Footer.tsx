import Link from "next/link";
import { BrandMarkPlaceholder } from "@/components/brand/BrandMarkPlaceholder";
import { Container } from "@/components/ui/primitives";
import { PhoneLink, SocialLink } from "@/components/layout/ContactLinks";
import { getPresentation } from "@/lib/presentation";
import { readCatalog } from "@/lib/catalog-store";

/*
 * Footer по ТЗ §10: категории, покупателям, компания, контакты-плейсхолдеры,
 * юридические ссылки. Контакты — из lib/site.ts без фейковых значений.
 */

export async function Footer() {
  const { settings, categories, presentation } = await readCatalog();
  const p = getPresentation(presentation);
  const columns = [{title:"Каталог",links:categories.filter(c=>!c.hidden).map(c=>({href:"/catalog?category="+c.slug,label:c.name,hidden:false}))},...p.footer.columns];
  return (
    <footer className="mt-16 border-t border-line bg-surface">
      <Container className="py-12">
        <div className="grid gap-10 sm:grid-cols-2 lg:grid-cols-[1.4fr_1fr_1fr_1fr]">
          <div>
            <Link href="/" aria-label="EVGENIY APPLE — на главную">
              <BrandMarkPlaceholder className="text-[17px]" />
            </Link>
            {/* TODO: заменить адрес и график на данные владельца (ТЗ §24) */}
            <p className="mt-4 text-sm text-muted">
              {settings.address}
              <br />
              {settings.hours}
              <br />
              {p.footer.note}
            </p>
            <p className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-1.5 text-sm">
              <PhoneLink />
              <SocialLink network="telegram" />
              <SocialLink network="instagram" />
            </p>
          </div>

          {columns.map((col) => (
            <nav key={col.title} aria-label={col.title}>
              <h3 className="text-xs font-bold uppercase tracking-wider text-muted">
                {col.title}
              </h3>
              <ul className="mt-4 space-y-2.5">
                {col.links.filter(link => !link.hidden).map((link) => (
                  <li key={link.href + link.label}>
                    <Link
                      href={link.href}
                      className="text-sm text-ink/80 transition-colors hover:text-ink"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </nav>
          ))}
        </div>

        <div className="mt-10 flex flex-col gap-3 border-t border-line pt-6 text-xs text-muted sm:flex-row sm:items-center sm:justify-between">
          {/* TODO: заменить юрссылки и реквизиты на данные заказчика */}
          <p>
            © 2026 {p.brand.name} APPLE. {settings.legalName} · УНП {settings.legalId}
          </p>
          <div className="flex gap-5">
            <Link href="/privacy" className="hover:text-ink">
              {p.footer.privacyLabel}
            </Link>
            <Link href="/terms" className="hover:text-ink">
              {p.footer.termsLabel}
            </Link>
          </div>
        </div>
      </Container>
    </footer>
  );
}
