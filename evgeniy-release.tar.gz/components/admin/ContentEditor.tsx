"use client";
import { useState } from "react";
import { PAGE_COPY } from "@/lib/content";
import type { CatalogDocument } from "@/lib/schema";
export function ContentEditor({
  pages,
  onChange,
}: {
  pages: CatalogDocument["pages"];
  onChange: (pages: NonNullable<CatalogDocument["pages"]>) => void;
}) {
  const [route, setRoute] = useState("shipping");
  const page = pages?.[route] || PAGE_COPY[route];
  const edit = (fn: (p: typeof page) => void) => {
    const p = structuredClone(page);
    fn(p);
    onChange({ ...pages, [route]: p });
  };
  return (
    <section className="rounded-block border border-line bg-white p-5 sm:p-7">
      <h2 className="text-xl font-semibold">Тексты страниц</h2>
      <label className="admin-label mt-5">
        Страница
        <select
          aria-label="Страница для редактирования"
          className="field max-w-lg"
          value={route}
          onChange={(e) => setRoute(e.target.value)}
        >
          {Object.entries(PAGE_COPY).map(([key, p]) => (
            <option key={key} value={key}>
              {p.title}
            </option>
          ))}
        </select>
      </label>
      <label className="admin-label mt-5">
        Заголовок
        <input
          className="field"
          value={page.title}
          onChange={(e) => edit((p) => (p.title = e.target.value))}
        />
      </label>
      <label className="admin-label mt-5">
        Вступление
        <textarea
          className="field min-h-24"
          value={page.intro}
          onChange={(e) => edit((p) => (p.intro = e.target.value))}
        />
      </label>
      <div className="mt-6 space-y-6">
        {page.sections.map((s, i) => (
          <div
            key={route + i}
            className="rounded-card border border-line bg-canvas p-4"
          >
            <label className="admin-label">
              Название раздела
              <input
                className="field"
                value={s.title}
                onChange={(e) =>
                  edit((p) => (p.sections[i].title = e.target.value))
                }
              />
            </label>
            <label className="admin-label mt-3">
              Текст
              <textarea
                className="field min-h-32"
                value={s.text}
                onChange={(e) =>
                  edit((p) => (p.sections[i].text = e.target.value))
                }
              />
            </label>
            <button
              className="mt-3 text-xs text-red-700"
              onClick={() => edit((p) => p.sections.splice(i, 1))}
            >
              Удалить раздел
            </button>
          </div>
        ))}
      </div>
      <button
        className="mt-6 text-sm text-accent"
        onClick={() =>
          edit((p) => p.sections.push({ title: "Новый раздел", text: "" }))
        }
      >
        ＋ Добавить раздел
      </button>
      <p className="mt-5 text-xs text-muted">
        Опубликуйте только согласованные условия гарантии, доставки и заказа.
      </p>
    </section>
  );
}
