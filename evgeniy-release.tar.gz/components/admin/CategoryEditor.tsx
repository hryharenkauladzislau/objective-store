"use client";
import type { CatalogDocument } from "@/lib/schema";
import Image from "next/image";
export function CategoryEditor({
  data,
  onChange,
  upload,
}: {
  data: CatalogDocument;
  onChange: (fn: (d: CatalogDocument) => void) => void;
  upload: (file: File) => Promise<string>;
}) {
  const uploadImage = async (file: File, categoryIndex: number, subcategoryIndex?: number) => {
    const url = await upload(file);
    onChange((d) => {
      if (subcategoryIndex === undefined) d.categories[categoryIndex].image = url;
      else d.categories[categoryIndex].subcategories![subcategoryIndex].image = url;
    });
  };
  return (
    <section className="rounded-block border border-line bg-surface p-5 sm:p-7">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <h2 className="text-xl font-semibold">Категории и подкатегории</h2>
        <button
          className="text-sm text-accent"
          onClick={() =>
            onChange((d) =>
              d.categories.push({
                slug: "category-" + crypto.randomUUID().slice(0, 8),
                name: "Новая категория",
                caption: "",
                image: null,
                subcategories: [],
                direct: true,
              }),
            )
          }
        >
          ＋ Категория
        </button>
      </div>
      <p className="my-4 text-sm leading-relaxed text-muted">
        Крестик убирает категорию с витрины вместе с её товарами. Товары
        сохраняются, категорию можно восстановить. Подкатегории необязательны.
      </p>
      <div className="space-y-4">
        {data.categories.map((c, i) => (
          <div
            key={c.slug}
            className={
              "rounded-card border border-line p-4 " +
              (c.hidden ? "bg-canvas" : "")
            }
          >
            <div className="flex items-start gap-3">
              <div className="min-w-0 flex-1">
                <label className="admin-label">
                  Название категории
                  <input
                    className="field"
                    aria-label={"Название категории " + c.slug}
                    value={c.name}
                    onChange={(e) =>
                      onChange((d) => {
                        d.categories[i].name = e.target.value;
                      })
                    }
                  />
                </label>
                <span className="mt-1 block text-xs text-muted">
                  {c.slug}
                  {c.hidden ? " · убрана с сайта" : ""}
                </span>
              </div>
              <button
                className={
                  "mt-7 px-2 text-sm " +
                  (c.hidden ? "text-accent" : "text-red-700")
                }
                aria-label={(c.hidden ? "Восстановить " : "Убрать ") + c.name}
                onClick={() =>
                  onChange((d) => {
                    d.categories[i].hidden = !c.hidden;
                  })
                }
              >
                {c.hidden ? "Восстановить" : "×"}
              </button>
              <button
                className="mt-7 px-2 text-sm disabled:opacity-30"
                aria-label={"Переместить выше " + c.name}
                disabled={i === 0}
                onClick={() =>
                  onChange((d) => {
                    [d.categories[i - 1], d.categories[i]] = [
                      d.categories[i],
                      d.categories[i - 1],
                    ];
                  })
                }
              >
                ↑
              </button>
            </div>
            <label className="admin-label mt-4">
              Подпись на главной
              <input
                className="field"
                value={c.caption}
                onChange={(e) =>
                  onChange((d) => {
                    d.categories[i].caption = e.target.value;
                  })
                }
              />
            </label>
            <label className="admin-label mt-4">
              Логотип / обложка бренда
              <span className="mt-2 flex items-center gap-3 rounded-xl border border-line bg-canvas p-3">
                {c.image ? <Image src={c.image} alt="" width={64} height={64} unoptimized={c.image.startsWith("/api/")} className="h-16 w-16 rounded-lg bg-surface object-contain p-1" /> : <span className="flex h-16 w-16 items-center justify-center rounded-lg bg-surface text-xs text-muted">Нет фото</span>}
                <span className="min-w-0 flex-1"><input className="max-w-full text-xs" type="file" accept="image/jpeg,image/png,image/webp" onChange={(e) => { const file=e.target.files?.[0]; if(file) void uploadImage(file,i); }} />{c.image && <span className="mt-1 block truncate text-xs text-muted">{c.image}</span>}</span>
              </span>
            </label>
            <label className="mt-4 flex gap-2 text-sm">
              <input
                type="checkbox"
                checked={c.direct ?? !c.subcategories?.length}
                onChange={(e) =>
                  onChange((d) => {
                    d.categories[i].direct = e.target.checked;
                  })
                }
              />
              Сразу показывать товары
            </label>
            <div className="mt-5 space-y-2">
              {(c.subcategories || []).map((s, j) => (
                <div key={s.slug} className="grid gap-2 rounded-xl border border-line p-3 sm:grid-cols-[1fr_1fr_auto]">
                  <input
                    className="field"
                    aria-label={"Название подкатегории " + s.slug}
                    value={s.name}
                    onChange={(e) =>
                      onChange((d) => {
                        d.categories[i].subcategories![j].name = e.target.value;
                      })
                    }
                  />
                  <label className="admin-label">
                    Логотип / фото подкатегории
                    <input type="file" accept="image/jpeg,image/png,image/webp" onChange={(e) => { const file=e.target.files?.[0]; if(file) void uploadImage(file,i,j); }} />
                  </label>
                  <button
                    className="px-3 text-red-700"
                    aria-label={"Удалить подкатегорию " + s.name}
                    onClick={() =>
                      onChange((d) => {
                        d.categories[i].subcategories = d.categories[
                          i
                        ].subcategories!.filter((x) => x.slug !== s.slug);
                        d.products.forEach((p) => {
                          if (p.category === c.slug && p.subcategory === s.slug)
                            p.subcategory = null;
                        });
                      })
                    }
                  >
                    ×
                  </button>
                </div>
              ))}
            </div>
            <button
              className="mt-4 text-sm text-accent"
              onClick={() =>
                onChange((d) => {
                  (d.categories[i].subcategories ??= []).push({
                    slug: "sub-" + crypto.randomUUID().slice(0, 8),
                    name: "Новая подкатегория",
                    image: null,
                  });
                  d.categories[i].direct = false;
                })
              }
            >
              ＋ Подкатегория
            </button>
          </div>
        ))}
      </div>
    </section>
  );
}
