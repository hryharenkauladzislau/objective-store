"use client";
import { useEffect, useState } from "react";
import type { CatalogDocument } from "@/lib/schema";
import type { Product, Variant, UsedUnit } from "@/lib/catalog";
import { ProductImage } from "@/components/catalog/ProductImage";
import { ContentEditor } from "./ContentEditor";
import { CategoryEditor } from "./CategoryEditor";
import { TradeInEditor } from "./TradeInEditor";
import { SiteEditor } from "./SiteEditor";
import { PriceListEditor } from "./PriceListEditor";
import SOURCE from "@/lib/source-data.json";
import { DEFAULT_TRADE_IN_SETTINGS } from "@/lib/trade-in";
type Preview = {
  candidate: CatalogDocument | null;
  counts: Record<string, number>;
  report: { row: number; sku: string; result: string; message: string }[];
};
const statusLabels = {
  "in-stock": "В наличии",
  "on-order": "Под заказ",
  out: "Нет в наличии",
  request: "Цена по запросу",
};
function Field({
  label,
  value,
  onChange,
  type = "text",
}: {
  label: string;
  value: string | number;
  onChange: (v: string) => void;
  type?: string;
}) {
  return (
    <label className="admin-label">
      {label}
      <input
        className="field"
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
      />
    </label>
  );
}
export function AdminPanel({ initial }: { initial: CatalogDocument | null }) {
  const [d, setD] = useState(initial);
  const [tab, setTab] = useState("Товары");
  const [selected, setSelected] = useState(0);
  const [variant, setVariant] = useState(0);
  const [usedIndex, setUsedIndex] = useState(0);
  const [cat, setCat] = useState("");
  const [subcat, setSubcat] = useState("");
  const [onlySale, setOnlySale] = useState(false);
  const [query, setQuery] = useState("");
  const [busy, setBusy] = useState(false);
  const [dirty, setDirty] = useState(false);
  const [message, setMessage] = useState("");
  const [password, setPassword] = useState("");
  const [preview, setPreview] = useState<Preview | null>(null);
  useEffect(() => {
    const warn = (e: BeforeUnloadEvent) => {
      if (dirty) {
        e.preventDefault();
        e.returnValue = "";
      }
    };
    window.addEventListener("beforeunload", warn);
    return () => window.removeEventListener("beforeunload", warn);
  }, [dirty]);
  const mutate = (fn: (x: CatalogDocument) => void) => {
    if (!d) return;
    const copy = structuredClone(d);
    fn(copy);
    setD(copy);
    setDirty(true);
  };
  const call = async (url: string, options: RequestInit) => {
    const r = await fetch(url, options);
    const x = await r.json().catch(() => ({
      error: "Сессия истекла или сервер недоступен. Обновите страницу.",
    }));
    if (!r.ok) throw new Error(x.error || "Ошибка запроса");
    return x;
  };
  const action = async (fn: () => Promise<void>) => {
    setBusy(true);
    setMessage("");
    try {
      await fn();
    } catch (e) {
      setMessage((e as Error).message);
    } finally {
      setBusy(false);
    }
  };
  const save = () =>
    action(async () => {
      const x = await call("/api/admin/catalog", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(d),
      });
      setD(x);
      setDirty(false);
      setMessage("Сохранено. Изменения уже на сайте.");
    });
  const upload = async (file: File) => {
    const f = new FormData();
    f.set("file", file);
    return (await call("/api/admin/photos", { method: "POST", body: f }))
      .url as string;
  };
  if (!d)
    return (
      <div className="mx-auto max-w-md px-5 py-20">
        <h1 className="text-3xl font-semibold">Управление магазином</h1>
        <p className="mt-3 text-sm text-muted">Вход администратора</p>
        <form
          className="mt-7 grid gap-4"
          onSubmit={(e) => {
            e.preventDefault();
            action(async () => {
              await call("/api/admin/session", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ password }),
              });
              setD(await call("/api/admin/catalog", {}));
              setPassword("");
            });
          }}
        >
          <Field
            label="Пароль"
            type="password"
            value={password}
            onChange={setPassword}
          />
          <button
            disabled={busy}
            className="rounded-full bg-accent py-3 text-canvas"
          >
            {busy ? "Вход…" : "Войти"}
          </button>
        </form>
        {message && (
          <p className="mt-4 text-sm text-red-700" role="alert">
            {message}
          </p>
        )}
      </div>
    );
  const p = d.products[selected];
  const v = p?.variants[variant];
  const u = d.used[usedIndex];
  const updateP = (part: Partial<Product>) =>
    mutate((x) => Object.assign(x.products[selected], part));
  const updateV = (part: Partial<Variant>) =>
    mutate((x) => Object.assign(x.products[selected].variants[variant], part));
  const updateU = (part: Partial<UsedUnit>) =>
    mutate((x) => Object.assign(x.used[usedIndex], part));
  const blankVariant = (): Variant => ({
    sku: "sku-" + Date.now(),
    storageGb: 128,
    colorHex: "#eeeeee",
    colorName: "Белый",
    sim: "Уточняется",
    basePriceUsd: null,
    manualPriceUsd: null,
    status: "request",
    images: [],
  });
  return (
    <div className="mx-auto max-w-[1400px] px-4 py-8 sm:px-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <p className="text-xs uppercase tracking-widest text-muted">
            EVGENIY APPLE
          </p>
          <h1 className="mt-2 text-3xl font-semibold">Управление магазином</h1>
        </div>
        <div className="flex gap-3">
          <button
            disabled={busy}
            className="rounded-full bg-accent px-6 py-3 text-sm text-canvas disabled:opacity-50"
            onClick={save}
          >
            {busy ? "Подождите…" : dirty ? "Сохранить изменения" : "Сохранить"}
          </button>
          <button
            className="text-sm text-muted"
            onClick={() =>
              action(async () => {
                await call("/api/admin/session", { method: "DELETE" });
                setD(null);
                setDirty(false);
              })
            }
          >
            Выйти
          </button>
        </div>
      </div>
      <p className="mt-4 text-xs text-muted">
        Изменения публикуются после сохранения. Ревизия {d.revision}.{" "}
        {dirty ? "Есть несохранённые изменения." : ""}
      </p>
      {message && (
        <p
          role="status"
          className="my-4 rounded-xl border border-line bg-surface p-4 text-sm"
        >
          {message}
        </p>
      )}
      <fieldset disabled={busy} className="min-w-0">
        <nav
          className="my-7 flex gap-2 overflow-x-auto"
          aria-label="Разделы админки"
        >
          {[
            "Товары",
            "Б/У",
            "Цены",
            "Категории",
            "Trade-in",
            "Excel",
            "Тексты",
            "Настройки",
            "Сайт",
            "Данные канала",
          ].map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={
                "shrink-0 rounded-full px-5 py-3 text-sm " +
                (tab === t
                  ? "bg-accent text-canvas"
                  : "border border-line bg-surface")
              }
            >
              {t}
            </button>
          ))}
        </nav>
        {tab === "Товары" && (
          <div className="grid gap-6 lg:grid-cols-[260px_1fr]">
            <aside>
              <button
                className="mb-4 w-full rounded-xl border border-accent p-3 text-sm text-accent"
                onClick={() => {
                  mutate((x) =>
                    x.products.push({
                      slug: "new-" + Date.now(),
                      category: (
                        x.categories.find((c) => !c.hidden) || x.categories[0]
                      ).slug,
                      name: "Новая модель",
                      series: "",
                      tagline: "",
                      addedAt: new Date().toISOString().slice(0, 10),
                      featuredOnHome: false,
                      hidden: true,
                      specs: [],
                      variants: [blankVariant()],
                    }),
                  );
                  setSelected(d.products.length);
                  setVariant(0);
                }}
              >
                ＋ Добавить модель
              </button>
              <Field label="Поиск модели" value={query} onChange={setQuery} />
              <div className="mt-3 max-h-[600px] space-y-1 overflow-y-auto">
                {d.products.map(
                  (m, i) =>
                    m.name.toLowerCase().includes(query.toLowerCase()) && (
                      <button
                        className={
                          "w-full rounded-xl p-3 text-left text-sm " +
                          (i === selected
                            ? "bg-tint text-accent"
                            : "hover:bg-surface")
                        }
                        key={m.slug}
                        onClick={() => {
                          setSelected(i);
                          setVariant(0);
                        }}
                      >
                        {m.name}
                        {m.hidden && (
                          <span className="ml-2 text-xs text-muted">скрыт</span>
                        )}
                      </button>
                    ),
                )}
              </div>
            </aside>
            {p && (
              <section className="min-w-0 rounded-block border border-line bg-surface p-5 sm:p-7">
                <h2 className="mb-5 text-xl font-semibold">Модель</h2>
                <div className="grid gap-4 sm:grid-cols-2">
                  <Field
                    label="Название"
                    value={p.name}
                    onChange={(name) => updateP({ name })}
                  />
                  <Field
                    label="URL (slug, латиница)"
                    value={p.slug}
                    onChange={(slug) => updateP({ slug })}
                  />
                  <label className="admin-label">
                    Категория
                    <select
                      className="field"
                      value={p.category}
                      aria-label="Категория"
                      onChange={(e) =>
                        updateP({
                          category: e.target.value as Product["category"],
                          subcategory: null,
                        })
                      }
                    >
                      {d.categories.map((c) => (
                        <option key={c.slug} value={c.slug}>
                          {c.name}
                        </option>
                      ))}
                    </select>
                  </label>
                  {!!d.categories.find((c) => c.slug === p.category)
                    ?.subcategories?.length && (
                    <label className="admin-label">
                      Подкатегория
                      <select
                        className="field"
                        aria-label="Подкатегория товара"
                        value={p.subcategory || ""}
                        onChange={(e) =>
                          updateP({ subcategory: e.target.value || null })
                        }
                      >
                        <option value="">Без подкатегории</option>
                        {d.categories
                          .find((c) => c.slug === p.category)!
                          .subcategories!.map((s) => (
                            <option key={s.slug} value={s.slug}>
                              {s.name}
                            </option>
                          ))}
                      </select>
                    </label>
                  )}
                  <Field
                    label="Серия"
                    value={p.series}
                    onChange={(series) => updateP({ series })}
                  />
                  <Field
                    label="Короткое описание"
                    value={p.tagline}
                    onChange={(tagline) => updateP({ tagline })}
                  />
                  <Field
                    label="Дата появления"
                    type="date"
                    value={p.addedAt}
                    onChange={(addedAt) => updateP({ addedAt })}
                  />
                </div>
                <div className="my-5 flex flex-wrap gap-5 text-sm">
                  <label>
                    <input
                      className="mr-2"
                      type="checkbox"
                      checked={!!p.hidden}
                      onChange={(e) => updateP({ hidden: e.target.checked })}
                    />
                    Скрыт с сайта
                  </label>
                  <label>
                    <input
                      className="mr-2"
                      type="checkbox"
                      checked={p.featuredOnHome}
                      onChange={(e) =>
                        updateP({ featuredOnHome: e.target.checked })
                      }
                    />
                    Карусель на главной
                  </label>
                  <button
                    className="text-accent"
                    disabled={selected === 0}
                    onClick={() => {
                      mutate((x) => {
                        [x.products[selected - 1], x.products[selected]] = [
                          x.products[selected],
                          x.products[selected - 1],
                        ];
                      });
                      setSelected(selected - 1);
                    }}
                  >
                    ↑ Выше в списке
                  </button>
                </div>
                <label className="admin-label">
                  Характеристики: одна строка «Название: значение»
                  <textarea
                    className="field min-h-32"
                    key={p.slug}
                    defaultValue={p.specs
                      .map((s) => s.label + ": " + s.value)
                      .join("\n")}
                    onBlur={(e) =>
                      updateP({
                        specs: e.target.value
                          .split("\n")
                          .filter(Boolean)
                          .map((line) => {
                            const i = line.indexOf(":");
                            return {
                              label: i < 0 ? line : line.slice(0, i),
                              value: i < 0 ? "" : line.slice(i + 1).trim(),
                            };
                          }),
                      })
                    }
                  />
                </label>
                <div className="mt-8 flex flex-wrap items-center justify-between gap-3">
                  <h2 className="text-xl font-semibold">
                    Варианты ({p.variants.length})
                  </h2>
                  <button
                    className="text-sm text-accent"
                    onClick={() => {
                      updateP({ variants: [...p.variants, blankVariant()] });
                      setVariant(p.variants.length);
                    }}
                  >
                    ＋ Добавить вариант
                  </button>
                </div>
                <select
                  className="field my-4"
                  aria-label="Выбрать вариант"
                  value={variant}
                  onChange={(e) => setVariant(Number(e.target.value))}
                >
                  {p.variants.map((n, i) => (
                    <option key={n.sku + "-" + i} value={i}>
                      {n.storageGb || "Стандарт"} · {n.colorName} · {n.sim} ·{" "}
                      {n.sku}
                    </option>
                  ))}
                </select>
                {v && (
                  <>
                    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                      <Field
                        label="SKU (уникальный)"
                        value={v.sku}
                        onChange={(sku) => updateV({ sku })}
                      />
                      <Field
                        label="Память, ГБ (пусто — стандарт)"
                        type="number"
                        value={v.storageGb ?? ""}
                        onChange={(s) =>
                          updateV({ storageGb: s === "" ? null : Number(s) })
                        }
                      />
                      <Field
                        label="Цвет"
                        value={v.colorName}
                        onChange={(colorName) => updateV({ colorName })}
                      />
                      <Field
                        label="HEX цвета"
                        type="color"
                        value={v.colorHex}
                        onChange={(colorHex) => updateV({ colorHex })}
                      />
                      <Field
                        label="SIM / версия"
                        value={v.sim}
                        onChange={(sim) => updateV({ sim })}
                      />
                      <label className="admin-label">
                        Наличие
                        <select
                          className="field"
                          value={v.status}
                          onChange={(e) =>
                            updateV({
                              status: e.target.value as Variant["status"],
                            })
                          }
                        >
                          {Object.entries(statusLabels).map(([key, text]) => (
                            <option key={key} value={key}>
                              {text}
                            </option>
                          ))}
                        </select>
                      </label>
                      <Field
                        label="Базовая цена, USD"
                        type="number"
                        value={v.basePriceUsd ?? ""}
                        onChange={(s) =>
                          updateV({ basePriceUsd: s === "" ? null : Number(s) })
                        }
                      />
                      <Field
                        label="Ручная цена, USD (без коэффициента)"
                        type="number"
                        value={v.manualPriceUsd ?? ""}
                        onChange={(s) =>
                          updateV({
                            manualPriceUsd: s === "" ? null : Number(s),
                          })
                        }
                      />
                      <Field
                        label="Старая цена, USD (SALE; пусто — без скидки)"
                        type="number"
                        value={v.oldPriceUsd ?? ""}
                        onChange={(s) =>
                          updateV({ oldPriceUsd: s === "" ? null : Number(s) })
                        }
                      />
                    </div>
                    <div className="my-5 flex flex-wrap gap-3">
                      {v.images.map((src, i) => (
                        <div
                          key={src + i}
                          className="relative h-24 w-24 rounded-xl border border-line"
                        >
                          <ProductImage
                            src={src}
                            alt="Фото варианта"
                            sizes="96px"
                          />
                          <button
                            aria-label={"Удалить фото " + (i + 1)}
                            className="absolute top-0 right-0 rounded-full bg-surface px-2"
                            onClick={() =>
                              updateV({
                                images: v.images.filter((_, j) => j !== i),
                              })
                            }
                          >
                            ×
                          </button>
                        </div>
                      ))}
                    </div>
                    <label className="admin-label">
                      Добавить фотографии (JPG, PNG, WebP до 10 МБ)
                      <input
                        type="file"
                        multiple
                        accept="image/jpeg,image/png,image/webp"
                        disabled={busy}
                        onChange={(e) => {
                          const files = Array.from(e.target.files || []);
                          action(async () => {
                            const urls: string[] = [];
                            for (const f of files) urls.push(await upload(f));
                            updateV({ images: [...v.images, ...urls] });
                            setMessage(
                              "Фотографии загружены. Сохраните изменения.",
                            );
                          });
                        }}
                      />
                    </label>
                    <button
                      className="mt-6 text-sm text-red-700 disabled:opacity-30"
                      disabled={p.variants.length === 1}
                      onClick={() => {
                        updateP({
                          variants: p.variants.filter((_, i) => i !== variant),
                        });
                        setVariant(0);
                      }}
                    >
                      Удалить вариант
                    </button>
                  </>
                )}
                <button
                  className="mt-8 block text-sm text-red-700"
                  onClick={() => {
                    if (confirm("Удалить модель и все её варианты?")) {
                      mutate((x) => x.products.splice(selected, 1));
                      setSelected(0);
                      setVariant(0);
                    }
                  }}
                >
                  Удалить модель
                </button>
              </section>
            )}
          </div>
        )}
        {tab === "Цены" && (
          <section>
            <PriceListEditor dirty={dirty} revision={d.revision} onSaved={(next) => { setD(next); setDirty(false); }} />
            <div className="grid gap-4 sm:grid-cols-2">
              <label className="admin-label">
                Категория
                <select
                  className="field"
                  value={cat}
                  aria-label="Категория"
                  onChange={(e) => {
                    setCat(e.target.value);
                    setSubcat("");
                  }}
                >
                  <option value="">Все категории</option>
                  <option value="__used">Б/У устройства</option>
                  {d.categories.map((c) => (
                    <option key={c.slug} value={c.slug}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </label>
              <Field label="Модель или SKU" value={query} onChange={setQuery} />
              {!!d.categories.find((c) => c.slug === cat)?.subcategories
                ?.length && (
                <label className="admin-label">
                  Подкатегория
                  <select
                    className="field"
                    value={subcat}
                    onChange={(e) => setSubcat(e.target.value)}
                  >
                    <option value="">Все подкатегории</option>
                    {d.categories
                      .find((c) => c.slug === cat)!
                      .subcategories!.map((s) => (
                        <option key={s.slug} value={s.slug}>
                          {s.name}
                        </option>
                      ))}
                  </select>
                </label>
              )}
              <label className="flex items-center gap-2 text-sm">
                <input
                  type="checkbox"
                  checked={onlySale}
                  onChange={(e) => setOnlySale(e.target.checked)}
                />
                Только со скидкой
              </label>
            </div>
            <div className="mt-6 overflow-x-auto rounded-card border border-line bg-surface">
              <table className="w-full min-w-[700px] text-left text-sm">
                <thead>
                  <tr>
                    {[
                      "Модель / вариант",
                      "База USD",
                      "Ручная USD",
                      "Старая USD / SALE",
                      "Наличие",
                    ].map((t) => (
                      <th className="p-4 font-medium" key={t}>
                        {t}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {d.products.flatMap((m, pi) =>
                    (!cat || cat === m.category) &&
                    (!subcat || subcat === m.subcategory)
                      ? m.variants.map((n, vi) =>
                          (m.name + " " + n.sku)
                            .toLowerCase()
                            .includes(query.toLowerCase()) &&
                          (!onlySale || n.oldPriceUsd != null) ? (
                            <tr key={n.sku} className="border-t border-line">
                              <td className="p-4">
                                <b>{m.name}</b>
                                <p className="mt-1 text-xs text-muted">
                                  {n.storageGb} ГБ · {n.colorName} · {n.sim}
                                  <br />
                                  {n.sku}
                                </p>
                              </td>
                              {(
                                [
                                  "basePriceUsd",
                                  "manualPriceUsd",
                                  "oldPriceUsd",
                                ] as const
                              ).map((k) => (
                                <td className="p-3" key={k}>
                                  <input
                                    aria-label={m.name + " " + n.sku + " " + k}
                                    className="field w-32"
                                    type="number"
                                    min="0"
                                    value={n[k] ?? ""}
                                    onChange={(e) =>
                                      mutate(
                                        (x) =>
                                          (x.products[pi].variants[vi][k] =
                                            e.target.value === ""
                                              ? null
                                              : Number(e.target.value)),
                                      )
                                    }
                                  />
                                </td>
                              ))}
                              <td className="p-3">
                                <select
                                  className="field"
                                  aria-label={"Наличие " + n.sku}
                                  value={n.status}
                                  onChange={(e) =>
                                    mutate(
                                      (x) =>
                                        (x.products[pi].variants[vi].status = e
                                          .target.value as Variant["status"]),
                                    )
                                  }
                                >
                                  {Object.entries(statusLabels).map(
                                    ([k, t]) => (
                                      <option key={k} value={k}>
                                        {t}
                                      </option>
                                    ),
                                  )}
                                </select>
                              </td>
                            </tr>
                          ) : null,
                        )
                      : [],
                  )}
                  {(!cat || cat === "__used") &&
                    d.used.map((n, i) =>
                      (n.name + " " + n.id)
                        .toLowerCase()
                        .includes(query.toLowerCase()) &&
                      (!onlySale || n.oldPriceUsd != null) ? (
                        <tr
                          key={"used-" + n.id}
                          className="border-t border-line"
                        >
                          <td className="p-4">
                            <b>{n.name}</b>
                            <p className="mt-1 text-xs text-muted">
                              Б/У · {n.storageGb} ГБ · {n.colorName}
                              <br />
                              {n.id}
                            </p>
                          </td>
                          <td className="p-3 text-muted">—</td>
                          {(["priceUsd", "oldPriceUsd"] as const).map((k) => (
                            <td key={k} className="p-3">
                              <input
                                className="field w-32"
                                type="number"
                                min="0"
                                aria-label={n.name + " " + n.id + " " + k}
                                value={n[k] ?? ""}
                                onChange={(e) =>
                                  mutate((x) => {
                                    if (k === "priceUsd")
                                      x.used[i].priceUsd = Number(
                                        e.target.value,
                                      );
                                    else
                                      x.used[i].oldPriceUsd =
                                        e.target.value === ""
                                          ? null
                                          : Number(e.target.value);
                                  })
                                }
                              />
                            </td>
                          ))}
                          <td className="p-3">
                            <select
                              className="field"
                              aria-label={"Наличие Б/У " + n.id}
                              value={n.sold ? "sold" : "available"}
                              onChange={(e) =>
                                mutate((x) => {
                                  x.used[i].sold = e.target.value === "sold";
                                })
                              }
                            >
                              <option value="available">В наличии</option>
                              <option value="sold">Скрыт / продан</option>
                            </select>
                          </td>
                        </tr>
                      ) : null,
                    )}
                </tbody>
              </table>
            </div>
          </section>
        )}
        {tab === "Б/У" && (
          <section className="rounded-block border border-line bg-surface p-5">
            <div className="mb-5 flex flex-wrap gap-4">
              <select
                className="field max-w-md"
                aria-label="Б/У экземпляр"
                value={usedIndex}
                onChange={(e) => setUsedIndex(Number(e.target.value))}
              >
                {d.used.map((n, i) => (
                  <option key={n.id} value={i}>
                    {n.name} · {n.id}
                    {n.sold ? " · продан" : ""}
                  </option>
                ))}
              </select>
              <button
                className="text-sm text-accent"
                onClick={() => {
                  mutate((x) =>
                    x.used.push({
                      id: "used-" + Date.now(),
                      slug: "used-" + Date.now(),
                      name: "Б/У устройство",
                      storageGb: 128,
                      colorName: "",
                      condition: "good",
                      conditionNote: "",
                      batteryHealth: 100,
                      batteryReplaced: false,
                      kit: [],
                      checks: [],
                      defects: null,
                      warrantyMonths: 0,
                      priceUsd: 0,
                      images: [],
                      sold: true,
                    }),
                  );
                  setUsedIndex(d.used.length);
                }}
              >
                ＋ Добавить экземпляр
              </button>
            </div>
            {u ? (
              <>
                <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                  {(
                    [
                      "name",
                      "id",
                      "slug",
                      "colorName",
                      "conditionNote",
                    ] as const
                  ).map((k) => (
                    <Field
                      key={k}
                      label={
                        {
                          name: "Название",
                          id: "ID",
                          slug: "URL (slug)",
                          colorName: "Цвет",
                          conditionNote: "Описание состояния",
                        }[k]
                      }
                      value={u[k]}
                      onChange={(s) => updateU({ [k]: s })}
                    />
                  ))}
                  {(
                    [
                      "storageGb",
                      "batteryHealth",
                      "warrantyMonths",
                      "priceUsd",
                    ] as const
                  ).map((k) => (
                    <Field
                      key={k}
                      type="number"
                      label={
                        {
                          storageGb: "Память, ГБ",
                          batteryHealth: "Аккумулятор, %",
                          warrantyMonths: "Гарантия, месяцев",
                          priceUsd: "Цена, USD",
                        }[k]
                      }
                      value={u[k]}
                      onChange={(s) => updateU({ [k]: Number(s) })}
                    />
                  ))}
                  <Field
                    label="Старая цена Б/У, USD (SALE)"
                    type="number"
                    value={u.oldPriceUsd ?? ""}
                    onChange={(s) =>
                      updateU({ oldPriceUsd: s === "" ? null : Number(s) })
                    }
                  />
                  <label className="admin-label">
                    Состояние
                    <select
                      className="field"
                      value={u.condition}
                      onChange={(e) =>
                        updateU({
                          condition: e.target.value as UsedUnit["condition"],
                        })
                      }
                    >
                      <option value="excellent">Отличное</option>
                      <option value="good">Хорошее</option>
                      <option value="fair">Со следами использования</option>
                    </select>
                  </label>
                  {(["kit", "checks"] as const).map((k) => (
                    <label key={u.id + k} className="admin-label">
                      {k === "kit"
                        ? "Комплект (через запятую)"
                        : "Проверки (через запятую)"}
                      <input
                        className="field"
                        defaultValue={u[k].join(", ")}
                        onBlur={(e) =>
                          updateU({
                            [k]: e.target.value
                              .split(",")
                              .map((x) => x.trim())
                              .filter(Boolean),
                          })
                        }
                      />
                    </label>
                  ))}
                  <Field
                    label="Дефекты"
                    value={u.defects || ""}
                    onChange={(s) => updateU({ defects: s || null })}
                  />
                </div>
                <div className="my-5 flex gap-6 text-sm">
                  <label>
                    <input
                      className="mr-2"
                      type="checkbox"
                      checked={u.batteryReplaced}
                      onChange={(e) =>
                        updateU({ batteryReplaced: e.target.checked })
                      }
                    />
                    Аккумулятор заменён
                  </label>
                  <label>
                    <input
                      className="mr-2"
                      type="checkbox"
                      checked={!!u.sold}
                      onChange={(e) => updateU({ sold: e.target.checked })}
                    />
                    Продан / скрыт
                  </label>
                </div>
                <div className="my-5 flex flex-wrap gap-3">
                  {u.images.map((src, i) => (
                    <div key={src + i} className="relative h-24 w-24">
                      <ProductImage src={src} alt="Б/У фото" />
                      <button
                        className="absolute top-0 right-0 bg-surface px-2"
                        aria-label={"Удалить фото " + i}
                        onClick={() =>
                          updateU({
                            images: u.images.filter((_, j) => j !== i),
                          })
                        }
                      >
                        ×
                      </button>
                    </div>
                  ))}
                </div>
                <label className="admin-label">
                  Реальные фото экземпляра (обязательны)
                  <input
                    type="file"
                    multiple
                    accept="image/jpeg,image/png,image/webp"
                    disabled={busy}
                    onChange={(e) => {
                      const files = Array.from(e.target.files || []);
                      action(async () => {
                        const urls = [];
                        for (const f of files) urls.push(await upload(f));
                        updateU({ images: [...u.images, ...urls] });
                      });
                    }}
                  />
                </label>
                <button
                  className="mt-7 text-sm text-red-700"
                  onClick={() => {
                    if (confirm("Удалить экземпляр?")) {
                      mutate((x) => x.used.splice(usedIndex, 1));
                      setUsedIndex(0);
                    }
                  }}
                >
                  Удалить экземпляр
                </button>
              </>
            ) : (
              <p className="text-sm text-muted">
                Нет экземпляров. Добавьте устройство и его реальные фото.
              </p>
            )}
          </section>
        )}
        {tab === "Настройки" && (
          <section className="rounded-block border border-line bg-surface p-5 sm:p-7">
            <h2 className="mb-5 text-xl font-semibold">Цены и контакты</h2>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field
                label="Глобальный коэффициент"
                type="number"
                value={d.settings.coefficient}
                onChange={(s) =>
                  mutate((x) => (x.settings.coefficient = Number(s)))
                }
              />
              <label className="admin-label">
                Округление USD
                <select
                  className="field"
                  value={d.settings.rounding}
                  onChange={(e) =>
                    mutate(
                      (x) =>
                        (x.settings.rounding = Number(e.target.value) as
                          1 | 5 | 10 | 50),
                    )
                  }
                >
                  {[1, 5, 10, 50].map((n) => (
                    <option key={n} value={n}>
                      До {n}
                    </option>
                  ))}
                </select>
              </label>
              {(
                [
                  "phone",
                  "telegramUrl",
                  "telegramChannel",
                  "instagramUrl",
                  "address",
                  "hours",
                  "email",
                  "legalName",
                  "legalId",
                ] as const
              ).map((k) => (
                <Field
                  key={k}
                  label={
                    {
                      phone: "Телефон",
                      telegramUrl: "Telegram менеджера (https://t.me/...)",
                      telegramChannel: "Telegram-канал",
                      instagramUrl: "Instagram",
                      address: "Адрес самовывоза",
                      hours: "График / запись",
                      email: "Email",
                      legalName: "Продавец",
                      legalId: "УНП",
                    }[k]
                  }
                  value={d.settings[k]}
                  onChange={(s) => mutate((x) => (x.settings[k] = s))}
                />
              ))}
            </div>
            <p className="mt-4 text-xs text-muted">
              Порядок моделей меняется в редакторе. Ручная цена не умножается на
              коэффициент.
            </p>
          </section>
        )}
        {tab === "Excel" && (
          <section className="rounded-block border border-line bg-surface p-5 sm:p-7">
            <h2 className="text-xl font-semibold">
              Импорт с предварительным отчётом
            </h2>
            <p className="my-4 max-w-2xl text-sm leading-relaxed text-muted">
              Сопоставление по SKU. Пустая цена очищает поле. Позиции,
              отсутствующие в файле, сохраняются. Сначала сохраните текущие
              изменения.
            </p>
            <a
              className="text-sm text-accent underline"
              href="/api/admin/excel"
            >
              Скачать каталог для изменения .xlsx
            </a>
            <label className="admin-label mt-6">
              Загрузить .xlsx до 2 МБ
              <input
                type="file"
                accept=".xlsx"
                disabled={busy || dirty}
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file)
                    action(async () => {
                      const f = new FormData();
                      f.set("file", file);
                      setPreview(
                        await call("/api/admin/excel", {
                          method: "POST",
                          body: f,
                        }),
                      );
                    });
                }}
              />
            </label>
            {preview && (
              <>
                <div className="my-5 flex flex-wrap gap-4 text-sm">
                  {Object.entries(preview.counts).map(([k, n]) => (
                    <span key={k}>
                      {
                        {
                          new: "Новые",
                          changed: "Изменены",
                          unchanged: "Без изменений",
                          error: "Ошибки",
                        }[k]
                      }
                      : {n}
                    </span>
                  ))}
                </div>
                <div className="max-h-80 overflow-auto">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr>
                        <th>Строка</th>
                        <th>SKU</th>
                        <th>Результат</th>
                        <th>Примечание</th>
                      </tr>
                    </thead>
                    <tbody>
                      {preview.report.map((r, i) => (
                        <tr className="border-t border-line" key={i}>
                          <td className="py-3">{r.row || "Файл"}</td>
                          <td>{r.sku}</td>
                          <td>{r.result}</td>
                          <td>{r.message}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <button
                  className="mt-6 rounded-full bg-accent px-6 py-3 text-sm text-canvas disabled:opacity-30"
                  disabled={!preview.candidate || busy}
                  onClick={() => {
                    setD(preview.candidate);
                    setDirty(true);
                    setPreview(null);
                    setMessage(
                      "Импорт подготовлен. Нажмите «Сохранить изменения» для публикации.",
                    );
                  }}
                >
                  Применить в редакторе
                </button>
                <button
                  className="ml-5 text-sm text-muted"
                  onClick={() => setPreview(null)}
                >
                  Отменить
                </button>
              </>
            )}
          </section>
        )}
        {tab === "Тексты" && (
          <ContentEditor
            pages={d.pages}
            onChange={(pages) => mutate((x) => (x.pages = pages))}
          />
        )}
        {tab === "Сайт" && <SiteEditor value={d.presentation} upload={upload} onChange={p => mutate(x => {x.presentation=p;})} />}
        {tab === "Данные канала" && <section className="rounded-block border border-line bg-surface p-5 sm:p-7"><h2 className="text-xl font-semibold">Архив прайса и источники магазина</h2><p className="my-4 text-sm text-muted">{SOURCE.notice}</p><a href={SOURCE.sourceUrl} target="_blank" rel="noopener noreferrer" className="text-sm text-accent underline">Первичная публикация от {SOURCE.publishedAt} ↗</a><p className="my-4 text-xs text-muted">Проверено {SOURCE.checkedAt}. {SOURCE.limitations}</p><dl className="grid gap-3 rounded-card bg-canvas p-5 text-sm sm:grid-cols-2">{Object.entries(SOURCE.verified).map(([key,value])=><div key={key}><dt className="text-xs text-muted">{{phone:"Телефон",manager:"Менеджер",channel:"Канал",instagram:"Instagram",hours:"График",delivery:"Доставка",gifts:"Подарки",legal:"Продавец",legalAddress:"Юридический адрес",pickup:"Самовывоз"}[key]}</dt><dd className="mt-1 break-words">{value}</dd></div>)}</dl><h3 className="mt-7 font-semibold">Опубликованные предложения: {SOURCE.offers.length}</h3><ul className="mt-4 divide-y divide-line">{SOURCE.offers.map((o,i)=><li key={i} className="py-3 text-sm">{o.offer}<span className="ml-3 text-xs text-muted">Архив, {o.sourceDate}</span></li>)}</ul></section>}
        {tab === "Категории" && <CategoryEditor data={d} onChange={mutate} upload={upload} />}
        {tab === "Trade-in" && (
          <TradeInEditor
            rates={d.tradeIn || []}
            settings={d.tradeInSettings || DEFAULT_TRADE_IN_SETTINGS}
            onSettingsChange={(settings) => mutate((x) => { x.tradeInSettings = settings; })}
            onChange={(rates) =>
              mutate((x) => {
                x.tradeIn = rates;
              })
            }
          />
        )}
      </fieldset>
    </div>
  );
}
