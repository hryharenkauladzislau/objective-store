"use client";
import { useState } from "react";
import type { TradeInRate } from "@/lib/trade-in";
import type { CatalogDocument } from "@/lib/schema";
export function TradeInEditor({
  rates,
  onChange,
  settings,
  onSettingsChange,
}: {
  rates: TradeInRate[];
  onChange: (rates: TradeInRate[]) => void;
  settings: NonNullable<CatalogDocument["tradeInSettings"]>;
  onSettingsChange: (settings: NonNullable<CatalogDocument["tradeInSettings"]>) => void;
}) {
  const [query, setQuery] = useState("");
  const edit = (i: number, part: Partial<TradeInRate>) =>
    onChange(rates.map((r, j) => (j === i ? { ...r, ...part } : r)));
  return (
    <div className="space-y-6">
    <section className="rounded-block border border-line bg-white p-5 sm:p-7">
      <h2 className="text-xl font-semibold">Настройки анкеты</h2>
      <p className="my-4 text-sm text-muted">Списки вводятся по одному варианту в строке. Они сразу меняют форму для клиента.</p>
      <div className="grid gap-4 lg:grid-cols-3">
        {([ ["deviceTypes","Типы устройств"], ["conditionOptions","Состояние"], ["workOptions","Работоспособность"] ] as const).map(([key,label]) => <label key={key} className="admin-label">{label}<textarea className="field min-h-36" value={settings[key].join("\n")} onChange={(e)=>onSettingsChange({...settings,[key]:e.target.value.split("\n").map(x=>x.trim()).filter(Boolean)})}/></label>)}
      </div>
      <div className="mt-4 grid gap-4">
        <label className="admin-label">Вводный текст<textarea className="field min-h-24" value={settings.intro} onChange={(e)=>onSettingsChange({...settings,intro:e.target.value})}/></label>
        <label className="admin-label">Пояснение к оценке<textarea className="field min-h-24" value={settings.estimateNotice} onChange={(e)=>onSettingsChange({...settings,estimateNotice:e.target.value})}/></label>
        <label className="admin-label">Пояснение о фотографиях<textarea className="field min-h-24" value={settings.photoNotice} onChange={(e)=>onSettingsChange({...settings,photoNotice:e.target.value})}/></label>
      </div>
    </section>
    <section className="rounded-block border border-line bg-white p-5 sm:p-7">
      <div className="flex flex-wrap justify-between gap-4">
        <h2 className="text-xl font-semibold">Прайс Trade-in</h2>
        <button
          className="text-sm text-accent"
          onClick={() =>
            onChange([
              ...rates,
              {
                id: "rate-" + crypto.randomUUID().slice(0, 8),
                model: "Новая модель",
                storageGb: null,
                maxPrice: 100,
                currency: "USD",
                sourceUrl: "https://eappl.by/",
                checkedAt: new Date().toISOString().slice(0, 10),
                approved: false,
              },
            ])
          }
        >
          ＋ Оценка
        </button>
      </div>
      <p className="my-4 text-sm leading-relaxed text-muted">
        Исходный прайс iStock — российские рубли и максимальные оценки. Не
        переносите их в USD без пересчёта. После проверки своей суммы и валюты
        включите «Цена магазина». До этого клиент видит подписанный сторонний
        ориентир. Для устройств с повреждениями нужна оценка менеджера.
      </p>
      <label className="admin-label">
        Поиск модели
        <input
          className="field"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
      </label>
      <div className="mt-5 space-y-4">
        {rates.map((r, i) =>
          r.model.toLowerCase().includes(query.toLowerCase()) ? (
            <div key={r.id} className="rounded-card border border-line p-4">
              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                <label className="admin-label">
                  Модель
                  <input
                    className="field"
                    value={r.model}
                    onChange={(e) => edit(i, { model: e.target.value })}
                  />
                </label>
                <label className="admin-label">
                  Память, ГБ (пусто — любая)
                  <input
                    className="field"
                    type="number"
                    min="1"
                    value={r.storageGb ?? ""}
                    onChange={(e) =>
                      edit(i, {
                        storageGb: e.target.value
                          ? Number(e.target.value)
                          : null,
                      })
                    }
                  />
                </label>
                <label className="admin-label">
                  Оценка до
                  <input
                    className="field"
                    type="number"
                    min="1"
                    value={r.maxPrice}
                    onChange={(e) =>
                      edit(i, { maxPrice: Number(e.target.value) })
                    }
                  />
                </label>
                <label className="admin-label">
                  Валюта
                  <select
                    className="field"
                    value={r.currency}
                    onChange={(e) =>
                      edit(i, {
                        currency: e.target.value as TradeInRate["currency"],
                      })
                    }
                  >
                    {["USD", "BYN", "RUB"].map((c) => (
                      <option key={c}>{c}</option>
                    ))}
                  </select>
                </label>
                <label className="admin-label sm:col-span-2">
                  Источник оценки (HTTPS)
                  <input
                    className="field"
                    type="url"
                    value={r.sourceUrl}
                    onChange={(e) => edit(i, { sourceUrl: e.target.value })}
                  />
                </label>
                <label className="admin-label">
                  Дата проверки
                  <input
                    className="field"
                    type="date"
                    value={r.checkedAt}
                    onChange={(e) => edit(i, { checkedAt: e.target.value })}
                  />
                </label>
              </div>
              <div className="mt-4 flex justify-between gap-4 text-sm">
                <label>
                  <input
                    className="mr-2"
                    type="checkbox"
                    checked={r.approved}
                    onChange={(e) => edit(i, { approved: e.target.checked })}
                  />
                  Цена магазина утверждена
                </label>
                <button
                  className="text-red-700"
                  aria-label={"Удалить оценку " + r.model}
                  onClick={() => onChange(rates.filter((_, j) => j !== i))}
                >
                  Удалить
                </button>
              </div>
            </div>
          ) : null,
        )}
      </div>
    </section></div>
  );
}
