"use client";
import { useState } from "react";
import type { CatalogDocument } from "@/lib/schema";
type Preview = { candidate: CatalogDocument; changes: { sku: string; name: string; before: number; after: number }[]; rows: number };
export function PriceListEditor({ dirty, revision, onSaved }: { dirty: boolean; revision: number; onSaved: (d: CatalogDocument) => void }) {
  const [preview, setPreview] = useState<Preview | null>(null);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  async function response(r: Response) {
    const data = await r.json();
    if (!r.ok) throw new Error(data.error || "Не удалось обновить цены");
    return data;
  }
  return <div className="mb-7 rounded-block border border-line bg-surface p-5 sm:p-7">
    <h2 className="text-xl font-semibold">Цены через TXT</h2>
    <p className="mt-3 text-sm leading-relaxed text-muted">Одна строка — один вариант памяти, цвета и версии. Последнее число — цена в USD. Измените его и загрузите файл обратно. Для новой техники 0 означает цену по запросу.</p>
    {dirty && <p className="mt-3 text-sm text-signal-ink">Сначала сохраните изменения в админке.</p>}
    <div className="mt-5 flex flex-wrap items-center gap-4">
      <a aria-disabled={dirty || undefined} className={"rounded-full border border-line px-5 py-3 text-sm font-semibold " + (dirty ? "pointer-events-none opacity-40" : "hover:border-accent")} href={dirty ? undefined : "/api/admin/prices"}>Скачать TXT</a>
      <label className="text-sm">Загрузить TXT<input aria-label="Загрузить TXT с ценами" className="ml-3 max-w-full text-xs" type="file" accept=".txt,text/plain" disabled={busy || dirty} onChange={async (e) => {
        const file = e.target.files?.[0]; e.target.value = ""; if (!file) return;
        setBusy(true); setMessage(""); setPreview(null);
        try { const form = new FormData(); form.set("file", file); setPreview(await response(await fetch("/api/admin/prices", { method: "POST", body: form }))); }
        catch (e) { setMessage((e as Error).message); } finally { setBusy(false); }
      }}/></label>
    </div>
    {message && <p role="status" className="mt-4 text-sm">{message}</p>}
    {preview && <div className="mt-5">
      <p className="text-sm">Прочитано вариантов: {preview.rows}. Изменено цен: {preview.changes.length}.</p>
      {!!preview.changes.length && <><div className="mt-3 max-h-80 overflow-auto rounded-card border border-line"><table className="w-full min-w-[500px] text-left text-sm"><thead><tr><th className="p-3">Вариант</th><th className="p-3">Было USD</th><th className="p-3">Стало USD</th></tr></thead><tbody>{preview.changes.map((c) => <tr key={c.sku} className="border-t border-line"><td className="p-3">{c.name}</td><td className="p-3">{c.before || "По запросу"}</td><td className="p-3">{c.after || "По запросу"}</td></tr>)}</tbody></table></div><button className="mt-4 rounded-full bg-accent px-5 py-3 text-sm font-semibold text-canvas disabled:opacity-40" disabled={busy || dirty || revision !== preview.candidate.revision} onClick={async () => {
        setBusy(true); setMessage("");
        try { onSaved(await response(await fetch("/api/admin/catalog", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(preview.candidate) }))); setPreview(null); setMessage("Цены обновлены на сайте."); }
        catch (e) { setMessage((e as Error).message); } finally { setBusy(false); }
      }}>{busy ? "Сохранение…" : "Применить цены"}</button></>}
    </div>}
  </div>;
}
