import Link from "next/link";
import { ProductImage } from "@/components/catalog/ProductImage";
import type { HomeBlock } from "@/lib/presentation";

export function DeviceScene({ block }: { block: HomeBlock }) {
  return <section className="device-scene" aria-label={block.title}>
    <div className="device-scene-heading"><p className="editorial-eyebrow">{block.kicker}</p><h2>{block.title}</h2>
      {block.body && <p className="editorial-description">{block.body}</p>}
    </div>
    <div className="device-scene-grid">{block.items.map((item,i) => <Link key={i} href={item.href||block.ctaHref}
      className={`device-motion device-motion-${i%3}`} data-device-motion data-depth={[.13,-.12,.16][i%3]} data-rotate={[18,-24,12][i%3]}>
      <div className="device-tilt" data-tilt><div className="device-float"><div className="device-cutout">
        <ProductImage src={item.image} alt={item.title} sizes="(max-width:640px) 80vw,33vw" className="object-contain"/>
      </div></div></div>
      <h3>{item.title}</h3>{item.text&&<p>{item.text}</p>}
    </Link>)}</div>
    {block.ctaLabel&&<Link href={block.ctaHref} className="editorial-link">{block.ctaLabel}</Link>}
  </section>;
}
