/** A lightweight CSS 3D mockup, not a product configurator or a stock video. */
export function PhoneSculpture({ compact = false }: { compact?: boolean }) {
  return <div className={`phone-stage${compact ? " phone-stage-compact" : ""}`} aria-hidden="true" data-device-motion>
    <div className="phone-stage-shadow" />
    <div className="phone-pointer" data-tilt>
      <div className="phone-orbit">
        <div className="phone-object">
          <div className="phone-plane phone-back">
            <div className="phone-camera-plate">
              {[0, 1, 2].map(i => <span key={i} className={`phone-lens phone-lens-${i}`}><i /><b /></span>)}
              <span className="phone-flash" /><span className="phone-sensor" />
            </div>
            <span className="phone-back-emblem">EA</span>
          </div>
          <div className="phone-plane phone-front"><div className="phone-display"><span className="phone-island" /><div className="phone-screen-art" /></div></div>
          <div className="phone-edge phone-edge-left"><span /></div>
          <div className="phone-edge phone-edge-right"><span /></div>
          <div className="phone-edge phone-edge-top" />
          <div className="phone-edge phone-edge-bottom" />
        </div>
      </div>
    </div>
  </div>;
}
