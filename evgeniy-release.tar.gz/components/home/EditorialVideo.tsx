"use client";
import { useEffect, useRef, useState } from "react";

/** Local, muted product footage. Real Apple frames, never a reconstructed device. */
export function EditorialVideo({ variant = "design", className = "" }: {
  variant?: "design" | "unibody";
  className?: string;
}) {
  const ref = useRef<HTMLVideoElement>(null);
  const [playing, setPlaying] = useState(false);
  const src = `/videos/iphone-18-${variant}-loop.mp4`;
  const poster = `/images/editorial/iphone-18-${variant}-poster.webp`;
  useEffect(() => {
    const video = ref.current;
    if (!video) return;
    const reduced = matchMedia("(prefers-reduced-motion: reduce)");
    let visible = false;
    const update = () => {
      if (visible && !reduced.matches && !document.hidden) void video.play().catch(() => {});
      else video.pause();
    };
    const observer = new IntersectionObserver(entries => {
      visible = entries[0].isIntersecting; update();
    }, { threshold: 0.15 });
    observer.observe(video);
    reduced.addEventListener("change", update);
    document.addEventListener("visibilitychange", update);
    return () => { observer.disconnect(); reduced.removeEventListener("change", update); document.removeEventListener("visibilitychange", update); video.pause(); };
  }, [src]);
  return <div className={`official-device-film ${className} ${playing ? "film-playing" : ""}`} data-device-motion aria-hidden="true">
    {/* A separate poster stays visible if autoplay is blocked, or motion is reduced. */}
    {/* eslint-disable-next-line @next/next/no-img-element */}
    <img src={poster} alt="" className="official-film-poster" />
    <video ref={ref} src={src} poster={poster} muted loop playsInline preload="metadata"
      tabIndex={-1} className={playing ? "official-film-video is-playing" : "official-film-video"}
      onPlaying={() => setPlaying(true)} onPause={() => setPlaying(false)} onError={() => setPlaying(false)} />
  </div>;
}
