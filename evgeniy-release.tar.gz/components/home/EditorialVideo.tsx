"use client";
import { useEffect, useRef } from "react";

export function EditorialVideo() {
  const ref = useRef<HTMLVideoElement>(null);
  useEffect(() => {
    const video = ref.current;
    if (!video) return;
    const reduced = matchMedia("(prefers-reduced-motion: reduce)");
    let visible = false;
    const update = () => {
      if (visible && !reduced.matches && !document.hidden) void video.play().catch(() => {});
      else video.pause();
    };
    const observer = new IntersectionObserver(entries => {
      visible = entries[0].isIntersecting; update();
    });
    observer.observe(video);
    reduced.addEventListener("change", update);
    document.addEventListener("visibilitychange", update);
    return () => { observer.disconnect(); reduced.removeEventListener("change", update); document.removeEventListener("visibilitychange", update); video.pause(); };
  }, []);
  return <video ref={ref} className="editorial-hero-video" src="/videos/iphone-detail.mp4"
    poster="/images/editorial/dark.webp" muted loop playsInline preload="metadata" aria-hidden="true"/>;
}
