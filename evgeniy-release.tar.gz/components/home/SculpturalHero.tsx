import { Button } from "@/components/ui/Button";
import { ProductImage } from "@/components/catalog/ProductImage";
import { EditorialVideo } from "./EditorialVideo";
import type { HomeBlock } from "@/lib/presentation";

export function SculpturalHero({ block }: { block: HomeBlock }) {
  const words = block.title.trim().split(/\s+/);
  const appleIndex = words.indexOf("Apple");
  const end = appleIndex >= 0 ? words.slice(appleIndex).join(" ") : words.pop();
  const lead = appleIndex >= 0 ? words.slice(0, appleIndex).join(" ") : words.join(" ");
  return <div className="sculptural-hero">
    <div className="sculptural-hero-copy">
      <p className="editorial-eyebrow">{block.kicker}</p>
      <h1 className={appleIndex >= 0 ? "hero-title-long" : undefined}>{lead && <span>{lead}</span>}{" "}<strong>{end}</strong></h1>
      {block.body && <p className="sculptural-hero-description">{block.body}</p>}
      {block.ctaLabel && <Button href={block.ctaHref} className="sculptural-hero-cta">{block.ctaLabel}</Button>}
    </div>
    <div className="sculptural-hero-art">
      {block.image && <span className="sculptural-hero-word" aria-hidden="true">APPLE</span>}
      {block.image ? <div className="sculptural-hero-custom" data-tilt><ProductImage src={block.image} alt="" priority className="object-cover" sizes="(max-width:767px) 100vw,50vw" /></div> : <EditorialVideo className="hero-device-film" />}
      <div className="sculptural-art-label" aria-hidden="true"><span>EVGENIY APPLE</span><span>DESIGN / DEVICE</span></div>
    </div>
  </div>;
}
