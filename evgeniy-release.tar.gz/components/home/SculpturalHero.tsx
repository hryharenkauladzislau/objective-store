import { Button } from "@/components/ui/Button";
import { ProductImage } from "@/components/catalog/ProductImage";
import { PhoneSculpture } from "./PhoneSculpture";
import type { HomeBlock } from "@/lib/presentation";

export function SculpturalHero({ block }: { block: HomeBlock }) {
  const words = block.title.trim().split(/\s+/);
  const end = words.pop();
  return <div className="sculptural-hero">
    <div className="sculptural-hero-copy">
      <p className="editorial-eyebrow">{block.kicker}</p>
      <h1>{words.length > 0 && <span>{words.join(" ")}</span>}<strong>{end}</strong></h1>
      {block.body && <p className="sculptural-hero-description">{block.body}</p>}
      {block.ctaLabel && <Button href={block.ctaHref} className="sculptural-hero-cta">{block.ctaLabel}</Button>}
    </div>
    <div className="sculptural-hero-art">
      <span className="sculptural-hero-word" aria-hidden="true">APPLE</span>
      {block.image ? <div className="sculptural-hero-custom" data-tilt><ProductImage src={block.image} alt="" priority className="object-cover" sizes="(max-width:767px) 100vw,50vw" /></div> : <PhoneSculpture />}
      <div className="sculptural-art-label" aria-hidden="true"><span>EVGENIY APPLE</span><span>DESIGN / DEVICE</span></div>
    </div>
  </div>;
}
