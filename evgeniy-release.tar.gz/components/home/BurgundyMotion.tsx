import Image from "next/image";

/** Bespoke CSS motion composition; static content remains visible without JS. */
export function BurgundyMotion() {
  return <div className="burgundy-motion" aria-hidden="true">
    <div className="burgundy-motion-orbit"><Image src="/images/editorial/iphone-18-burgundy.webp" alt="" fill sizes="(max-width:767px) 100vw,80vw" preload className="burgundy-motion-phone" /></div>
    <span className="burgundy-motion-caption">iPhone 18 Pro · Burgundy</span>
  </div>;
}
