"use client";

import { useEffect, useRef, type ReactNode } from "react";

/** Scroll motion is progressive enhancement; content remains visible without JS. */
export function EditorialMotion({ children }: { children: ReactNode }) {
  const root = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const element = root.current;
    if (!element) return;
    const reduced = matchMedia("(prefers-reduced-motion: reduce)");
    let frame = 0;
    const sections = element.querySelectorAll<HTMLElement>("[data-home-block]");
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add("editorial-entered");
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.08 });
    sections.forEach(section => observer.observe(section));
    const devices = element.querySelectorAll<HTMLElement>("[data-device-motion]");
    const deviceObserver = new IntersectionObserver(entries => entries.forEach(entry => entry.target.classList.toggle("motion-active", entry.isIntersecting)), { rootMargin: "50px" });
    devices.forEach(device => deviceObserver.observe(device));
    const update = () => {
      frame = 0;
      element.querySelectorAll<HTMLElement>("[data-depth]").forEach(card => {
        const rect = card.getBoundingClientRect();
        if (rect.bottom < -150 || rect.top > innerHeight + 150) return;
        const shift = reduced.matches ? 0 : Math.max(-65, Math.min(65,
          (innerHeight / 2 - rect.top - rect.height / 2) * Number(card.dataset.depth)));
        card.style.setProperty("--scroll-shift", `${shift}px`);
        const progress = Math.max(-1, Math.min(1, (innerHeight / 2 - rect.top - rect.height / 2) / innerHeight));
        card.style.setProperty("--scroll-rotate", `${reduced.matches ? 0 : progress * Number(card.dataset.rotate || 0)}deg`);
      });
    };
    const scroll = () => { if (!frame) frame = requestAnimationFrame(update); };
    const pointerMove = (event: PointerEvent) => {
      if (reduced.matches || event.pointerType !== "mouse") return;
      const target = (event.target as HTMLElement).closest<HTMLElement>("[data-tilt]");
      if (!target || !element.contains(target)) return;
      const box = target.getBoundingClientRect();
      target.style.setProperty("--tilt-x", `${(event.clientY - box.top - box.height / 2) / box.height * -10}deg`);
      target.style.setProperty("--tilt-y", `${(event.clientX - box.left - box.width / 2) / box.width * 12}deg`);
    };
    const pointerOut = (event: PointerEvent) => {
      const target = (event.target as HTMLElement).closest<HTMLElement>("[data-tilt]");
      if (target && !(event.relatedTarget instanceof Node && target.contains(event.relatedTarget))) {
        target.style.setProperty("--tilt-x", "0deg"); target.style.setProperty("--tilt-y", "0deg");
      }
    };
    element.addEventListener("pointermove", pointerMove, { passive: true });
    element.addEventListener("pointerout", pointerOut);
    window.addEventListener("scroll", scroll, { passive: true });
    window.addEventListener("resize", scroll);
    reduced.addEventListener("change", scroll);
    update();
    return () => {
      observer.disconnect(); deviceObserver.disconnect(); cancelAnimationFrame(frame);
      element.removeEventListener("pointermove", pointerMove); element.removeEventListener("pointerout", pointerOut);
      window.removeEventListener("scroll", scroll);
      window.removeEventListener("resize", scroll);
      reduced.removeEventListener("change", scroll);
    };
  }, []);
  return <div ref={root} className="premium-home">{children}</div>;
}
