"use client";

import { useEffect, useRef, type ReactNode } from "react";

/** Scroll motion is progressive enhancement; content remains visible without JS. */
export function EditorialMotion({ children }: { children: ReactNode }) {
  const root = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const element = root.current;
    if (!element) return;
    const reduced = matchMedia("(prefers-reduced-motion: reduce)");
    const desktopMotion = matchMedia("(min-width:1024px) and (hover:hover) and (pointer:fine)");
    let frame = 0;
    let pointerFrame = 0;
    let pointerSample: { target: HTMLElement; x: number; y: number } | null = null;
    const depthCards = element.querySelectorAll<HTMLElement>("[data-depth]");
    const lastShifts = new WeakMap<HTMLElement, number>();
    const sections = element.querySelectorAll<HTMLElement>("[data-home-block]");
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add("editorial-entered");
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.08 });
    sections.forEach(section => observer.observe(section));
    const revealItems = element.querySelectorAll<HTMLElement>(
      ".home-product-grid > a,.home-category,.home-steps > div,.home-benefits > a,.home-services > a,.home-quick-links > a,.editorial-photo-image,.device-cutout,.home-used-details > div"
    );
    const revealObserver = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (!entry.isIntersecting) return;
        entry.target.classList.add("motion-revealed");
        revealObserver.unobserve(entry.target);
      });
    }, { threshold: 0.12 });
    revealItems.forEach(item => {
      const siblings = item.parentElement?.children;
      const index = siblings ? Array.from(siblings).indexOf(item) : 0;
      item.style.setProperty("--reveal-delay", `${Math.min(index, 4) * 65}ms`);
      revealObserver.observe(item);
    });
    const devices = element.querySelectorAll<HTMLElement>("[data-device-motion]");
    const deviceObserver = new IntersectionObserver(entries => entries.forEach(entry => entry.target.classList.toggle("motion-active", entry.isIntersecting)), { rootMargin: "50px" });
    devices.forEach(device => deviceObserver.observe(device));
    const update = () => {
      frame = 0;
      // Batch all geometry reads before writing styles (no read/write layout thrash).
      const updates: { card: HTMLElement; shift: number }[] = [];
      depthCards.forEach(card => {
        if (reduced.matches || !desktopMotion.matches) {
          updates.push({ card, shift: 0 });
          return;
        }
        const rect = card.getBoundingClientRect();
        if (rect.bottom < -150 || rect.top > innerHeight + 150) return;
        const shift = Math.max(-45, Math.min(45,
          (innerHeight / 2 - rect.top - rect.height / 2) * Number(card.dataset.depth)));
        updates.push({ card, shift });
      });
      updates.forEach(({ card, shift }) => {
        if (Math.abs((lastShifts.get(card) ?? Infinity) - shift) < .5) return;
        card.style.setProperty("--scroll-shift", `${shift.toFixed(1)}px`);
        lastShifts.set(card, shift);
      });
    };
    const scroll = () => {
      if (!document.hidden && !reduced.matches && desktopMotion.matches && !frame) frame = requestAnimationFrame(update);
    };
    const mediaChange = () => { cancelAnimationFrame(frame); update(); };
    const updatePointer = () => {
      pointerFrame = 0;
      const sample = pointerSample;
      if (!sample || reduced.matches || !desktopMotion.matches) return;
      const box = sample.target.getBoundingClientRect();
      if (!box.width || !box.height) return;
      sample.target.style.setProperty("--tilt-x", `${(sample.y - box.top - box.height / 2) / box.height * -6}deg`);
      sample.target.style.setProperty("--tilt-y", `${(sample.x - box.left - box.width / 2) / box.width * 7}deg`);
    };
    const pointerMove = (event: PointerEvent) => {
      if (reduced.matches || !desktopMotion.matches || event.pointerType !== "mouse") return;
      const target = (event.target as HTMLElement).closest<HTMLElement>("[data-tilt]");
      if (!target || !element.contains(target)) return;
      pointerSample = { target, x: event.clientX, y: event.clientY };
      if (!pointerFrame) pointerFrame = requestAnimationFrame(updatePointer);
    };
    const pointerOut = (event: PointerEvent) => {
      const target = (event.target as HTMLElement).closest<HTMLElement>("[data-tilt]");
      if (target && !(event.relatedTarget instanceof Node && target.contains(event.relatedTarget))) {
        if (pointerSample?.target === target) pointerSample = null;
        target.style.setProperty("--tilt-x", "0deg"); target.style.setProperty("--tilt-y", "0deg");
      }
    };
    element.addEventListener("pointermove", pointerMove, { passive: true });
    element.addEventListener("pointerout", pointerOut);
    window.addEventListener("scroll", scroll, { passive: true });
    window.addEventListener("resize", scroll);
    reduced.addEventListener("change", mediaChange);
    desktopMotion.addEventListener("change", mediaChange);
    update();
    return () => {
      observer.disconnect(); revealObserver.disconnect(); deviceObserver.disconnect(); cancelAnimationFrame(frame); cancelAnimationFrame(pointerFrame);
      element.removeEventListener("pointermove", pointerMove); element.removeEventListener("pointerout", pointerOut);
      window.removeEventListener("scroll", scroll);
      window.removeEventListener("resize", scroll);
      reduced.removeEventListener("change", mediaChange);
      desktopMotion.removeEventListener("change", mediaChange);
    };
  }, []);
  return <div ref={root} className="premium-home">{children}</div>;
}
