"use client";

import { useEffect, useRef, type ReactNode } from "react";

/** Scroll motion is progressive enhancement; content remains visible without JS. */
export function EditorialMotion({ children }: { children: ReactNode }) {
  const root = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const element = root.current;
    if (!element) return;
    const reduced = matchMedia("(prefers-reduced-motion: reduce)");
    let frame = 0;
    const sections = element.querySelectorAll<HTMLElement>("[data-home-block]");
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add("editorial-entered");
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.08 });
    sections.forEach(section => observer.observe(section));
    const update = () => {
      frame = 0;
      element.querySelectorAll<HTMLElement>("[data-depth]").forEach(card => {
        const rect = card.getBoundingClientRect();
        if (rect.bottom < -150 || rect.top > innerHeight + 150) return;
        const shift = reduced.matches ? 0 : Math.max(-65, Math.min(65,
          (innerHeight / 2 - rect.top - rect.height / 2) * Number(card.dataset.depth)));
        card.style.setProperty("--scroll-shift", `${shift}px`);
      });
    };
    const scroll = () => { if (!frame) frame = requestAnimationFrame(update); };
    window.addEventListener("scroll", scroll, { passive: true });
    window.addEventListener("resize", scroll);
    reduced.addEventListener("change", scroll);
    update();
    return () => {
      observer.disconnect(); cancelAnimationFrame(frame);
      window.removeEventListener("scroll", scroll);
      window.removeEventListener("resize", scroll);
      reduced.removeEventListener("change", scroll);
    };
  }, []);
  return <div ref={root} className="premium-home">{children}</div>;
}
