import Link from "next/link";
import { ProductImage } from "@/components/catalog/ProductImage";
import type { HomeBlock } from "@/lib/presentation";

export function EditorialShowcase({ block }: { block: HomeBlock }) {
  return <section className="editorial-showcase" aria-label={block.title}>
    <div className="editorial-showcase-copy">
      <p className="editorial-eyebrow">{block.kicker}</p>
      <h2>{block.title}</h2>
      {block.body && <p className="editorial-description">{block.body}</p>}
      {block.ctaLabel && <Link className="editorial-link" href={block.ctaHref}>{block.ctaLabel}</Link>}
    </div>
    <div className="editorial-photos">
      {block.items.map((item, i) => <Link key={i} href={item.href || block.ctaHref}
        className={`editorial-photo editorial-photo-${i % 3}`} data-depth={[0.12,-0.16,0.2][i % 3]}>
        <div className="editorial-photo-image" data-tilt><ProductImage src={item.image} alt={item.title} sizes="(max-width:768px) 70vw,35vw" className="object-cover"/></div>
        <span>{item.title}</span>
      </Link>)}
    </div>
  </section>;
}
