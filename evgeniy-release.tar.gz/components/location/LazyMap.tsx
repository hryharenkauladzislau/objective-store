"use client";
import { useEffect, useRef, useState } from "react";

/** Native iframe lazy-loading can start kilometres down the page; use actual proximity. */
export function LazyMap({ src }: { src: string }) {
  const root = useRef<HTMLDivElement>(null);
  const [loaded, setLoaded] = useState(false);
  useEffect(() => {
    const node = root.current;
    if (!node) return;
    const observer = new IntersectionObserver(entries => {
      if (entries[0].isIntersecting) { setLoaded(true); observer.disconnect(); }
    }, { rootMargin: "150px" });
    observer.observe(node);
    return () => observer.disconnect();
  }, []);
  return <div ref={root} className="h-full min-h-[inherit]">
    {loaded && <iframe title="БЦ Аякс на Яндекс Картах" src={src} loading="lazy" allowFullScreen className="h-full min-h-[inherit] w-full border-0" />}
  </div>;
}
