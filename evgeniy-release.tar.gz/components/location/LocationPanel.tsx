import type { Presentation } from "@/lib/presentation";
import { LazyMap } from "./LazyMap";

export function LocationPanel({ value, compact = false }: { value: Presentation["location"]; compact?: boolean }) {
  if (!value.enabled) return null;
  return (
    <div className="location-panel grid overflow-hidden rounded-block border border-line bg-surface lg:grid-cols-[.82fr_1.18fr]">
      <div className="flex flex-col justify-between p-7 sm:p-10">
        <div>
          <p className="text-xs uppercase tracking-[.2em] text-muted">САМОВЫВОЗ ПО ЗАПИСИ</p>
          <h2 className="mt-4 text-3xl font-semibold tracking-tight sm:text-5xl">{value.title}</h2>
          <p className="mt-5 text-lg font-medium">{value.address}</p>
          <p className="mt-3 max-w-md text-sm leading-relaxed text-muted">{value.description}</p>
        </div>
        <a className="mt-8 inline-flex w-fit rounded-full bg-accent px-6 py-3 text-sm font-semibold text-canvas" href={value.directionsUrl} target="_blank" rel="noopener noreferrer">Построить маршрут</a>
      </div>
      <div className={compact ? "min-h-[340px]" : "min-h-[420px]"}>
        <LazyMap src={value.mapEmbedUrl} />
      </div>
    </div>
  );
}
