"use client";
import { useEffect, useState } from "react";
import { BrandMarkPlaceholder } from "@/components/brand/BrandMarkPlaceholder";
export function DartLoader() {
  const [visible, setVisible] = useState(false);
  const [progress, setProgress] = useState(0);
  useEffect(() => {
    try {
      if (sessionStorage.getItem("ea:boot")) return;
    } catch {}
    let disposed = false;
    let done = false;
    let tasks = 0;
    const bump = () => {
      if (disposed) return;
      tasks++;
      setProgress(tasks * 50);
      if (tasks >= 2) {
        done = true;
        setVisible(false);
        try {
          sessionStorage.setItem("ea:boot", "1");
        } catch {}
      }
    };
    document.fonts.ready.then(bump, bump);
    const img = document.querySelector<HTMLImageElement>(
      'img[data-boot-critical="true"]',
    );
    if (img && !img.complete) img.decode().then(bump, bump);
    else bump();
    const show = setTimeout(() => {
      if (!done) setVisible(true);
    }, 400);
    const limit = setTimeout(() => {
      setVisible(false);
      try {
        sessionStorage.setItem("ea:boot", "1");
      } catch {}
    }, 2500);
    return () => {
      disposed = true;
      clearTimeout(show);
      clearTimeout(limit);
    };
  }, []);
  if (!visible) return null;
  return (
    <div
      className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-canvas"
      role="status"
      aria-label={"Загрузка " + progress + "%"}
    >
      <div className="relative flex h-64 w-64 items-center justify-center">
        <BrandMarkPlaceholder className="text-xl" />
        {Array.from({ length: 8 }, (_, i) => (
          <span
            key={i}
            className="soft-dart absolute inset-0"
            style={{
              transform: "rotate(" + i * 45 + "deg)",
              opacity: i < progress / 12.5 ? 1 : 0.15,
            }}
          >
            <span className="absolute left-1/2 top-1 h-8 w-2 rounded-full bg-accent" />
          </span>
        ))}
      </div>
      <span className="mt-6 text-sm tabular-nums text-muted">{progress}%</span>
      <div className="mt-3 h-1 w-36 overflow-hidden rounded-full bg-line">
        <div className="h-full bg-accent" style={{ width: progress + "%" }} />
      </div>
    </div>
  );
}
