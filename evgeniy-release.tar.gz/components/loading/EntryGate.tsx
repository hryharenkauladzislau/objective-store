"use client";
import Link from "next/link";
import { usePresentation } from "@/components/layout/SiteProvider";
import { useEffect, useRef, useState } from "react";
import { BrandMarkPlaceholder } from "@/components/brand/BrandMarkPlaceholder";
export function EntryGate() {
  const p = usePresentation().entry;
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDialogElement>(null);
  useEffect(() => {
    let shown = false;
    try {
      shown = !!sessionStorage.getItem("ea:entry");
    } catch {}
    const t = setTimeout(() => setOpen(p.enabled && !shown), 0);
    return () => clearTimeout(t);
  }, [p.enabled]);
  const close = () => {
    try {
      sessionStorage.setItem("ea:entry", "1");
    } catch {}
    setOpen(false);
  };
  useEffect(() => {
    if (open) ref.current?.showModal();
    else ref.current?.close();
  }, [open]);
  return (
    <dialog ref={ref} onCancel={close} className="entry-dialog">
      <div className="p-6 sm:p-10">
        <div className="flex items-center justify-between">
          <BrandMarkPlaceholder />
          <button
            onClick={close}
            aria-label="Закрыть выбор услуги"
            className="round-action"
          >
            ×
          </button>
        </div>
        <p className="mt-10 text-xs uppercase tracking-[0.2em] text-muted">
          {p.kicker}
        </p>
        <h2 className="mt-3 text-3xl font-semibold tracking-tight sm:text-5xl">
          {p.title}
        </h2>
        <div className="mt-8 grid grid-cols-2 gap-3">
          {p.items.map(({href, title, text: desc}, i) => (
            <Link
              key={href}
              href={href}
              onClick={close}
              className="rounded-card border border-line bg-surface p-4 transition-colors hover:border-accent sm:p-6"
            >
              <span className="text-xs text-muted">{String(i+1).padStart(2,"0")}</span>
              <h3 className="mt-5 text-xl font-semibold">{title}</h3>
              <p className="mt-2 text-xs text-muted sm:text-sm">{desc}</p>
            </Link>
          ))}
        </div>
        <button
          onClick={close}
          className="mt-6 text-sm text-muted underline underline-offset-4"
        >
          {p.closeLabel}
        </button>
      </div>
    </dialog>
  );
}
