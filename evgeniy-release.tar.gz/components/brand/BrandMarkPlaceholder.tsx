"use client";
import Image from "next/image";
import { usePresentation } from "@/components/layout/SiteProvider";
import { cn } from "@/lib/cn";

/*
 * Текстовый знак бренда — заглушка до получения логотипа от заказчика (ТЗ §6).
 * Размер задаётся внешним font-size (например, text-[17px] в шапке), поэтому
 * знак масштабируется от строки шапки до центральной композиции прелоадера.
 * Замена на настоящий SVG-логотип: переписать реализацию этого компонента,
 * места использования не меняются.
 */
export function BrandMarkPlaceholder({ className }: { className?: string }) {
  const p = usePresentation();
  return (
    <span
      aria-hidden="true"
      className={cn(
        "inline-flex items-center gap-2.5 whitespace-nowrap",
        className,
      )}
    >
      {p.brand.logo ? <Image src={p.brand.logo} alt={p.brand.name} width={180} height={70} unoptimized className="max-h-[3em] w-auto max-w-[210px] object-contain" /> : <>
      <svg
        viewBox="0 0 48 56"
        className="h-[2.7em] w-[2.3em] text-accent"
        fill="none"
      >
        <path
          d="M37 11c-9 0-17 7-17 15h17c0 10-7 16-15 16C11 42 5 34 5 26S12 10 23 10"
          stroke="currentColor"
          strokeWidth="7"
          strokeLinecap="round"
        />
        <path d="M26 8C28 1 34 0 39 0c0 6-5 10-13 8Z" fill="currentColor" />
      </svg>
      <span className="flex flex-col">
        <span className="font-extrabold tracking-[0.04em]">{p.brand.name}</span>
        <span className="mt-0.5 text-[0.62em] font-semibold tracking-[0.2em] text-muted">
          {p.brand.secondary}
        </span>
      </span>
      </>}
    </span>
  );
}
