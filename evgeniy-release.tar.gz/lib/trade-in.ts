// Публичные верхние оценки iStock. Это ориентир другого рынка, а не оферта Evgeniy Apple.
// Проверено 02.10.2026: https://istock38.ru/page/trade-in
export interface TradeInRate {
  id: string;
  model: string;
  storageGb: number | null;
  maxPrice: number;
  currency: "USD" | "BYN" | "RUB";
  sourceUrl: string;
  checkedAt: string;
  approved: boolean;
}
export const TRADE_IN_REFERENCE: TradeInRate[] = [
  ["iPhone X", 8000],
  ["iPhone XS", 8000],
  ["iPhone XS Max", 10000],
  ["iPhone XR", 8000],
  ["iPhone 11", 18000],
  ["iPhone 11 Pro", 19000],
  ["iPhone 11 Pro Max", 23000],
  ["iPhone 12", 23000],
  ["iPhone 12 mini", 17000],
  ["iPhone 12 Pro", 27000],
  ["iPhone 12 Pro Max", 37000],
  ["iPhone 13", 34000],
  ["iPhone 13 mini", 25000],
  ["iPhone 13 Pro", 48000],
  ["iPhone 13 Pro Max", 53000],
  ["iPhone 14", 43000],
  ["iPhone 14 Pro", 67000],
  ["iPhone 14 Pro Max", 73000],
  ["iPhone 15", 55000],
  ["iPhone 15 Plus", 60000],
  ["iPhone 15 Pro", 88000],
  ["iPhone 15 Pro Max", 100000],
].map(([model, maxPrice], i) => ({
  id: "reference-" + i,
  model: String(model),
  maxPrice: Number(maxPrice),
  storageGb: null,
  currency: "RUB",
  sourceUrl: "https://istock38.ru/page/trade-in",
  checkedAt: "2026-10-02",
  approved: false,
}));
export function formatTradeIn(
  rate: Pick<TradeInRate, "maxPrice" | "currency">,
) {
  return new Intl.NumberFormat("ru-RU", {
    style: "currency",
    currency: rate.currency,
    maximumFractionDigits: 0,
  }).format(rate.maxPrice);
}
export function matchingRate(
  rates: TradeInRate[],
  model: string,
  memory: string,
) {
  const normalized = model.toLowerCase().replace(/\s+/g, " ").trim();
  const n = memory
    .toLowerCase()
    .replace(",", ".")
    .match(/([0-9.]+)/);
  const gb = n
    ? Number(n[1]) * (/тб|tb/.test(memory.toLowerCase()) ? 1024 : 1)
    : null;
  const candidates = rates.filter(
    (r) => r.model.toLowerCase().replace(/\s+/g, " ").trim() === normalized,
  );
  return (
    candidates.find((r) => r.storageGb === gb) ||
    candidates.find((r) => r.storageGb === null)
  );
}
