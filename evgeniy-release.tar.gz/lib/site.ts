// Начальные контакты из публичных источников магазина; далее меняются в админке.

export const SITE = {
  name: "EVGENIY APPLE",
  founderName: "Евгений",
  city: "Минск",

  /** Телефон владельца; null → показываем шаблон без tel-ссылки */
  phone: "+375 29 555-84-70" as string | null,
  /** Шаблон-плейсхолдер, пока телефон не предоставлен */
  phonePlaceholder: "+375 (__) ___-__-__",

  /** Ссылка Telegram; null → «ссылка ожидается» (ТЗ §24) */
  telegramUrl: "https://t.me/evgeniy_apple" as string | null,
  telegramLabel: "Telegram",

  /** Ссылка Instagram; null → «ссылка ожидается» */
  instagramUrl: "https://www.instagram.com/evgeniy_apple/" as string | null,
  instagramLabel: "Instagram",
  telegramChannel: "https://t.me/evgeniy_apple_minsk",
  address: "Минск, ул. Лобанка, 14",
  hours: "Время визита согласуйте заранее",
  email: "EAppleinfo@gmail.com",
  legalName: "ИП Климов Е.Н.",
  legalId: "791293022",
};

export type NavLink = { href: string; label: string };

/** Навигация шапки — 8 пунктов строго по ТЗ §6 */
export const NAV_LINKS: NavLink[] = [
  { href: "/catalog", label: "Новые устройства" },
  { href: "/used", label: "Б/У устройства" },
  { href: "/trade-in", label: "Trade-in" },
  { href: "/shipping", label: "Доставка и оплата" },
  { href: "/warranty", label: "Гарантия" },
  { href: "/repair", label: "Ремонт и обслуживание" },
  { href: "/about", label: "Обо мне" },
  { href: "/contacts", label: "Контакты" },
];
