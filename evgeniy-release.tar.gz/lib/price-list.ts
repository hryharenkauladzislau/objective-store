import { catalogSchema, type CatalogDocument } from "@/lib/schema";

const clean = (s: string) => s.replace(/[\t\r\n]+/g, " ").trim();
function entries(d: CatalogDocument) {
  const rows = d.products.flatMap((p) => p.variants.map((v) => ({
    kind: "new", id: v.sku,
    details: [p.name, v.storageGb ? `${v.storageGb} GB` : "Стандарт", v.colorName, v.sim].map(clean).join(" | "),
    price: v.manualPriceUsd ?? (v.basePriceUsd == null ? 0 : Math.round(v.basePriceUsd * d.settings.coefficient / d.settings.rounding) * d.settings.rounding),
    variant: v,
  })));
  return [ ...rows, ...d.used.map((u) => ({ kind: "used", id: u.id, details: [u.name, `${u.storageGb} GB`, u.colorName, "Б/У"].map(clean).join(" | "), price: u.priceUsd, unit: u })) ];
}
export function exportPriceList(d: CatalogDocument): string {
  return "\uFEFF# EVGENIY APPLE — цены USD\n# Меняйте только последнее число. 0 = цена по запросу для новых товаров.\n# Revision: " + d.revision + "\n# Тип\tSKU/ID\tМодель | Память | Цвет | Версия\tЦена USD\n" + entries(d).map((r) => [r.kind, r.id, r.details, r.price].join("\t")).join("\n") + "\n";
}
export function previewPriceList(text: string, original: CatalogDocument) {
  const revision = text.match(/^# Revision: (\d+)\r?$/m)?.[1];
  if (revision === undefined || Number(revision) !== original.revision) throw new Error("Каталог изменился. Скачайте свежий TXT перед обновлением цен.");
  const candidate = structuredClone(original);
  const known = new Map(entries(candidate).map((r) => [r.kind + ":" + r.id, r]));
  const seen = new Set<string>();
  const changes: { sku: string; name: string; before: number; after: number }[] = [];
  let rows = 0;
  for (const [index, raw] of text.replace(/^\uFEFF/, "").split(/\r?\n/).entries()) {
    if (!raw.trim() || raw.trimStart().startsWith("#")) continue;
    const cells = raw.split("\t");
    const fail = (message: string): never => { throw new Error(`Строка ${index + 1}: ${message}`); };
    if (cells.length !== 4) fail("сохраните 4 поля, разделённые табуляцией");
    const [kind, id, details, value] = cells;
    const key = kind + ":" + id;
    if (seen.has(key)) fail("вариант повторяется");
    seen.add(key);
    const row = known.get(key);
    if (!row) fail("неизвестный SKU/ID; скачайте свежий TXT");
    if (row!.details !== details) fail("описание варианта изменилось; меняйте только последнее число");
    if (!/^\d{1,7}(?:[.,]\d{1,2})?$/.test(value.trim())) fail("цена должна быть числом от 0 до 1000000");
    const price = Number(value.trim().replace(",", "."));
    if (!Number.isFinite(price) || price > 1000000 || (kind === "used" && price <= 0)) fail("недопустимая цена");
    rows++;
    if (price === row!.price) continue;
    if ("variant" in row!) {
      const v = row!.variant;
      v.manualPriceUsd = price === 0 ? null : price;
      if (price === 0) { v.basePriceUsd = null; v.oldPriceUsd = null; }
      else if (v.oldPriceUsd != null && v.oldPriceUsd <= price) v.oldPriceUsd = null;
    } else {
      const u = row!.unit;
      u.priceUsd = price;
      if (u.oldPriceUsd != null && u.oldPriceUsd <= price) u.oldPriceUsd = null;
    }
    changes.push({ sku: id, name: details, before: row!.price, after: price });
  }
  if (!rows) throw new Error("В файле нет строк с ценами");
  return { candidate: catalogSchema.parse(candidate), changes, rows };
}
