import "server-only";
import { createHmac, createHash, timingSafeEqual } from "node:crypto";
import { cookies } from "next/headers";
export const COOKIE = "ea_admin";
const attempts = new Map<string, { count: number; until: number }>();
const digest = (s: string) => createHash("sha256").update(s).digest();
export function configured() {
  return (
    (process.env.ADMIN_PASSWORD?.length ?? 0) >= 12 &&
    (process.env.ADMIN_SESSION_SECRET?.length ?? 0) >= 32
  );
}
export function passwordMatches(s: string) {
  return (
    configured() &&
    timingSafeEqual(digest(s), digest(process.env.ADMIN_PASSWORD!))
  );
}
const sign = (s: string) =>
  createHmac("sha256", process.env.ADMIN_SESSION_SECRET!)
    .update(s)
    .digest("base64url");
export function token() {
  const data = Buffer.from(
    JSON.stringify({
      expires: Date.now() + 8 * 3600000,
      password: digest(process.env.ADMIN_PASSWORD!).toString("hex"),
    }),
  ).toString("base64url");
  return `${data}.${sign(data)}`;
}
export async function isAdmin() {
  if (!configured()) return false;
  const t = (await cookies()).get(COOKIE)?.value;
  if (!t) return false;
  const [data, sig] = t.split(".");
  if (!data || !sig || !timingSafeEqual(digest(sig), digest(sign(data))))
    return false;
  try {
    const p = JSON.parse(Buffer.from(data, "base64url").toString());
    return (
      p.expires > Date.now() &&
      p.password === digest(process.env.ADMIN_PASSWORD!).toString("hex")
    );
  } catch {
    return false;
  }
}
export function sameOrigin(r: Request) {
  try {
    const a = new URL(r.headers.get("origin") || "");
    const b = new URL(r.url);
    return (
      a.host === b.host ||
      (!!process.env.NEXT_PUBLIC_SITE_URL &&
        a.origin === new URL(process.env.NEXT_PUBLIC_SITE_URL).origin)
    );
  } catch {
    return false;
  }
}
export function throttle(r: Request) {
  const key = (r.headers.get("x-forwarded-for") || "local")
    .split(",")[0]
    .trim();
  const now = Date.now();
  for (const [k, v] of attempts) if (v.until < now) attempts.delete(k);
  const entry = attempts.get(key) || { count: 0, until: now + 15 * 60000 };
  entry.count++;
  attempts.set(key, entry);
  return entry.count > 5;
}
export async function guard(r: Request) {
  if (!sameOrigin(r))
    return Response.json(
      { error: "Недопустимый источник запроса" },
      { status: 403 },
    );
  if (!(await isAdmin()))
    return Response.json({ error: "Войдите в админку" }, { status: 401 });
  return null;
}
