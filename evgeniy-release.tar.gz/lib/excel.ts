import ExcelJS from "exceljs";
import type { CatalogDocument } from "./schema";
import { catalogSchema } from "./schema";
const cols = [
  "sku",
  "slug",
  "name",
  "category",
  "storageGb",
  "colorName",
  "colorHex",
  "sim",
  "basePriceUsd",
  "manualPriceUsd",
  "oldPriceUsd",
  "subcategory",
  "status",
];
export async function excelTemplate(catalog?: CatalogDocument) {
  const w = new ExcelJS.Workbook();
  const s = w.addWorksheet("Каталог");
  s.addRow(cols);
  catalog?.products.forEach((p) =>
    p.variants.forEach((v) =>
      s.addRow([
        v.sku,
        p.slug,
        p.name,
        p.category,
        v.storageGb,
        v.colorName,
        v.colorHex,
        v.sim,
        v.basePriceUsd,
        v.manualPriceUsd,
        v.oldPriceUsd ?? null,
        p.subcategory ?? null,
        v.status,
      ]),
    ),
  );
  s.getRow(1).font = { bold: true };
  s.columns.forEach((c) => (c.width = 22));
  return Buffer.from(await w.xlsx.writeBuffer());
}
export async function previewExcel(bytes: Buffer, original: CatalogDocument) {
  if (bytes.length > 2 * 1024 * 1024) throw new Error("Файл больше 2 МБ");
  let total = 0,
    entries = 0;
  for (let i = 0; i + 46 < bytes.length; i++) {
    if (bytes.readUInt32LE(i) !== 0x02014b50) continue;
    total += bytes.readUInt32LE(i + 24);
    entries++;
    if (total > 20 * 1024 * 1024 || entries > 100)
      throw new Error("Слишком большой распакованный файл");
  }
  if (!entries) throw new Error("Нужен файл .xlsx");
  const w = new ExcelJS.Workbook();
  await w.xlsx.load(bytes as never);
  const sheet = w.worksheets[0];
  if (!sheet || sheet.rowCount > 5001)
    throw new Error("Допустимо до 5000 строк");
  const header = new Map<string, number>();
  sheet.getRow(1).eachCell((c, n) => header.set(c.text.trim(), n));
  if (!header.has("sku")) throw new Error("Нет столбца sku");
  const candidate = structuredClone(original);
  const report: {
    row: number;
    sku: string;
    result: "new" | "changed" | "unchanged" | "error";
    message: string;
  }[] = [];
  const seen = new Set<string>();
  for (let n = 2; n <= sheet.rowCount; n++) {
    const row = sheet.getRow(n);
    if (!row.hasValues) continue;
    const get = (key: string) => {
      const idx = header.get(key);
      if (!idx) return "";
      const c = row.getCell(idx);
      if (c.type === ExcelJS.ValueType.Formula)
        throw new Error("Формулы не поддерживаются: " + key);
      return c.text.trim();
    };
    let sku = "";
    try {
      sku = get("sku");
      if (!sku) throw new Error("Нет SKU");
      if (seen.has(sku)) throw new Error("SKU повторяется в файле");
      seen.add(sku);
      const p = candidate.products.find((p) =>
        p.variants.some((v) => v.sku === sku),
      );
      const v = p?.variants.find((v) => v.sku === sku);
      const num = (key: string) =>
        get(key) === "" ? null : Number(get(key).replace(",", "."));
      if (v) {
        const before = JSON.stringify([p?.slug, p?.name, p?.category, v]);
        for (const key of ["colorName", "colorHex", "sim"] as const)
          if (header.has(key) && get(key)) v[key] = get(key);
        if (header.has("storageGb")) v.storageGb = num("storageGb");
        if (p) {
          for (const key of ["slug", "name"] as const)
            if (header.has(key) && get(key)) p[key] = get(key);
          if (header.has("category") && get("category"))
            p.category = get("category") as typeof p.category;
          if (header.has("subcategory"))
            p.subcategory = get("subcategory") || null;
        }
        for (const key of [
          "basePriceUsd",
          "manualPriceUsd",
          "oldPriceUsd",
        ] as const)
          if (header.has(key)) v[key] = num(key);
        if (header.has("status") && get("status"))
          v.status = get("status") as typeof v.status;
        report.push({
          row: n,
          sku,
          result:
            before === JSON.stringify([p?.slug, p?.name, p?.category, v])
              ? "unchanged"
              : "changed",
          message: "",
        });
      } else {
        for (const key of ["slug", "name", "category", "colorName", "sim"])
          if (!get(key))
            throw new Error("Нужно поле " + key + " для нового SKU");
        let product = candidate.products.find((p) => p.slug === get("slug"));
        if (!product) {
          product = {
            slug: get("slug"),
            name: get("name"),
            category: get(
              "category",
            ) as CatalogDocument["products"][number]["category"],
            series: get("name"),
            tagline: "",
            addedAt: new Date().toISOString().slice(0, 10),
            featuredOnHome: false,
            subcategory: get("subcategory") || null,
            hidden: false,
            specs: [],
            variants: [],
          };
          candidate.products.push(product);
        }
        product.variants.push({
          sku,
          storageGb: num("storageGb"),
          colorName: get("colorName"),
          colorHex: get("colorHex") || "#eeeeee",
          sim: get("sim"),
          basePriceUsd: num("basePriceUsd"),
          manualPriceUsd: num("manualPriceUsd"),
          oldPriceUsd: num("oldPriceUsd"),
          status: (get("status") || "request") as "request",
          images: [],
        });
        report.push({
          row: n,
          sku,
          result: "new",
          message: "Фото добавьте в редакторе товара",
        });
      }
    } catch (e) {
      report.push({
        row: n,
        sku,
        result: "error",
        message: (e as Error).message,
      });
    }
  }
  const parsed = catalogSchema.safeParse(candidate);
  if (!parsed.success)
    for (const issue of parsed.error.issues.slice(0, 20))
      report.push({
        row: 0,
        sku: "",
        result: "error",
        message: issue.path.join(".") + ": " + issue.message,
      });
  const counts = { new: 0, changed: 0, unchanged: 0, error: 0 };
  report.forEach((r) => counts[r.result]++);
  return { candidate: counts.error ? null : candidate, report, counts };
}
