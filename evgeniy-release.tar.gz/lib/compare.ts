"use client";
import { useMemo, useSyncExternalStore } from "react";
export function readCompareList(): string[] {
  try {
    const value: unknown = JSON.parse(
      localStorage.getItem("ea:compare") || "[]",
    );
    return Array.isArray(value)
      ? [
          ...new Set(
            value.filter(
              (v): v is string =>
                typeof v === "string" && /^[a-z0-9-]{1,100}$/.test(v),
            ),
          ),
        ].slice(0, 3)
      : [];
  } catch {
    return [];
  }
}
export function writeCompareList(ids: string[]) {
  localStorage.setItem("ea:compare", JSON.stringify(ids.slice(0, 3)));
  window.dispatchEvent(new Event("ea:compare"));
}
const subscribe = (callback: () => void) => {
  window.addEventListener("ea:compare", callback);
  window.addEventListener("storage", callback);
  return () => {
    window.removeEventListener("ea:compare", callback);
    window.removeEventListener("storage", callback);
  };
};
const snapshot = () => JSON.stringify(readCompareList());
const serverSnapshot = () => "[]";
export function useCompareList() {
  const serialized = useSyncExternalStore(subscribe, snapshot, serverSnapshot);
  return useMemo(() => JSON.parse(serialized) as string[], [serialized]);
}
