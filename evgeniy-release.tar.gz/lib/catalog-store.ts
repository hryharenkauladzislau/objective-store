import "server-only";
import { promises as fs } from "node:fs";
import path from "node:path";
import { randomUUID } from "node:crypto";
import { Pool } from "pg";
import { categories, products } from "@/lib/mock/catalog";
import { catalogSchema, type CatalogDocument } from "@/lib/schema";
import { SITE } from "@/lib/site";
import { DEFAULT_PRESENTATION } from "@/lib/presentation";
import { TRADE_IN_REFERENCE } from "@/lib/trade-in";

const pool = process.env.DATABASE_URL
  ? new Pool({ connectionString: process.env.DATABASE_URL, max: 4 })
  : null;
const directory = process.env.STORAGE_DIR || path.join(process.cwd(), ".data");
let init: Promise<void> | undefined;
let queue: Promise<unknown> = Promise.resolve();
function seed(): CatalogDocument {
  return {
    revision: 0,
    presentation: structuredClone(DEFAULT_PRESENTATION),
    categories: structuredClone(categories),
    products: structuredClone(products).map((p) => ({
      ...p,
      variants: p.variants.map((v) => ({
        ...v,
        basePriceUsd: null,
        manualPriceUsd: null,
        status: "request" as const,
      })),
    })),
    used: [],
    tradeIn: structuredClone(TRADE_IN_REFERENCE),
    settings: {
      coefficient: 1,
      rounding: 10,
      phone: SITE.phone!,
      telegramUrl: SITE.telegramUrl!,
      telegramChannel: SITE.telegramChannel,
      instagramUrl: SITE.instagramUrl!,
      address: SITE.address,
      hours: SITE.hours,
      email: SITE.email,
      legalName: SITE.legalName,
      legalId: SITE.legalId,
    },
  };
}
async function ready() {
  if (!pool) return;
  init ??= (async () => {
    await pool.query(
      "CREATE TABLE IF NOT EXISTS ea_catalog(id integer PRIMARY KEY CHECK(id=1),document jsonb NOT NULL)",
    );
    await pool.query(
      "CREATE TABLE IF NOT EXISTS ea_media(id uuid PRIMARY KEY,bytes bytea NOT NULL)",
    );
    await pool.query(
      "INSERT INTO ea_catalog VALUES(1,$1::jsonb) ON CONFLICT DO NOTHING",
      [JSON.stringify(seed())],
    );
  })().catch((e) => {
    init = undefined;
    throw e;
  });
  await init;
}
export async function readCatalog(): Promise<CatalogDocument> {
  await ready();
  if (pool) {
    const r = await pool.query("SELECT document FROM ea_catalog WHERE id=1");
    const d = catalogSchema.parse(r.rows[0].document);
    return { ...d, tradeIn: d.tradeIn ?? structuredClone(TRADE_IN_REFERENCE) };
  }
  try {
    const d = catalogSchema.parse(
      JSON.parse(
        await fs.readFile(path.join(directory, "catalog.json"), "utf8"),
      ),
    );
    return { ...d, tradeIn: d.tradeIn ?? structuredClone(TRADE_IN_REFERENCE) };
  } catch (e) {
    if ((e as NodeJS.ErrnoException).code !== "ENOENT") throw e;
    return seed();
  }
}
export function publicCatalog(d: CatalogDocument): CatalogDocument {
  return {
    ...d,
    settings: { ...d.settings, coefficient: 1, rounding: 1 },
    categories: d.categories.filter((c) => !c.hidden),
    products: d.products
      .filter(
        (p) =>
          !p.hidden &&
          d.categories.some((c) => c.slug === p.category && !c.hidden),
      )
      .map((p) => ({
        ...p,
        variants: p.variants.map((v) => ({
          ...v,
          basePriceUsd: null,
          manualPriceUsd:
            v.manualPriceUsd ??
            (v.basePriceUsd === null
              ? null
              : Math.round(
                  (v.basePriceUsd * d.settings.coefficient) /
                    d.settings.rounding,
                ) * d.settings.rounding),
        })),
      })),
    used: d.used.filter((u) => !u.sold),
  };
}
export class RevisionConflict extends Error {}
function canWrite() {
  if (
    !pool &&
    process.env.NODE_ENV === "production" &&
    !process.env.STORAGE_DIR
  )
    throw new Error("Настройте DATABASE_URL или постоянный STORAGE_DIR");
}
export async function writeCatalog(input: unknown): Promise<CatalogDocument> {
  canWrite();
  const d = catalogSchema.parse(input);
  await ready();
  const next = { ...d, revision: d.revision + 1 };
  if (pool) {
    const r = await pool.query(
      "UPDATE ea_catalog SET document=$1::jsonb WHERE id=1 AND (document->>'revision')::bigint=$2 RETURNING document",
      [JSON.stringify(next), d.revision],
    );
    if (!r.rowCount)
      throw new RevisionConflict(
        "Данные изменены в другой вкладке. Обновите страницу.",
      );
    return next;
  }
  const operation = queue.then(async () => {
    const old = await readCatalog();
    if (old.revision !== d.revision)
      throw new RevisionConflict(
        "Данные изменены в другой вкладке. Обновите страницу.",
      );
    await fs.mkdir(directory, { recursive: true });
    const temp = path.join(directory, `${randomUUID()}.tmp`);
    await fs.writeFile(temp, JSON.stringify(next));
    await fs.rename(temp, path.join(directory, "catalog.json"));
    return next;
  });
  queue = operation.catch(() => {});
  return operation;
}
export async function putPhoto(bytes: Buffer) {
  canWrite();
  await ready();
  const id = randomUUID();
  if (pool) await pool.query("INSERT INTO ea_media VALUES($1,$2)", [id, bytes]);
  else {
    await fs.mkdir(path.join(directory, "media"), { recursive: true });
    await fs.writeFile(path.join(directory, "media", `${id}.webp`), bytes);
  }
  return `/api/media/${id}`;
}
export async function getPhoto(id: string) {
  if (
    !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(id)
  )
    return null;
  await ready();
  if (pool) {
    const r = await pool.query("SELECT bytes FROM ea_media WHERE id=$1", [id]);
    return r.rows[0]?.bytes as Buffer | undefined;
  }
  try {
    return await fs.readFile(path.join(directory, "media", `${id}.webp`));
  } catch (e) {
    if ((e as NodeJS.ErrnoException).code === "ENOENT") return null;
    throw e;
  }
}
