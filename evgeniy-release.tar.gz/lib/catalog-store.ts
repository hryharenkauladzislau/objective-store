import "server-only";
import { promises as fs } from "node:fs";
import path from "node:path";
import { randomUUID } from "node:crypto";
import { Pool } from "pg";
import { products } from "@/lib/mock/catalog";
import { catalogSchema, type CatalogDocument } from "@/lib/schema";
import { SITE } from "@/lib/site";
import { DEFAULT_PRESENTATION } from "@/lib/presentation";
import { DEFAULT_TRADE_IN_SETTINGS, TRADE_IN_REFERENCE } from "@/lib/trade-in";

const BRAND_CATEGORIES: CatalogDocument["categories"] = [
  {
    slug: "apple",
    name: "Apple",
    caption: "iPhone, Mac, iPad, Watch, AirPods и аксессуары",
    image: "/images/products/iphone-17-pro-1.webp",
    direct: false,
    subcategories: [
      { slug: "iphone", name: "iPhone", image: "/images/products/iphone-17-pro-1.webp" },
      { slug: "mac", name: "MacBook", image: "/images/products/macbook-air-13-m4-1.webp" },
      { slug: "ipad", name: "iPad", image: "/images/products/ipad-pro-m5-1.webp" },
      { slug: "watch", name: "Apple Watch", image: "/images/products/apple-watch-ultra-3-1.webp" },
      { slug: "airpods", name: "AirPods", image: "/images/products/airpods-pro-3-1.webp" },
      { slug: "accessories", name: "Аксессуары", image: "/images/products/magsafe-cases-1.webp" },
    ],
  },
  { slug: "dyson", name: "Dyson", caption: "Техника Dyson — по запросу", image: null, direct: true, hidden: true },
  { slug: "playstation", name: "PlayStation", caption: "Консоли и аксессуары — по запросу", image: null, direct: true, hidden: true },
];

// Публичный прайс канала от 26.09.2026. Итоговая цена всё равно подтверждается
// в день покупки; значения служат стартовыми «от» для имеющихся моделей.
const LATEST_PRICES: Record<string, Record<number, [number, number?]>> = {
  "iphone-17-pro-max": { 256:[1280,1350], 512:[1440,1570], 1024:[1650,1950], 2048:[1780] },
  "iphone-17-pro": { 256:[1190,1240], 512:[1350,1450], 1024:[1450,1650] },
  "iphone-17": { 256:[970,980], 512:[1130,1150] },
  "iphone-air": { 256:[920], 512:[1020] },
  "iphone-16-pro-max": { 256:[1220], 512:[1400], 1024:[1450] },
  "iphone-16-pro": { 128:[1100], 1024:[1480] },
  "iphone-16": { 128:[800], 256:[900] },
  "iphone-15": { 128:[690], 256:[820], 512:[900] },
  "iphone-14": { 128:[650], 512:[700] },
};
function seededPrice(slug: string, storage: number | null, sim: string): number | null {
  if (!storage) return null;
  const pair = LATEST_PRICES[slug]?.[storage];
  if (!pair) return null;
  const physical = /nano|sim\s*\+|dual sim/i.test(sim);
  return physical && pair[1] ? pair[1] : pair[0];
}

const pool = process.env.DATABASE_URL
  ? new Pool({ connectionString: process.env.DATABASE_URL, max: 4 })
  : null;
const directory = process.env.STORAGE_DIR || path.join(process.cwd(), ".data");
let init: Promise<void> | undefined;
let queue: Promise<unknown> = Promise.resolve();
function seed(): CatalogDocument {
  return {
    revision: 0,
    presentation: structuredClone(DEFAULT_PRESENTATION),
    categories: structuredClone(BRAND_CATEGORIES),
    products: structuredClone(products).map((p) => ({
      ...p,
      subcategory: p.category,
      category: "apple",
      variants: p.variants.map((v) => ({
        ...v,
        basePriceUsd: null,
        manualPriceUsd: seededPrice(p.slug, v.storageGb, v.sim),
        status: seededPrice(p.slug, v.storageGb, v.sim) ? "on-order" as const : "request" as const,
      })),
    })),
    used: [],
    tradeIn: structuredClone(TRADE_IN_REFERENCE),
    tradeInSettings: structuredClone(DEFAULT_TRADE_IN_SETTINGS),
    settings: {
      coefficient: 1,
      rounding: 10,
      phone: SITE.phone!,
      telegramUrl: SITE.telegramUrl!,
      telegramChannel: SITE.telegramChannel,
      instagramUrl: SITE.instagramUrl!,
      address: SITE.address,
      hours: SITE.hours,
      email: SITE.email,
      legalName: SITE.legalName,
      legalId: SITE.legalId,
    },
  };
}
async function ready() {
  if (!pool) return;
  init ??= (async () => {
    await pool.query(
      "CREATE TABLE IF NOT EXISTS ea_catalog(id integer PRIMARY KEY CHECK(id=1),document jsonb NOT NULL)",
    );
    await pool.query(
      "CREATE TABLE IF NOT EXISTS ea_media(id uuid PRIMARY KEY,bytes bytea NOT NULL)",
    );
    await pool.query(
      "INSERT INTO ea_catalog VALUES(1,$1::jsonb) ON CONFLICT DO NOTHING",
      [JSON.stringify(seed())],
    );
  })().catch((e) => {
    init = undefined;
    throw e;
  });
  await init;
}
export async function readCatalog(): Promise<CatalogDocument> {
  await ready();
  if (pool) {
    const r = await pool.query("SELECT document FROM ea_catalog WHERE id=1");
    const d = catalogSchema.parse(r.rows[0].document);
    return migrateCatalog(d);
  }
  try {
    const d = catalogSchema.parse(
      JSON.parse(
        await fs.readFile(path.join(directory, "catalog.json"), "utf8"),
      ),
    );
    return migrateCatalog(d);
  } catch (e) {
    if ((e as NodeJS.ErrnoException).code !== "ENOENT") throw e;
    return seed();
  }
}

function migrateCatalog(d: CatalogDocument): CatalogDocument {
  const legacy = !d.categories.some((c) => c.slug === "apple") &&
    d.categories.some((c) => ["iphone", "mac", "ipad", "watch", "airpods", "accessories"].includes(c.slug));
  return {
    ...d,
    categories: legacy ? structuredClone(BRAND_CATEGORIES) : d.categories,
    products: legacy ? d.products.map((p) => ({ ...p, subcategory: p.category, category: "apple" })) : d.products,
    tradeIn: d.tradeIn ?? structuredClone(TRADE_IN_REFERENCE),
    tradeInSettings: d.tradeInSettings ?? structuredClone(DEFAULT_TRADE_IN_SETTINGS),
  };
}
export function publicCatalog(d: CatalogDocument): CatalogDocument {
  return {
    ...d,
    settings: { ...d.settings, coefficient: 1, rounding: 1 },
    categories: d.categories.filter((c) => !c.hidden),
    products: d.products
      .filter(
        (p) =>
          !p.hidden &&
          d.categories.some((c) => c.slug === p.category && !c.hidden),
      )
      .map((p) => ({
        ...p,
        variants: p.variants.map((v) => ({
          ...v,
          basePriceUsd: null,
          manualPriceUsd:
            v.manualPriceUsd ??
            (v.basePriceUsd === null
              ? null
              : Math.round(
                  (v.basePriceUsd * d.settings.coefficient) /
                    d.settings.rounding,
                ) * d.settings.rounding),
        })),
      })),
    used: d.used.filter((u) => !u.sold),
  };
}
export class RevisionConflict extends Error {}
function canWrite() {
  if (
    !pool &&
    process.env.NODE_ENV === "production" &&
    !process.env.STORAGE_DIR
  )
    throw new Error("Настройте DATABASE_URL или постоянный STORAGE_DIR");
}
export async function writeCatalog(input: unknown): Promise<CatalogDocument> {
  canWrite();
  const d = catalogSchema.parse(input);
  await ready();
  const next = { ...d, revision: d.revision + 1 };
  if (pool) {
    const r = await pool.query(
      "UPDATE ea_catalog SET document=$1::jsonb WHERE id=1 AND (document->>'revision')::bigint=$2 RETURNING document",
      [JSON.stringify(next), d.revision],
    );
    if (!r.rowCount)
      throw new RevisionConflict(
        "Данные изменены в другой вкладке. Обновите страницу.",
      );
    return next;
  }
  const operation = queue.then(async () => {
    const old = await readCatalog();
    if (old.revision !== d.revision)
      throw new RevisionConflict(
        "Данные изменены в другой вкладке. Обновите страницу.",
      );
    await fs.mkdir(directory, { recursive: true });
    const temp = path.join(directory, `${randomUUID()}.tmp`);
    await fs.writeFile(temp, JSON.stringify(next));
    await fs.rename(temp, path.join(directory, "catalog.json"));
    return next;
  });
  queue = operation.catch(() => {});
  return operation;
}
export async function putPhoto(bytes: Buffer) {
  canWrite();
  await ready();
  const id = randomUUID();
  if (pool) await pool.query("INSERT INTO ea_media VALUES($1,$2)", [id, bytes]);
  else {
    await fs.mkdir(path.join(directory, "media"), { recursive: true });
    await fs.writeFile(path.join(directory, "media", `${id}.webp`), bytes);
  }
  return `/api/media/${id}`;
}
export async function getPhoto(id: string) {
  if (
    !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(id)
  )
    return null;
  await ready();
  if (pool) {
    const r = await pool.query("SELECT bytes FROM ea_media WHERE id=$1", [id]);
    return r.rows[0]?.bytes as Buffer | undefined;
  }
  try {
    return await fs.readFile(path.join(directory, "media", `${id}.webp`));
  } catch (e) {
    if ((e as NodeJS.ErrnoException).code === "ENOENT") return null;
    throw e;
  }
}
