import { z } from "zod";
import { NAV_LINKS } from "@/lib/site";
const copy = z.string().max(8000);
const href = z.string().max(500).refine(s => /^\/(?!\/)[a-zA-Z0-9/?=&_.#%+\-]*$/.test(s), "Ссылка должна вести на страницу сайта");
const image = z.string().max(2000).refine(s => /^\/images\/[a-zA-Z0-9/_\.\-]+$/.test(s) || /^\/api\/media\/[0-9a-f-]{36}$/.test(s), "Загрузите фотографию в админке");
const external = z.string().url().refine(s => /^https:\/\/(www\.)?(yandex\.(by|ru)|instagram\.com)\//.test(s), "Разрешены ссылки Яндекс Карт и Instagram");
const link = z.object({ label: z.string().min(1).max(120), href, hidden: z.boolean().optional() });
const item = z.object({ title: z.string().max(500), text: copy, href: href.optional() });
export const homeBlockSchema = z.object({ id: z.string().regex(/^[a-z0-9-]{1,80}$/), title: copy, kicker: z.string().max(500), body: copy, ctaLabel: z.string().max(120), ctaHref: href, enabled: z.boolean(), items: z.array(item).max(30) });
export const presentationSchema = z.object({
 brand: z.object({ name: z.string().min(1).max(80), secondary: z.string().max(80), city: z.string().max(80), logo: image.nullable(), founderName: z.string().min(1).max(80), founderPhoto: image, headerNote: z.string().max(200) }),
 theme: z.object({ accent: z.string().regex(/^#[a-fA-F0-9]{6}$/), canvas: z.string().regex(/^#[a-fA-F0-9]{6}$/), ink: z.string().regex(/^#[a-fA-F0-9]{6}$/), signal: z.string().regex(/^#[a-fA-F0-9]{6}$/) }),
 navigation: z.array(link).max(20),
 home: z.array(homeBlockSchema).max(30),
 entry: z.object({ enabled: z.boolean(), title: copy, kicker: copy, closeLabel: z.string().max(120), items: z.array(item.extend({ href })).min(1).max(8) }),
 carousel: z.object({ autoplay: z.boolean(), speed: z.number().min(10).max(100), limit: z.number().int().min(4).max(30), hint: z.string().max(200), zoomOnHover: z.boolean() }),
 loader: z.object({ enabled: z.boolean() }),
 dock: z.object({ enabled: z.boolean(), label: z.string().min(1).max(100) }),
 footer: z.object({ note: copy, privacyLabel: z.string().max(120), termsLabel: z.string().max(120), columns: z.array(z.object({ title: z.string().max(120), links: z.array(link).max(30) })).max(6) }),
 socialProof: z.object({
   title: z.string().max(300),
   intro: copy,
   yandexUrl: external,
   instagramUrl: external,
   reviews: z.array(z.object({ author:z.string().min(1).max(120), text:z.string().min(1).max(1500), source:z.enum(["yandex","instagram"]), date:z.string().max(40), url:external, rating:z.number().int().min(1).max(5).optional() })).max(30),
 }).default({title:"Отзывы и покупки клиентов",intro:"Смотрите живые отметки, распаковки и обратную связь в социальных сетях.",yandexUrl:"https://yandex.by/maps/org/biznes_tsentr_ayaks/221760653625/",instagramUrl:"https://www.instagram.com/evgeniy_apple/",reviews:[]}),
 location: z.object({ enabled:z.boolean(), title:z.string().max(300), address:z.string().max(500), description:copy, mapEmbedUrl:external, directionsUrl:external }).default({enabled:true,title:"Как нас найти",address:"Минск, ул. Могилёвская, 1 · БЦ «Аякс»",description:"Самовывоз по предварительной записи. БЦ находится рядом со станцией метро «Институт культуры».",mapEmbedUrl:"https://yandex.by/map-widget/v1/?oid=221760653625",directionsUrl:"https://yandex.by/maps/org/biznes_tsentr_ayaks/221760653625/"}),
 seo: z.object({ title: z.string().min(1).max(160), description: z.string().max(500) }),
}).superRefine((d,c) => { if(new Set(d.home.map(b=>b.id)).size !== d.home.length) c.addIssue({code:"custom",path:["home"],message:"ID блоков не должны повторяться"}); });
export type Presentation = z.infer<typeof presentationSchema>;
export type HomeBlock = z.infer<typeof homeBlockSchema>;
const b = (id:string,title:string,body="",ctaLabel="Каталог",ctaHref="/catalog",items:HomeBlock["items"]=[],kicker=""):HomeBlock => ({id,title,body,ctaLabel,ctaHref,items,kicker,enabled:true});
export const DEFAULT_PRESENTATION: Presentation = {
 brand:{name:"EVGENIY",secondary:"APPLE · MINSK",city:"Минск",logo:"/images/evgeniy-apple-logo.png",founderName:"Евгений",founderPhoto:"/images/evgeniy-founder.webp",headerNote:"Оригинальная техника · Минск"},
 theme:{accent:"#c4a367",canvas:"#111210",ink:"#f4f0e8",signal:"#c4a367"},
 navigation:NAV_LINKS.map(n=>({...n})),
 home:[
 b("carousel","Ваш следующий iPhone.","Выберите модель. Цвет, память и актуальную цену уточним перед покупкой.","Каталог","/catalog",[],"EVGENIY APPLE / МИНСК"),
 b("quick-links","","","Каталог","/catalog",[{title:"Каталог",text:"",href:"/catalog"},{title:"Б/У устройства",text:"",href:"/used"},{title:"Trade-in",text:"",href:"/trade-in"},{title:"Задать вопрос",text:"",href:"/contacts"}]),
 b("benefits","","","","/catalog",[{title:"Чехол, стекло и перенос данных",text:"Подарки к покупке — уточните комплект для вашей модели.",href:"/faq"},{title:"Доставка по Минску и Беларуси",text:"По Минску — бесплатно, по регионам — от 15 BYN. Подтвердим условия при заказе.",href:"/shipping"},{title:"Самовывоз по записи",text:"Пн–пт 11:00–19:00 · Сб 11:00–16:00 · Вс выходной.",href:"/contacts"}]),
 b("sale","Специальные предложения","","Все SALE","/catalog?sale=1"),
 b("categories","Техника для ваших задач.","","Каталог"),
 b("used","Другой владелец. Тот же Apple.","Фотографии конкретного устройства, состояние аккумулятора и комплект. Всё, что важно знать до встречи.","Б/У устройства","/used",[{title:"Реальные фотографии",text:""},{title:"Состояние и следы использования",text:""},{title:"Аккумулятор и заменённые детали",text:""},{title:"Комплект и условия гарантии",text:""}],"Б/У УСТРОЙСТВА"),
 b("trade-in","Старый iPhone — часть оплаты нового.","Обменяйте вашу технику на скидку при покупке нового устройства. Окончательная оценка — после осмотра.","Оценить устройство","/trade-in",[],"TRADE-IN"),
 b("other-products","Не только iPhone.","","Все устройства"),
 b("steps","Как проходит покупка","","","/contacts",[{title:"Выбираете",text:"Модель, память и цвет. Если сомневаетесь — поможем сравнить."},{title:"Подтверждаем",text:"В Telegram уточняем цену, наличие и удобный способ получения."},{title:"Получаете",text:"Самовывоз по записи или доставка по Беларуси. Условия оплаты и гарантии — до заказа."}]),
 b("about","За именем — человек.","Меня зовут Евгений. В моём магазине можно подобрать новую и б/у технику Apple, обсудить обмен и договориться о доставке.","Обо мне","/about",[],"О МАГАЗИНЕ"),
 b("reviews","Отзывы и покупки клиентов","Живые отметки, распаковки и обратная связь — в Instagram. Отдельную карточку магазина на Яндекс Картах можно подключить в админке, когда она будет подтверждена.","Instagram","/about",[],"СОЦИАЛЬНОЕ ДОКАЗАТЕЛЬСТВО"),
 b("location","Как нас найти","Самовывоз по предварительной записи в БЦ «Аякс», рядом с метро «Институт культуры».","Построить маршрут","/about",[],"МИНСК · МОГИЛЁВСКАЯ, 1"),
 b("services","","","","/contacts",[{title:"Ремонт и обслуживание",text:"Опишите проблему — обсудим диагностику и дальнейшие действия.",href:"/repair"},{title:"Гарантия",text:"В канале для новой техники заявлена гарантия Apple на один год. Условия конкретного устройства уточните до покупки.",href:"/warranty"}]),
 b("faq","Коротко о главном","","Все вопросы","/faq",[{title:"Как узнать точную цену?",text:"Выберите конфигурацию и отправьте заявку. Цены и курс подтверждаются в день покупки."},{title:"Можно ли обменять мой телефон?",text:"Да, через Trade-in. Окончательная оценка зависит от осмотра устройства."},{title:"Есть доставка за пределы Минска?",text:"Да, по Беларуси. В канале указана доставка от 15 BYN; условия подтвердит менеджер."}]),
 b("contacts","Самовывоз по предварительной записи.","","Связаться","/contacts",[],"КОНТАКТЫ")],
 entry:{enabled:true,title:"Выберите, что вам нужно.",kicker:"С чего начнём?",closeLabel:"Перейти на сайт",items:[{title:"Каталог",text:"Новая техника",href:"/catalog"},{title:"Б/У",text:"Конкретные экземпляры",href:"/used"},{title:"Trade-in",text:"Обмен устройства",href:"/trade-in"},{title:"Задать вопрос",text:"Связаться с магазином",href:"/contacts"}]},
 carousel:{autoplay:true,speed:40,limit:12,hint:"",zoomOnHover:true},loader:{enabled:true},dock:{enabled:true,label:"Задать вопрос"},
 footer:{note:"Подбор техники и вопросы — лично с Евгением.",privacyLabel:"Политика конфиденциальности",termsLabel:"Условия заказа",columns:[{title:"Покупателям",links:NAV_LINKS.filter(n=>!["/catalog","/about","/contacts"].includes(n.href)).map(n=>({...n})).concat([{label:"Сравнение",href:"/compare"},{label:"Частые вопросы",href:"/faq"}])},{title:"Компания",links:[{label:"Обо мне",href:"/about"},{label:"Контакты",href:"/contacts"}]}]},
 socialProof:{title:"Отзывы и покупки клиентов",intro:"Смотрите живые отметки, распаковки и обратную связь в социальных сетях.",yandexUrl:"https://yandex.by/maps/org/biznes_tsentr_ayaks/221760653625/",instagramUrl:"https://www.instagram.com/evgeniy_apple/",reviews:[]},
 location:{enabled:true,title:"Как нас найти",address:"Минск, ул. Могилёвская, 1 · БЦ «Аякс»",description:"Самовывоз по предварительной записи. БЦ находится рядом со станцией метро «Институт культуры».",mapEmbedUrl:"https://yandex.by/map-widget/v1/?oid=221760653625",directionsUrl:"https://yandex.by/maps/org/biznes_tsentr_ayaks/221760653625/"},
 seo:{title:"EVGENIY APPLE — техника Apple в Минске",description:"Новые и б/у устройства Apple, Trade-in, доставка по Минску и Беларуси. Подбор техники лично с Евгением."},
};
export function getPresentation(p?: Presentation):Presentation { return p || DEFAULT_PRESENTATION; }
