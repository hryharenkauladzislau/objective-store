// Типы и чистые правила каталога. Серверное хранилище — catalog-store.ts.

export type ProductStatus = "in-stock" | "on-order" | "out" | "request";

export type CategorySlug = string;

export interface Category {
  slug: CategorySlug;
  name: string;
  /** Описание для редакционной сетки на главной */
  caption: string;
  hidden?: boolean;
  direct?: boolean;
  subcategories?: { slug: string; name: string }[];
}

export interface Variant {
  /** Уникальный SKU варианта — по нему в будущем работает Excel-импорт (ТЗ §19) */
  sku: string;
  storageGb: number | null;
  /** HEX цвета варианта */
  colorHex: string;
  colorName: string;
  /** SIM / региональная версия */
  sim: string;
  /** Базовая цена USD до коэффициента (ТЗ §13) */
  basePriceUsd: number | null;
  /** Ручной override отображаемой цены; иначе считается от базовой */
  manualPriceUsd: number | null;
  /** Старая розничная цена для SALE, без коэффициента. */
  oldPriceUsd?: number | null;
  status: ProductStatus;
  images: string[];
}

export interface ProductSpec {
  label: string;
  value: string;
}

export interface Product {
  hidden?: boolean;
  slug: string;
  category: CategorySlug;
  subcategory?: string | null;
  name: string;
  series: string;
  tagline: string;
  /** Дата появления в каталоге — для сортировки «новизна» (ТЗ §11) */
  addedAt: string;
  /** Флаг «Показывать на главной» для карусели (ТЗ §9) */
  featuredOnHome: boolean;
  specs: ProductSpec[];
  variants: Variant[];
}

export interface UsedUnit {
  sold?: boolean;
  /** ID физического экземпляра (ТЗ §14) */
  id: string;
  slug: string;
  name: string;
  storageGb: number;
  colorName: string;
  condition: "excellent" | "good" | "fair";
  conditionNote: string;
  batteryHealth: number;
  batteryReplaced: boolean;
  kit: string[];
  checks: string[];
  defects: string | null;
  /** Гарантия магазина */
  warrantyMonths: number;
  priceUsd: number;
  oldPriceUsd?: number | null;
  images: string[];
}

/* ---------- Формирование цен (ТЗ §13) ---------- */

/** Формат USD; коэффициент и округление применяет publicCatalog(). */
export function formatPrice(usd: number): string {
  return `$${usd.toLocaleString("ru-RU")}`;
}

export function variantPrice(variant: Variant): number | null {
  return variant.manualPriceUsd ?? variant.basePriceUsd;
}
export function isSale(variant: Variant): boolean {
  const price = variantPrice(variant);
  return price !== null && (variant.oldPriceUsd ?? 0) > price;
}
export function productSaleVariant(product: Product): Variant | undefined {
  const available = product.variants.filter(
    (v) => v.status === "in-stock" || v.status === "on-order",
  );
  const price = productPriceFrom(product);
  return available.find((v) => variantPrice(v) === price && isSale(v));
}

/** Цена карточки = минимальная цена доступных вариантов («цена от», ТЗ §13) */
export function productPriceFrom(product: Product): number | null {
  const available = product.variants.filter(
    (v) => v.status === "in-stock" || v.status === "on-order",
  );
  const prices = available
    .map(variantPrice)
    .filter((p): p is number => p !== null);
  return prices.length ? Math.min(...prices) : null;
}

export function productStatus(product: Product): ProductStatus {
  if (product.variants.some((v) => v.status === "in-stock")) return "in-stock";
  if (product.variants.some((v) => v.status === "on-order")) return "on-order";
  if (product.variants.some((v) => v.status === "request")) return "request";
  return "out";
}

/* ---------- Запрос каталога с фильтрами и сортировкой (ТЗ §11) ---------- */

export type CatalogSort = "recommended" | "new" | "price-asc" | "price-desc";

export const CATALOG_SORTS: CatalogSort[] = [
  "recommended",
  "new",
  "price-asc",
  "price-desc",
];

export interface CatalogQuery {
  category?: CategorySlug;
  subcategory?: string;
  sale?: boolean;
  /** Модель, серия, цвет, артикул или ключевые слова */
  q?: string;
  storageGb?: number;
  color?: string;
  availability?: "in-stock" | "on-order";
  /** Верхняя граница цены «от», USD */
  maxPriceUsd?: number;
  sort?: CatalogSort;
}

function matchesQuery(product: Product, q: string): boolean {
  const haystack = [
    product.name,
    product.series,
    product.tagline,
    product.slug,
    ...product.variants.map((v) => `${v.sku} ${v.colorName}`),
  ]
    .join(" ")
    .toLowerCase();
  return haystack.includes(q);
}

/** Фильтрация и сортировка каталога; sort по умолчанию — порядок, заданный в админке */
export function queryProducts(
  query: CatalogQuery = {},
  source: Product[],
): Product[] {
  let list = source.filter(
    (p) =>
      !p.hidden &&
      (!query.category || p.category === query.category) &&
      (!query.subcategory || p.subcategory === query.subcategory),
  );

  const q = query.q?.trim().toLowerCase();
  if (q) list = list.filter((p) => matchesQuery(p, q));

  if (
    query.storageGb !== undefined ||
    query.sale ||
    query.color ||
    query.availability ||
    query.maxPriceUsd !== undefined
  )
    list = list.filter((p) =>
      p.variants.some(
        (v) =>
          (!query.sale ||
            (isSale(v) &&
              (v.status === "in-stock" || v.status === "on-order"))) &&
          (query.storageGb === undefined || v.storageGb === query.storageGb) &&
          (!query.color ||
            v.colorName.toLowerCase() === query.color.toLowerCase()) &&
          (!query.availability || v.status === query.availability) &&
          (query.maxPriceUsd === undefined ||
            (variantPrice(v) !== null &&
              variantPrice(v)! <= query.maxPriceUsd)),
      ),
    );

  switch (query.sort) {
    case "new":
      list.sort((a, b) => b.addedAt.localeCompare(a.addedAt));
      break;
    case "price-asc":
      list.sort(
        (a, b) =>
          (productPriceFrom(a) ?? Infinity) - (productPriceFrom(b) ?? Infinity),
      );
      break;
    case "price-desc":
      list.sort(
        (a, b) =>
          (productPriceFrom(b) ?? -Infinity) -
          (productPriceFrom(a) ?? -Infinity),
      );
      break;
    default:
      break;
  }

  return list;
}
