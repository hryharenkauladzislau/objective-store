import { z } from "zod";
import { presentationSchema } from "@/lib/presentation";
const text = z.string().max(1000);
const slug = z.string().regex(/^[a-z0-9][a-z0-9-]{0,99}$/);
const amount = z.number().finite().min(0).max(1000000).nullable();
export const imageSchema = z
  .string()
  .max(2000)
  .refine(
    (s) =>
      /^\/images\/[a-zA-Z0-9/_\.\-]+$/.test(s) ||
      /^\/api\/media\/[0-9a-f-]{36}$/.test(s) ||
      /^https:\/\/www\.apple\.com\//.test(s),
    "Используйте загруженное фото или источник Apple",
  );
export const variantSchema = z.object({
  sku: z.string().trim().min(1).max(120).regex(/^[^\t\r\n]+$/, "SKU не должен содержать переносы строки или табуляцию"),
  storageGb: z.number().int().positive().max(16384).nullable(),
  colorHex: z.string().regex(/^#[a-fA-F0-9]{6}$/),
  colorName: text.min(1),
  sim: text.min(1),
  basePriceUsd: amount,
  manualPriceUsd: amount,
  oldPriceUsd: amount.optional(),
  status: z.enum(["in-stock", "on-order", "out", "request"]),
  images: z.array(imageSchema).max(20),
});
export const productSchema = z.object({
  slug,
  category: slug,
  subcategory: slug.nullable().optional(),
  name: text.min(1),
  series: text,
  tagline: text,
  addedAt: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  featuredOnHome: z.boolean(),
  hidden: z.boolean().optional(),
  specs: z.array(z.object({ label: text.min(1), value: text })).max(60),
  variants: z.array(variantSchema).min(1).max(600),
});
export const usedSchema = z.object({
  id: slug,
  slug,
  name: text.min(1),
  storageGb: z.number().int().positive(),
  colorName: text,
  condition: z.enum(["excellent", "good", "fair"]),
  conditionNote: text,
  batteryHealth: z.number().min(0).max(100),
  batteryReplaced: z.boolean(),
  kit: z.array(text).max(40),
  checks: z.array(text).max(40),
  defects: text.nullable(),
  warrantyMonths: z.number().int().min(0).max(60),
  priceUsd: z.number().min(0).max(1000000),
  oldPriceUsd: amount.optional(),
  images: z.array(imageSchema).max(20),
  sold: z.boolean().optional(),
});
const tg = z.string().regex(/^https:\/\/t\.me\/[a-zA-Z0-9_]+$/);
export const settingsSchema = z.object({
  coefficient: z.number().positive().max(10000),
  rounding: z.union([z.literal(1), z.literal(5), z.literal(10), z.literal(50)]),
  phone: z.string().regex(/^\+?[\d\s()\-]{7,30}$/),
  telegramUrl: tg,
  telegramChannel: tg,
  instagramUrl: z
    .string()
    .regex(/^https:\/\/(www\.)?instagram\.com\/[a-zA-Z0-9_\.]+\/?$/),
  address: text,
  hours: text,
  email: z.email(),
  legalName: text,
  legalId: text,
});
export const catalogSchema = z
  .object({
    revision: z.number().int().nonnegative(),
    presentation: presentationSchema.optional(),
    products: z.array(productSchema).max(500),
    used: z.array(usedSchema).max(1000),
    categories: z
      .array(
        z.object({
          slug: productSchema.shape.category,
          name: text.min(1),
          caption: text,
          image: imageSchema.nullable().optional(),
          hidden: z.boolean().optional(),
          direct: z.boolean().optional(),
          subcategories: z
            .array(z.object({ slug, name: text.min(1), image: imageSchema.nullable().optional() }))
            .max(150)
            .optional(),
        }),
      )
      .min(1)
      .max(50),
    settings: settingsSchema,
    tradeIn: z
      .array(
        z.object({
          id: slug,
          model: text.min(1),
          storageGb: z.number().int().positive().nullable(),
          maxPrice: z.number().positive().max(1000000),
          currency: z.enum(["USD", "BYN", "RUB"]),
          sourceUrl: z.url().refine((s) => s.startsWith("https://")),
          checkedAt: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
          approved: z.boolean(),
        }),
      )
      .max(500)
      .optional(),
    tradeInSettings: z.object({
      deviceTypes: z.array(text.min(1)).min(1).max(20),
      conditionOptions: z.array(text.min(1)).min(1).max(20),
      workOptions: z.array(text.min(1)).min(1).max(20),
      intro: z.string().max(3000),
      estimateNotice: z.string().max(3000),
      photoNotice: z.string().max(1000),
    }).optional(),
    pages: z
      .record(
        z.string().regex(/^(shipping|warranty|repair|faq|privacy|terms|about|contacts|trade-in|catalog|used|compare)$/),
        z.object({
          title: text.min(1),
          intro: z.string().max(2000),
          sections: z
            .array(z.object({ title: text.min(1), text: z.string().max(8000) }))
            .max(30),
        }),
      )
      .optional(),
  })
  .superRefine((d, c) => {
    d.used.forEach((u, i) => {
      if (u.oldPriceUsd != null && u.oldPriceUsd <= u.priceUsd)
        c.addIssue({
          code: "custom",
          path: ["used", i, "oldPriceUsd"],
          message: "Старая цена должна быть выше новой",
        });
      if (!u.sold && !u.images.length)
        c.addIssue({
          code: "custom",
          path: ["used", i, "images"],
          message: "Для опубликованного экземпляра нужны реальные фото",
        });
    });
    const seen = new Set<string>();
    const slugs = new Set<string>();
    const cats = new Set(d.categories.map((x) => x.slug));
    d.categories.forEach((cat, i) => {
      const subs = (cat.subcategories || []).map((s) => s.slug);
      if (new Set(subs).size !== subs.length)
        c.addIssue({
          code: "custom",
          path: ["categories", i, "subcategories"],
          message: "Подкатегория повторяется",
        });
    });
    const rates = d.tradeIn || [];
    if (
      new Set(rates.map((r) => r.id)).size !== rates.length ||
      new Set(
        rates.map((r) =>
          JSON.stringify([r.model.toLowerCase().trim(), r.storageGb]),
        ),
      ).size !== rates.length
    )
      c.addIssue({
        code: "custom",
        path: ["tradeIn"],
        message: "Оценка модели/памяти повторяется",
      });
    d.products.forEach((p, i) => {
      if (slugs.has(p.slug))
        c.addIssue({
          code: "custom",
          path: ["products", i, "slug"],
          message: "Slug повторяется",
        });
      slugs.add(p.slug);
      const category = d.categories.find((cat) => cat.slug === p.category);
      if (
        p.subcategory &&
        !category?.subcategories?.some((s) => s.slug === p.subcategory)
      )
        c.addIssue({
          code: "custom",
          path: ["products", i, "subcategory"],
          message: "Подкатегория отсутствует",
        });
      if (!cats.has(p.category))
        c.addIssue({
          code: "custom",
          path: ["products", i, "category"],
          message: "Категория отсутствует",
        });
      const combos = new Set<string>();
      p.variants.forEach((v, j) => {
        const price =
          v.manualPriceUsd ??
          (v.basePriceUsd === null
            ? null
            : Math.round(
                (v.basePriceUsd * d.settings.coefficient) / d.settings.rounding,
              ) * d.settings.rounding);
        if (v.oldPriceUsd != null && (price === null || v.oldPriceUsd <= price))
          c.addIssue({
            code: "custom",
            path: ["products", i, "variants", j, "oldPriceUsd"],
            message:
              "Старая цена должна быть выше новой; для отключения скидки очистите поле",
          });
        if (seen.has(v.sku))
          c.addIssue({
            code: "custom",
            path: ["products", i, "variants", j, "sku"],
            message: "SKU повторяется",
          });
        seen.add(v.sku);
        const k = JSON.stringify([v.storageGb, v.colorName, v.sim]);
        if (combos.has(k))
          c.addIssue({
            code: "custom",
            path: ["products", i, "variants", j],
            message: "Вариант повторяется",
          });
        combos.add(k);
      });
    });
    for (const field of [
      d.used.map((u) => u.slug),
      d.used.map((u) => u.id),
      d.categories.map((x) => x.slug),
    ])
      if (new Set(field).size !== field.length)
        c.addIssue({ code: "custom", message: "Повторяющиеся идентификаторы" });
  });
export type CatalogDocument = z.infer<typeof catalogSchema>;
