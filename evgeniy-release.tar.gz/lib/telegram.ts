export function telegramLink(base: string, text: string) {
  return base + "?text=" + encodeURIComponent(text.slice(0, 3500));
}
export function track(
  event: string,
  detail: Record<string, string | number> = {},
) {
  if (typeof window !== "undefined")
    window.dispatchEvent(
      new CustomEvent("ea:analytics", { detail: { event, ...detail } }),
    );
}
