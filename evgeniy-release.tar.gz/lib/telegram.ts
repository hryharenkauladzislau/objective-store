/** Accept an old escaped draft without escaping it again. Plain % prices remain intact. */
export function telegramDraft(text: string) {
  let draft = text;
  for (let i = 0; i < 3 && /%(?:D[01]|F0|25(?:D[01]|F0)|2525(?:D[01]|F0))/i.test(draft); i++) {
    const decoded = draft.replace(/(?:%[0-9a-f]{2})+/gi, chunk => {
      try { return decodeURIComponent(chunk); } catch { return chunk; }
    });
    if (decoded === draft) break;
    draft = decoded;
  }
  return Array.from(draft.replace(/\u00a0/g, " ")).slice(0, 3500).join("");
}

/** Use Telegram's universal link, as in the original checkout.
 * Normalize legacy drafts first, then encode the query exactly once.
 */
export function telegramLink(base: string, text: string) {
  const username = new URL(base).pathname.replace(/^\/+|\/+$/g, "");
  if (!/^[a-zA-Z0-9_]+$/.test(username)) throw new Error("Некорректный Telegram username");
  return "https://t.me/" + username + "?text=" + encodeURIComponent(telegramDraft(text));
}
export function track(
  event: string,
  detail: Record<string, string | number> = {},
) {
  if (typeof window !== "undefined")
    window.dispatchEvent(
      new CustomEvent("ea:analytics", { detail: { event, ...detail } }),
    );
}
