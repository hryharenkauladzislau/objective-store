export function telegramLink(base: string, text: string) {
  // Pass the UTF-8 draft directly to Telegram's OS handler. The HTTPS landing
  // page adds another URL handoff and can leave percent escapes in the draft.
  const username = new URL(base).pathname.replace(/^\/+|\/+$/g, "");
  if (!/^[a-zA-Z0-9_]+$/.test(username)) throw new Error("Некорректный Telegram username");
  const draft = Array.from(text.replace(/\u00a0/g, " ")).slice(0, 3500).join("");
  return "tg://resolve?domain=" + username + "&text=" + encodeURIComponent(draft);
}
export function track(
  event: string,
  detail: Record<string, string | number> = {},
) {
  if (typeof window !== "undefined")
    window.dispatchEvent(
      new CustomEvent("ea:analytics", { detail: { event, ...detail } }),
    );
}
