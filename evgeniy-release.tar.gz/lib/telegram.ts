/** Accept an old escaped draft without escaping it again. Plain % prices remain intact. */
export function telegramDraft(text: string) {
  let draft = text;
  for (let i = 0; i < 3 && /%(?:D[01]|F0|25(?:D[01]|F0)|2525(?:D[01]|F0))/i.test(draft); i++) {
    const decoded = draft.replace(/(?:%[0-9a-f]{2})+/gi, chunk => {
      try { return decodeURIComponent(chunk); } catch { return chunk; }
    });
    if (decoded === draft) break;
    draft = decoded;
  }
  return Array.from(draft.replace(/\u00a0/g, " ")).slice(0, 3500).join("");
}

export function isMacTelegram() {
  return typeof navigator !== "undefined" && /Macintosh|Mac OS X/.test(navigator.userAgent) && navigator.maxTouchPoints === 0;
}

export function telegramLink(base: string, text: string, options: { draft?: boolean } = {}) {
  // Pass the UTF-8 draft directly to Telegram's OS handler. The HTTPS landing
  // page adds another URL handoff and can leave percent escapes in the draft.
  const username = new URL(base).pathname.replace(/^\/+|\/+$/g, "");
  if (!/^[a-zA-Z0-9_]+$/.test(username)) throw new Error("Некорректный Telegram username");
  const draft = telegramDraft(text);
  return "tg://resolve?domain=" + username + (options.draft === false ? "" : "&text=" + encodeURIComponent(draft));
}
export function track(
  event: string,
  detail: Record<string, string | number> = {},
) {
  if (typeof window !== "undefined")
    window.dispatchEvent(
      new CustomEvent("ea:analytics", { detail: { event, ...detail } }),
    );
}

/** Copy the readable draft as a fallback for clients which retain an old/escaped draft.
 * The native link still fills the message; nothing is sent automatically.
 * Do not wait for clipboard permission before opening Telegram in the click gesture.
 */
export function prepareTelegramDraft(text: string) {
  if (typeof navigator !== "undefined" && navigator.clipboard?.writeText)
    void navigator.clipboard.writeText(telegramDraft(text)).catch(() => {});
}
