import { spawn } from "node:child_process";
import { mkdtemp, rm, mkdir } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { randomBytes } from "node:crypto";
import assert from "node:assert/strict";
import ExcelJS from "exceljs";
import sharp from "sharp";
import { chromium } from "@playwright/test";
const port = 3217,
  origin = "http://127.0.0.1:" + port;
const nativeFetch = globalThis.fetch;
globalThis.fetch = (url, options = {}) =>
  nativeFetch(url, { signal: AbortSignal.timeout(8000), ...options });
const dir = await mkdtemp(path.join(tmpdir(), "ea-check-"));
const password = randomBytes(18).toString("hex");
const server = spawn(
  process.execPath,
  [
    "node_modules/next/dist/bin/next",
    "start",
    "-p",
    String(port),
    "--hostname",
    "127.0.0.1",
  ],
  {
    env: {
      ...process.env,
      DATABASE_URL: "",
      STORAGE_DIR: dir,
      ADMIN_PASSWORD: password,
      ADMIN_SESSION_SECRET: randomBytes(32).toString("hex"),
      NEXT_PUBLIC_SITE_URL: origin,
    },
    stdio: ["ignore", "pipe", "pipe"],
  },
);
let logs = "";
server.stdout.on("data", (x) => {
  logs += x;
  process.stdout.write(x);
});
server.stderr.on("data", (x) => {
  logs += x;
  process.stderr.write(x);
});
let browser;
let count = 0;
const ok = (message) => {
  count++;
  console.log("PASS", message);
};
try {
  for (let i = 0; i < 100; i++) {
    try {
      if ((await fetch(origin + "/api/catalog")).ok) break;
    } catch {}
    await new Promise((r) => setTimeout(r, 100));
  }
  const routes = [
    "/",
    "/catalog",
    "/catalog/iphone-17-pro",
    "/about",
    "/contacts",
    "/used",
    "/compare",
    "/trade-in",
    "/shipping",
    "/warranty",
    "/repair",
    "/faq",
    "/privacy",
    "/terms",
    "/admin",
    "/api/health",
    "/robots.txt",
    "/sitemap.xml",
  ];
  for (const p of routes)
    assert.equal((await fetch(origin + p)).status, 200, p);
  ok(routes.length + " routes");
  assert.equal((await fetch(origin + "/catalog/does-not-exist")).status, 404);
  ok("404 for unknown product");
  assert.equal((await fetch(origin + "/api/admin/catalog")).status, 401);
  assert.equal(
    (
      await fetch(origin + "/api/admin/session", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Origin: "https://wrong.example",
        },
        body: JSON.stringify({ password }),
      })
    ).status,
    403,
  );
  ok("protected admin and origin checks");
  const login = await fetch(origin + "/api/admin/session", {
    method: "POST",
    headers: { "Content-Type": "application/json", Origin: origin },
    body: JSON.stringify({ password }),
  });
  assert.equal(login.status, 200);
  const cookie = login.headers.get("set-cookie").split(";")[0];
  const headers = {
    Cookie: cookie,
    Origin: origin,
    "Content-Type": "application/json",
  };
  const get = async () =>
    await (
      await fetch(origin + "/api/admin/catalog", {
        headers: { Cookie: cookie },
      })
    ).json();
  const put = async (d) =>
    await fetch(origin + "/api/admin/catalog", {
      method: "PUT",
      headers,
      body: JSON.stringify(d),
    });
  let d = await get();
  const baseline = structuredClone(d);
  assert.equal(d.products.length, 18);
  assert.equal(d.used.length, 0);
  assert.ok(d.products.every((p) => p.variants.length));
  ok("complete seed without fictional used stock");
  const apple = d.categories.find((c) => c.slug === "apple");
  assert.equal(d.settings.telegramUrl, "https://t.me/Evgeniy_apple");
  assert.equal(d.settings.telegramChannel, "https://t.me/evgeniy_apple_minsk");
  assert.equal(d.settings.instagramUrl, "https://www.instagram.com/evgeniy_apple/");
  assert.ok(apple?.image && apple.subcategories.every((s) => s.image));
  ok("manager, channel, Instagram and category artwork are configured");
  const exportFile = await fetch(origin + "/api/admin/excel", {
    headers: { Cookie: cookie },
  });
  const exported = new ExcelJS.Workbook();
  await exported.xlsx.load(Buffer.from(await exportFile.arrayBuffer()));
  assert.equal(exported.worksheets[0].rowCount, 230);
  ok("Excel export contains every SKU");
  const invalid = structuredClone(d);
  invalid.products[0].variants[1].sku = invalid.products[0].variants[0].sku;
  assert.equal((await put(invalid)).status, 400);
  ok("duplicate SKU rejected");
  d.pages = {
    shipping: {
      title: "Доставка и оплата",
      intro: "Проверка редактора условий",
      sections: [{ title: "Самовывоз", text: "По предварительной записи" }],
    },
  };
  d.settings.coefficient = 1.03;
  d.settings.rounding = 5;
  d.products[0].variants[0].basePriceUsd = 100;
  d.products[0].variants[0].manualPriceUsd = null;
  d.products[0].variants[0].status = "in-stock";
  d.products[0].variants[1].manualPriceUsd = 205;
  const stale = structuredClone(d);
  let saved = await put(d);
  assert.equal(saved.status, 200);
  d = await saved.json();
  assert.ok(
    (await (await fetch(origin + "/shipping")).text()).includes(
      "Проверка редактора условий",
    ),
  );
  ok("editable service-page content");
  assert.equal((await put(stale)).status, 409);
  const pub = await (await fetch(origin + "/api/catalog")).json();
  assert.equal(pub.products[0].variants[0].manualPriceUsd, 105);
  assert.equal(pub.products[0].variants[1].manualPriceUsd, 205);
  assert.equal(pub.products[0].variants[0].basePriceUsd, null);
  assert.equal(pub.settings.coefficient, 1);
  ok("persisted coefficient, rounding, manual override and revision conflict");
  // Category lifecycle and discounts must persist without losing products.
  d.categories.push({
    slug: "custom-test",
    name: "Тестовая категория",
    caption: "",
    direct: false,
    subcategories: [{ slug: "sub-test", name: "Тестовая серия" }],
  });
  d.products[0].category = "custom-test";
  d.products[0].subcategory = "sub-test";
  d.products[0].variants[0].oldPriceUsd = 150;
  assert.equal((await put(d)).status, 200);
  d = await get();
  const saleHtml = await (
    await fetch(
      origin + "/catalog?category=custom-test&subcategory=sub-test&sale=1",
    )
  ).text();
  assert.ok(saleHtml.includes("SALE") && saleHtml.includes("<del"));
  assert.ok(saleHtml.includes("Тестовая серия"));
  const saleDocument = structuredClone(d);
  saleDocument.products[0].variants[0].oldPriceUsd = 50;
  assert.equal((await put(saleDocument)).status, 400);
  d.categories.find((c) => c.slug === "custom-test").hidden = true;
  assert.equal((await put(d)).status, 200);
  assert.equal(
    (await fetch(origin + "/catalog/" + d.products[0].slug)).status,
    404,
  );
  d = await get();
  assert.ok(d.products.some((p) => p.slug === baseline.products[0].slug));
  d.categories.find((c) => c.slug === "custom-test").hidden = false;
  assert.equal((await put(d)).status, 200);
  assert.equal(
    (await fetch(origin + "/catalog/" + d.products[0].slug)).status,
    200,
  );
  d = await get();
  // Disable discount before subsequent import changes the price.
  d.products[0].variants[0].oldPriceUsd = null;
  assert.equal((await put(d)).status, 200);
  d = await get();
  assert.equal(d.tradeIn.length, 22);
  assert.equal(
    d.tradeIn.find((r) => r.model === "iPhone 15 Pro").maxPrice,
    88000,
  );
  assert.equal(
    d.tradeIn.find((r) => r.model === "iPhone 15 Pro").currency,
    "RUB",
  );
  assert.ok(d.tradeIn.every((r) => !r.approved));
  ok(
    "custom categories, subcategory filtering, restore and truthful SALE prices",
  );
  ok("Trade-in reference keeps source currency and requires merchant approval");
  const w = new ExcelJS.Workbook();
  const s = w.addWorksheet("Каталог");
  s.addRow(["sku", "basePriceUsd"]);
  s.addRow([d.products[0].variants[0].sku, 125]);
  const bytes = Buffer.from(await w.xlsx.writeBuffer());
  const f = new FormData();
  f.set("file", new Blob([bytes]), "prices.xlsx");
  const preview = await (
    await fetch(origin + "/api/admin/excel", {
      method: "POST",
      headers: { Cookie: cookie, Origin: origin },
      body: f,
    })
  ).json();
  assert.equal(preview.counts.changed, 1);
  assert.equal(preview.counts.error, 0);
  assert.equal((await get()).revision, d.revision);
  assert.equal((await put(preview.candidate)).status, 200);
  d = await get();
  ok("Excel preview does not write; apply preserves absent SKUs");
  s.addRow(["", 50]);
  const f2 = new FormData();
  f2.set(
    "file",
    new Blob([Buffer.from(await w.xlsx.writeBuffer())]),
    "bad.xlsx",
  );
  const bad = await (
    await fetch(origin + "/api/admin/excel", {
      method: "POST",
      headers: { Cookie: cookie, Origin: origin },
      body: f2,
    })
  ).json();
  assert.equal(bad.candidate, null);
  assert.ok(bad.counts.error);
  ok("Excel errors block application");
  const png = await sharp({
    create: { width: 100, height: 100, channels: 3, background: "#dddddd" },
  })
    .png()
    .toBuffer();
  const photo = new FormData();
  photo.set("file", new Blob([png]), "photo.png");
  const up = await fetch(origin + "/api/admin/photos", {
    method: "POST",
    headers: { Cookie: cookie, Origin: origin },
    body: photo,
  });
  assert.equal(up.status, 200);
  const url = (await up.json()).url;
  assert.equal(
    (await fetch(origin + url)).headers.get("content-type"),
    "image/webp",
  );
  ok("photo upload, resize and persistent media route");
  assert.equal(
    (await fetch(origin + "/api/media/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"))
      .status,
    404,
  );
  ok("invalid media IDs return 404");
  d.used.push({
    id: "test-used",
    slug: "test-used",
    name: "Тестовый экземпляр",
    storageGb: 128,
    colorName: "Белый",
    condition: "good",
    conditionNote: "Тест",
    batteryHealth: 90,
    batteryReplaced: false,
    kit: ["Кабель"],
    checks: ["Камера"],
    defects: null,
    warrantyMonths: 0,
    priceUsd: 500,
    oldPriceUsd: 600,
    images: [url],
    sold: false,
  });
  assert.equal((await put(d)).status, 200);
  assert.equal((await fetch(origin + "/used/test-used")).status, 200);
  assert.ok(
    (await (await fetch(origin + "/used/test-used")).text()).includes("<del"),
  );
  d = await get();
  d.used[0].sold = true;
  d.products[1].hidden = true;
  assert.equal((await put(d)).status, 200);
  assert.equal((await fetch(origin + "/used/test-used")).status, 404);
  assert.equal(
    (await fetch(origin + "/catalog/" + d.products[1].slug)).status,
    404,
  );
  ok("used passport, sold and hidden routes");
  baseline.revision = (await get()).revision;
  assert.equal((await put(baseline)).status, 200);
  browser = await chromium.launch({
    headless: true,
    ...(process.env.BROWSER_EXECUTABLE_PATH
      ? {
          executablePath: process.env.BROWSER_EXECUTABLE_PATH,
          args: ["--no-sandbox", "--disable-gpu", "--disable-dev-shm-usage"],
        }
      : {}),
  });
  const ctx = await browser.newContext({ reducedMotion: "reduce" });
  const page = await ctx.newPage();
  const errors = [];
  page.on("pageerror", (e) => errors.push(e.message));
  await page.goto(origin);
  await page.getByRole("dialog").waitFor();
  assert.equal(await page.getByRole("dialog").getByRole("link").count(), 4);
  await page.getByRole("button", { name: "Перейти на сайт" }).click();
  await page.getByRole("dialog").waitFor({ state: "hidden" });
  ok("entry service chooser");
  await mkdir("docs/screenshots", { recursive: true });
  for (const width of [375, 768, 1280, 1440]) {
    await page.setViewportSize({ width, height: 950 });
    await page.goto(origin);
    await page.evaluate(() => document.fonts.ready);
    await page.waitForTimeout(250);
    assert.ok(
      await page.evaluate(
        () => document.documentElement.scrollWidth <= innerWidth,
      ),
      "homepage overflow " + width,
    );
    if (width === 375 || width === 1440) {
      await page.screenshot({
        path: "docs/screenshots/home-" + width + ".png",
        fullPage: true,
      });
    }
    await page.goto(origin + "/catalog");
    assert.ok(
      await page.evaluate(
        () => document.documentElement.scrollWidth <= innerWidth,
      ),
      "catalog overflow " + width,
    );
  }
  ok("home and catalog widths 375/768/1280/1440");
  await page.setViewportSize({ width: 1280, height: 900 });
  await page.goto(origin + "/catalog/iphone-17-pro-max");
  await page.getByRole("button", { name: "512 ГБ", exact: true }).click();
  await page.getByRole("button", { name: "Deep Blue", exact: true }).click();
  const link = await page
    .getByRole("link", { name: /Уточнить цену|Купить/ })
    .getAttribute("href");
  const text = new URL(link).searchParams.get("text");
  assert.ok(
    text.includes("512 ГБ") &&
      text.includes("Deep Blue") &&
      text.includes("Хочу купить товар") &&
      text.includes("Цена от:"),
  );
  await page.getByRole("button", { name: "Фото 2", exact: true }).click();
  assert.equal(
    await page
      .getByRole("button", { name: "Фото 2", exact: true })
      .getAttribute("aria-pressed"),
    "true",
  );
  ok("variant-specific Telegram draft and gallery");
  await page.getByRole("button", { name: "＋ Сравнить", exact: true }).click();
  await page.goto(origin + "/compare");
  await page
    .getByRole("link", { name: "iPhone 17 Pro Max", exact: false })
    .waitFor();
  await page.evaluate(() => {
    localStorage.setItem("ea:compare", "broken-json");
    window.dispatchEvent(new Event("ea:compare"));
  });
  await page
    .getByText("Выберите до трёх моделей для сравнения.", { exact: true })
    .waitFor();
  ok("comparison persists across navigation");
  await page.goto(origin + "/trade-in");
  await page.getByLabel("Модель", { exact: true }).fill("iPhone 15");
  await page.getByLabel("Память", { exact: true }).fill("256");
  await page.getByRole("button", { name: "Далее" }).click();
  await page.getByLabel("Состояние аккумулятора").fill("88");
  await page.getByRole("button", { name: "Далее" }).click();
  await page.getByLabel("Телефон или Telegram").fill("@tester");
  const trade = new URL(
    await page
      .getByRole("link", { name: "Отправить на оценку", exact: false })
      .getAttribute("href"),
  ).searchParams.get("text");
  assert.ok(
    trade.includes("iPhone 15") &&
      trade.includes("88") &&
      trade.includes("@tester"),
  );
  assert.ok(
    trade.includes("55000") || trade.replace(/\s/g, "").includes("55000"),
  );
  assert.ok(trade.includes("istock38.ru") && trade.includes("Не утверждённая"));
  await page.getByRole("button", { name: "Назад" }).click();
  assert.equal(
    await page.getByLabel("Состояние аккумулятора").inputValue(),
    "88",
  );
  ok("Trade-in steps retain details and prepare draft");
  await page.setViewportSize({ width: 375, height: 900 });
  await page.goto(origin + "/catalog/iphone-17-pro-max");
  assert.ok(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= innerWidth,
    ),
  );
  await page.screenshot({
    path: "docs/screenshots/product-375.png",
    fullPage: true,
  });
  ok("mobile product configuration");
  await page.goto(origin + "/admin");
  await page.getByLabel("Пароль", { exact: true }).fill(password);
  await page.getByRole("button", { name: "Войти", exact: true }).click();
  await page.getByRole("button", { name: "Цены", exact: true }).waitFor();
  await page.getByRole("button", { name: "Цены", exact: true }).click();
  await page.getByLabel("Категория", { exact: true }).selectOption("apple");
  assert.ok((await page.locator("tbody tr").count()) > 20);
  await page.getByRole("button", { name: "Товары", exact: true }).click();
  await page
    .getByRole("button", { name: "Добавить модель", exact: false })
    .click();
  await page
    .getByLabel("Название", { exact: true })
    .fill("Новая тестовая модель");
  await page
    .getByRole("button", { name: "Сохранить изменения", exact: true })
    .click();
  await page.getByRole("status").filter({ hasText: "Сохранено" }).waitFor();
  ok("admin login, category price filter and new-model save");
  await page.getByRole("button", { name: "Категории", exact: true }).click();
  await page.getByRole("button", { name: "Убрать Apple", exact: true }).click();
  await page
    .getByRole("button", { name: "Восстановить Apple", exact: true })
    .click();
  await page
    .getByRole("button", { name: "Сохранить изменения", exact: true })
    .click();
  await page.getByRole("status").filter({ hasText: "Сохранено" }).waitFor();
  await page.getByRole("button", { name: "Trade-in", exact: true }).click();
  assert.equal(await page.getByLabel("Цена магазина утверждена").count(), 22);
  await page.screenshot({
    path: "docs/screenshots/admin-trade-in-375.png",
    fullPage: true,
  });
  ok("admin category restore and editable sourced Trade-in rates");
  await page.setViewportSize({ width: 375, height: 900 });
  if (
    !(await page.evaluate(
      () => document.documentElement.scrollWidth <= innerWidth,
    ))
  ) {
    console.log(
      await page.evaluate(() =>
        Array.from(document.querySelectorAll("body *"))
          .filter((el) => el.getBoundingClientRect().right > innerWidth + 1)
          .slice(0, 10)
          .map((el) => ({
            tag: el.tagName,
            cls: el.className,
            width: el.getBoundingClientRect().width,
          })),
      ),
    );
    await page.screenshot({ path: "docs/screenshots/admin-overflow.png" });
  }
  assert.ok(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= innerWidth,
    ),
    "admin overflow",
  );
  ok("mobile admin layout");
  await page.getByRole("button", {name:"Сайт",exact:true}).click();
  await page.getByLabel("Заголовок блока",{exact:true}).fill("Карусель магазина: CMS проверка");
  await page.getByRole("button",{name:"Сохранить изменения",exact:true}).click();
  await page.getByRole("status").filter({hasText:"Сохранено"}).waitFor();
  assert.ok((await (await fetch(origin+"/")).text()).includes("Карусель магазина: CMS проверка"));
  ok("site editor publishes homepage copy and mobile editor has no overflow");
  assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
  let cmsDoc=await get();
  const cmsOriginal=structuredClone(cmsDoc.presentation);
  cmsDoc.presentation.home.find(b=>b.id==="steps").enabled=false;
  const contactsBlock=cmsDoc.presentation.home.find(b=>b.id==="contacts");
  cmsDoc.presentation.home=cmsDoc.presentation.home.filter(b=>b.id!=="contacts");
  cmsDoc.presentation.home.unshift(contactsBlock);
  cmsDoc.presentation.navigation[0].label="Все новые устройства";
  cmsDoc.presentation.theme.accent="#305639";
  cmsDoc.presentation.entry.enabled=false;
  cmsDoc.presentation.loader.enabled=false;
  assert.equal((await put(cmsDoc)).status,200);
  const cmsHtml=await (await fetch(origin+"/")).text();
  assert.ok(!cmsHtml.includes('data-home-block="steps"'));
  assert.ok(cmsHtml.indexOf('data-home-block="contacts"')<cmsHtml.indexOf('data-home-block="carousel"'));
  assert.ok(cmsHtml.includes("Все новые устройства"));
  assert.ok(cmsHtml.includes("#305639"));
  ok("CMS controls order, visibility, navigation and theme");
  cmsDoc=await get();const badCms=structuredClone(cmsDoc);
  badCms.presentation.navigation[0].href="javascript:alert(1)";
  assert.equal((await put(badCms)).status,400);
  badCms.presentation.navigation[0].href="//external.example";
  assert.equal((await put(badCms)).status,400);
  ok("CMS rejects script and external protocol-relative links");
  cmsDoc.presentation=cmsOriginal;
  cmsDoc.products.filter(n=>n.category==="iphone").slice(0,5).forEach(n=>{n.featuredOnHome=true;n.variants[0].status="in-stock";});
  assert.equal((await put(cmsDoc)).status,200);
  await page.setViewportSize({width:1440,height:950});
  await page.emulateMedia({reducedMotion:"no-preference"});
  await page.goto(origin);
  const belt=page.locator('[data-carousel="true"]');
  await belt.waitFor();await belt.hover();
  const beforeHover=await belt.evaluate(el=>el.scrollLeft);
  await page.waitForTimeout(700);
  const afterHover=await belt.evaluate(el=>el.scrollLeft);
  assert.ok(afterHover>beforeHover+10,"hover must not pause autoplay");
  ok("carousel continues autoplay while hovered on desktop");
  const rect=await belt.boundingBox();
  const dragStart=await belt.evaluate(el=>el.scrollLeft);
  await page.mouse.move(rect.x+220,rect.y+200);await page.mouse.down();
  await page.mouse.move(rect.x+60,rect.y+200,{steps:10});await page.mouse.up();
  assert.ok((await belt.evaluate(el=>el.scrollLeft))>dragStart+80,"desktop drag scrolls");
  assert.equal(new URL(page.url()).pathname,"/","drag must not open card");
  await page.waitForTimeout(900);
  const resumed=await belt.evaluate(el=>el.scrollLeft);
  await page.waitForTimeout(600);
  assert.ok((await belt.evaluate(el=>el.scrollLeft))>resumed+5,"autoplay resumes after drag");
  await page.getByRole("button",{name:"Следующие модели",exact:true}).click();
  await page.waitForTimeout(650);
  ok("desktop mouse drag, arrow navigation and resumed autoplay");
  await page.getByRole("button",{name:"Остановить карусель",exact:true}).click();
  const pausedPosition=await belt.evaluate(el=>el.scrollLeft);
  await page.waitForTimeout(500);
  assert.ok(Math.abs((await belt.evaluate(el=>el.scrollLeft))-pausedPosition)<3);
  ok("explicit pause remains available and functional");
  await page.emulateMedia({reducedMotion:"reduce"});
  await page.getByRole("button",{name:"Запустить карусель",exact:true}).click();
  const reducedPosition=await belt.evaluate(el=>el.scrollLeft);
  await page.waitForTimeout(500);
  assert.ok(Math.abs((await belt.evaluate(el=>el.scrollLeft))-reducedPosition)<3);
  ok("carousel respects reduced motion preference");
  await page.goto(origin+"/admin");
  await page.getByRole("button",{name:"Данные канала",exact:true}).click();
  await page.getByText("Архив прайса и источники магазина",{exact:true}).waitFor();
  await page.getByText("Опубликованные предложения: 93",{exact:true}).waitFor();
  ok("verified Telegram source archive available in admin");
  assert.deepEqual(errors, []);
  ok("no browser runtime errors");
  console.log(
    JSON.stringify({
      checks: count,
      routes: routes.length,
      browser: "Chromium",
      screenshots: ["home-375.png", "home-1440.png"],
    }),
  );
} catch (e) {
  console.error(e);
  console.error(logs.slice(-3000));
  process.exitCode = 1;
} finally {
  await browser?.close();
  server.kill("SIGTERM");
  await new Promise((resolve) => {
    server.on("exit", resolve);
    setTimeout(resolve, 1500);
  });
  await rm(dir, { recursive: true, force: true });
}
