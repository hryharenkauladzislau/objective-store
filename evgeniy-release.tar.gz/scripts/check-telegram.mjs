import assert from "node:assert/strict";
import { telegramLink } from "../lib/telegram.ts";

const draft = "Здравствуйте! Хочу купить товар: iPhone 17 Pro.\nПамять: 256 ГБ\nЦвет: Cosmic Orange\nВерсия: Nano-SIM + eSIM\nЦена от: $1\u00a0190.\nЗаряд: 88% & вопросы? #чехол 🍎";
const url = new URL(telegramLink("https://t.me/Evgeniy_apple", draft));
assert.equal(url.protocol, "tg:");
assert.equal(url.hostname, "resolve");
assert.equal(url.searchParams.get("domain"), "Evgeniy_apple");
assert.equal(url.searchParams.get("text"), draft.replace(/\u00a0/g, " "));
assert.equal(url.hash, "");
assert.deepEqual([...url.searchParams.keys()], ["domain", "text"]);
assert.ok(!url.href.includes("%25D0"), "Cyrillic must not be encoded twice");
const long = new URL(telegramLink("https://t.me/Evgeniy_apple/", "🍎".repeat(4000)));
assert.equal(Array.from(long.searchParams.get("text")).length, 3500);
assert.ok(!long.searchParams.get("text").includes("\uFFFD"));
assert.throws(() => telegramLink("https://t.me/bad/username", "Тест"));
console.log("PASS native Telegram drafts: Cyrillic, newlines, spaces, SIM +, URL delimiters, percent, emoji and safe truncation");
