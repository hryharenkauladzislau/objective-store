import assert from "node:assert/strict";
import { telegramLink, telegramDraft } from "../lib/telegram.ts";

const draft = "Здравствуйте! Хочу купить товар: iPhone 17 Pro.\nПамять: 256 ГБ\nЦвет: Cosmic Orange\nВерсия: Nano-SIM + eSIM\nЦена от: $1\u00a0190.\nЗаряд: 88% & вопросы? #чехол 🍎";
const url = new URL(telegramLink("https://t.me/Evgeniy_apple", draft));
assert.equal(url.protocol, "https:");
assert.equal(url.hostname, "t.me");
assert.equal(url.pathname, "/Evgeniy_apple");
assert.equal(url.searchParams.get("text"), draft.replace(/\u00a0/g, " "));
assert.equal(url.hash, "");
assert.deepEqual([...url.searchParams.keys()], ["text"]);
assert.ok(!url.href.includes("%25D0"), "Cyrillic must not be encoded twice");
const long = new URL(telegramLink("https://t.me/Evgeniy_apple/", "🍎".repeat(4000)));
assert.equal(Array.from(long.searchParams.get("text")).length, 3500);
assert.ok(!long.searchParams.get("text").includes("\uFFFD"));
assert.throws(() => telegramLink("https://t.me/bad/username", "Тест"));
console.log("PASS universal Telegram drafts: Cyrillic, newlines, spaces, SIM +, URL delimiters, percent, emoji and safe truncation");

assert.equal(telegramDraft(encodeURIComponent(draft)), draft.replace(/\u00a0/g, " "));
assert.equal(telegramDraft(encodeURIComponent(encodeURIComponent(draft))), draft.replace(/\u00a0/g, " "));
assert.equal(telegramDraft("%D0%97%D0%B4%D1%80%D0%B0%D0%B2%D1%81%D1%82%D0%B2%D1%83%D0%B9%D1%82%D0%B5! Цена от: $1%C2%A0190."), "Здравствуйте! Цена от: $1 190.");
assert.equal(telegramDraft("Скидка 50%, артикул ABC%20, память 256"), "Скидка 50%, артикул ABC%20, память 256");
console.log("PASS legacy mixed/double encoded drafts remain readable");
// Every platform receives the same non-empty automatic draft. No UA branch or
// clipboard dependency may strip it from the checkout link.
const { readFileSync } = await import("node:fs");
for (const name of ["TelegramRequest", "PurchaseBar"]) {
  const component = readFileSync(new URL("../components/catalog/" + name + ".tsx", import.meta.url), "utf8");
  assert.match(component, /telegramLink\(site\.telegramUrl!, text\)/);
  assert.doesNotMatch(component, /isMacTelegram|draft:\s*false|clipboard|preventDefault/);
}
assert.equal(new URL(telegramLink("https://t.me/Evgeniy_apple", encodeURIComponent(draft))).searchParams.get("text"), draft.replace(/\u00a0/g, " "));
console.log("PASS both purchase buttons keep the automatic draft on Mac and mobile");
