import urllib.request,re,json,pathlib,concurrent.futures,io
from PIL import Image
root=pathlib.Path(__file__).resolve().parents[1]
pages={
"iphone-17-pro":"2025/09/apple-unveils-iphone-17-pro-and-iphone-17-pro-max/",
"iphone-17":"2025/09/apple-debuts-iphone-17/",
"iphone-air":"2025/09/introducing-iphone-air-a-powerful-new-iphone-with-a-breakthrough-design/",
"iphone-16-pro":"2024/09/apple-debuts-iphone-16-pro-and-iphone-16-pro-max/",
"iphone-16":"2024/09/apple-introduces-iphone-16-and-iphone-16-plus/",
"iphone-16e":"2025/02/apple-debuts-iphone-16e-a-powerful-new-member-of-the-iphone-16-family/",
"iphone-15":"2023/09/apple-debuts-iphone-15-and-iphone-15-plus/",
"macbook-pro-16-m4":"2024/10/new-macbook-pro-features-m4-family-of-chips-and-apple-intelligence/",
"macbook-air-13-m4":"2025/03/apple-introduces-the-new-macbook-air-with-the-m4-chip-and-a-sky-blue-color/",
"ipad-pro-m5":"2025/10/apple-introduces-the-powerful-new-ipad-pro-with-the-m5-chip/",
"ipad-air-m3":"2025/03/apple-introduces-ipad-air-with-powerful-m3-chip-and-new-magic-keyboard/",
"apple-watch-series-11":"2025/09/apple-debuts-apple-watch-series-11-featuring-groundbreaking-health-insights/",
"apple-watch-ultra-3":"2025/09/introducing-apple-watch-ultra-3/",
"airpods-pro-3":"2025/09/introducing-airpods-pro-3-the-ultimate-audio-experience/",
"magsafe-cases":"2023/09/apple-debuts-iphone-15-and-iphone-15-plus/",
}
def run(item):
 slug,page=item;url="https://www.apple.com/newsroom/"+page
 try:
  html=urllib.request.urlopen(url,timeout=25).read().decode()
  images=list(dict.fromkeys(re.findall(r'https://www.apple.com/newsroom/images/[^"\s<>]+\.jpg\.large\.jpg',html)))
  def score(u):
   n=u.rsplit('/',1)[-1].lower()
   if any(x in n for x in ['photography','lifestyle','chip','health','camera-close','fitness','portrait','workout','display-','touch-id']):return -20
   return sum(5 for x in ['color-lineup','finish-lineup','hero','2-up','front-and-back','cosmic-orange','all-colors','design','airpods-pro-3-','band-lineup','magic-keyboard'] if x in n)
  chosen=sorted(images,key=score,reverse=True)
  if slug=="magsafe-cases":chosen=[u for u in images if "FineWoven" in u]
  chosen=[u for u in chosen if score(u)>-10][:2]
  result=[]
  folder=root/"public/images/products";folder.mkdir(parents=True,exist_ok=True)
  for i,u in enumerate(chosen):
   raw=urllib.request.urlopen(u,timeout=25).read()
   im=Image.open(io.BytesIO(raw));im.thumbnail((1100,1100))
   output=folder/(slug+"-"+str(i+1)+".webp");im.save(output,"WEBP",quality=82,method=6)
   result.append({"local":"/images/products/"+output.name,"source":u})
  print(slug, len(result))
  return slug,{"page":url,"images":result}
 except Exception as e:print(slug,str(e));return slug,{"page":url,"images":[]}
with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:manifest=dict(pool.map(run,pages.items()))
(root/"docs/ASSET-SOURCES.json").write_text(json.dumps(manifest,indent=2))
